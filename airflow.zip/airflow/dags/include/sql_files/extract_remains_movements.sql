SELECT 
	DATEADD(YEAR,-2000,remains._Period) AS _Period
	, COALESCE(
        additional_expenses_recorder._Number,
        accounting_adjustment_recorder._Number,
        assembly_recorder._Number,
        return_from_buyer_recorder._Number,
        return_to_supplier_recorder._Number,
        inventory_recorder._Number,
        production_report_recorder._Number,
        movement_recorder._Number,
        reclassification_recorder._Number,
        receipt_recorder._Number,
        cutting_recorder._Number,
        disassembly_recorder._Number,
        sales_recorder._Number,
        write_off_recorder._Number,
        shift_close_recorder._Number
    ) AS НомерДокумента
	, remains._RecorderTRef
	, remains._RecorderRRef
	, remains.СкладКомпании_ID
	, remains.ХозОперация_ID
    , COALESCE(receipt_party.Контрагент_ID, return_from_buyer_party.Контрагент_ID, inventory_party.Контрагент_ID) AS Контрагент_ID
	, remains.Номенклатура_ID
    , remains._RecordKind
	, remains.Количество
	, remains.СуммаУпр
    , remains.СуммаНДС
FROM 
    vw_ПартииТоваровКомпании remains WITH (NOLOCK)

-- To find document_number
LEFT OUTER JOIN vw_ПоступлениеДопРасходов additional_expenses_recorder WITH (NOLOCK)
    ON remains._RecorderTRef = 0x00000204 AND remains._RecorderRRef = additional_expenses_recorder._IDRRef
LEFT OUTER JOIN vw_КорректировкаУчетныхДанных accounting_adjustment_recorder WITH (NOLOCK)
    ON remains._RecorderTRef = 0x000001E9 AND remains._RecorderRRef = accounting_adjustment_recorder._IDRRef
LEFT OUTER JOIN vw_Комплектация assembly_recorder WITH (NOLOCK)
    ON remains._RecorderTRef = 0x000001E0 AND remains._RecorderRRef = assembly_recorder._IDRRef
LEFT OUTER JOIN vw_ВозвратОтПокупателя return_from_buyer_recorder WITH (NOLOCK)
    ON remains._RecorderTRef = 0x000001B2 AND remains._RecorderRRef = return_from_buyer_recorder._IDRRef
LEFT OUTER JOIN vw_ВозвратПоставщику return_to_supplier_recorder WITH (NOLOCK)
    ON remains._RecorderTRef = 0x000001B3 AND remains._RecorderRRef = return_to_supplier_recorder._IDRRef
LEFT OUTER JOIN vw_Инвентаризация inventory_recorder WITH (NOLOCK)
    ON remains._RecorderTRef = 0x000001D0 AND remains._RecorderRRef = inventory_recorder._IDRRef
LEFT OUTER JOIN vw_ОтчетПроизводстваЗаСмену production_report_recorder WITH (NOLOCK)
    ON remains._RecorderTRef = 0x000001F5 AND remains._RecorderRRef = production_report_recorder._IDRRef
LEFT OUTER JOIN vw_ПеремещениеТоваров movement_recorder WITH (NOLOCK)
    ON remains._RecorderTRef = 0x000001F8 AND remains._RecorderRRef = movement_recorder._IDRRef
LEFT OUTER JOIN vw_ПересортицаТоваров reclassification_recorder WITH (NOLOCK)
    ON remains._RecorderTRef = 0x000001FC AND remains._RecorderRRef = reclassification_recorder._IDRRef
LEFT OUTER JOIN vw_ПоступлениеТоваров receipt_recorder WITH (NOLOCK)
    ON remains._RecorderTRef = 0x00000205 AND remains._RecorderRRef = receipt_recorder._IDRRef
LEFT OUTER JOIN vw_Разделка cutting_recorder WITH (NOLOCK)
    ON remains._RecorderTRef = 0x0000020B AND remains._RecorderRRef = cutting_recorder._IDRRef
LEFT OUTER JOIN vw_Разукомплектация disassembly_recorder WITH (NOLOCK)
    ON remains._RecorderTRef = 0x0000020C AND remains._RecorderRRef = disassembly_recorder._IDRRef
LEFT OUTER JOIN vw_РеализацияТоваров sales_recorder WITH (NOLOCK)
    ON remains._RecorderTRef = 0x00000212 AND remains._RecorderRRef = sales_recorder._IDRRef
LEFT OUTER JOIN vw_СписаниеТоваров write_off_recorder WITH (NOLOCK)
    ON remains._RecorderTRef = 0x0000021A AND remains._RecorderRRef = write_off_recorder._IDRRef
LEFT OUTER JOIN vw_ЗакрытиеСмены shift_close_recorder WITH (NOLOCK)
    ON remains._RecorderTRef = 0x000001CA AND remains._RecorderRRef = shift_close_recorder._IDRRef

-- To find supplier
LEFT OUTER JOIN vw_ПоступлениеТоваров receipt_party WITH (NOLOCK)
    ON remains.Партия_НОМЕР = 0x00000205 AND remains.Партия_ID = receipt_party._IDRRef
LEFT OUTER JOIN vw_ОтчетПроизводстваЗаСмену production_report_party WITH (NOLOCK)
    ON remains.Партия_НОМЕР = 0x000001F5 AND remains.Партия_ID = production_report_party._IDRRef
LEFT OUTER JOIN vw_ЗакрытиеСмены shift_close_party WITH (NOLOCK)
    ON remains.Партия_НОМЕР = 0x000001CA AND remains.Партия_ID = shift_close_party._IDRRef
LEFT OUTER JOIN vw_Инвентаризация inventory_party WITH (NOLOCK)
    ON remains.Партия_НОМЕР = 0x000001D0 AND remains.Партия_ID = inventory_party._IDRRef
LEFT OUTER JOIN vw_ПересортицаТоваров reclassification_party WITH (NOLOCK)
    ON remains.Партия_НОМЕР = 0x000001FC AND remains.Партия_ID = reclassification_party._IDRRef
LEFT OUTER JOIN vw_ПеремещениеТоваров movement_party WITH (NOLOCK)
    ON remains.Партия_НОМЕР = 0x000001F8 AND remains.Партия_ID = movement_party._IDRRef
LEFT OUTER JOIN vw_Разделка cutting_party WITH (NOLOCK)
    ON remains.Партия_НОМЕР = 0x0000020B AND remains.Партия_ID = cutting_party._IDRRef
LEFT OUTER JOIN vw_ВозвратОтПокупателя return_from_buyer_party WITH (NOLOCK)
    ON remains.Партия_НОМЕР = 0x000001B2 AND remains.Партия_ID = return_from_buyer_party._IDRRef
LEFT OUTER JOIN vw_Комплектация assembly_party WITH (NOLOCK)
    ON remains.Партия_НОМЕР = 0x000001E0 AND remains.Партия_ID = assembly_party._IDRRef

WHERE 
    remains._Period >= DATEADD(YEAR, 2000, '{{get_data_interval_start(data_interval_end) | ds_nodash}}')
    AND remains._Period < DATEADD(YEAR, 2000, '{{get_next_month_start_date(data_interval_end) | ds_nodash}}')
    AND remains._Active = 0x01

-- TODO: Uncomment following lines to get correct remains with filtering out documents that have been deleted (_Marked = 0x01)
-- AND 
-- COALESCE(
--     receipt_party._Marked,
--     production_report_party._Marked,
--     shift_close_party._Marked,
--     inventory_party._Marked,
--     reclassification_party._Marked,
--     movement_party._Marked,
--     cutting_party._Marked,
--     return_from_buyer_party._Marked,
--     assembly_party._Marked, 0x00) = 0x00