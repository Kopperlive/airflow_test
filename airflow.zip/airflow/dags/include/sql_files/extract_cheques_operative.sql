DECLARE @end datetime = ? -- data_interval_end
DECLARE @start datetime = ?--data_interval_start
DECLARE @start_of_day datetime = dateadd(DAY, datediff(DAY, 0, @start),0) 

select 
    CONCAT(
             CONVERT([varchar](30), CONVERT([date], [SDATE])),
             '_',
             CONVERT([varchar](3), [SHOPINDEX]),
             '_',
             CONVERT([varchar](100), [CASHNUMBER]),
             '_',
             CONVERT([varchar](100), [ZNUMBER]),
             '_',
             CONVERT([varchar](100), [CHECKNUMBE])
         ) AS [Id]
    ,CAST(sdate as date) as [date]
    ,[shopindex] as [shopindex]
    ,[cashnumber] as [cashnumber]
    ,[znumber] as [zreportnumber]
    ,[checknumbe] as [checknumber]
    ,[cardarticu] as [articul]
    ,[casher] as [cashercode]
    ,CAST(STUFF(RIGHT('0000' + CAST(stime as varchar), 4), 3, 0, ':') as Time) as [time]
    ,[id] as [frontolid]
    ,[pricecur] as [price]
    ,[quantity] as [quantity]
    ,[totalcur] as [total]
    ,[recmoment] as [recorddatetime]
from [KKMCHECKCONTENS] WITH (NOLOCK)
where [recmoment] >=@start AND [recmoment]<@end
    AND [sdate]>=@start_of_day -- Get only current day's update
    AND [shopindex]=?
