WITH CTE_PROMO AS (
SELECT 
       s.НачалоДействия AS start_datetime
	   , s.КонецДействия AS end_datetime
	   , s.Подразделение_ID AS division_id
	   , ns.ТипЦен_ID AS price_type_id
       , s.Объект_ID  AS product_id
	   , _Number AS document_number
       , nss.ЗначениеСкидки AS new_price
FROM vw_Скидки s WITH (NOLOCK)
    JOIN vw_НазначениеСкидок ns WITH (NOLOCK)
        ON ns._IDRRef = s._RecorderRRef
    JOIN vw_НазначениеСкидок_Скидки nss WITH (NOLOCK)
        ON nss.Ссылка = ns._IDRRef
           AND nss.Номенклатура_ID = s.Объект_ID
WHERE s.КонецДействия >= CAST('{{ data_interval_end| add_1c_offset_years | convert_to_local_timezone }}' AS Date)-- Because the end_date should be more than now for it to be active currently
 	  AND s.НачалоДействия <= CAST('{{ data_interval_end| add_1c_offset_years | convert_to_local_timezone }}' AS Date)

      AND s._Active = 0x01
      AND s.Действует = 0x01
      AND ns._Marked = 0x00
      AND ns._Posted = 0x01
),

CTE_PRICE_CHANGES AS (
SELECT
	price_changes.ДатаНачалаДействия AS start_datetime
	, divisions._IDRRef AS division_id
    , price_changes.ТипЦен_ID AS price_type_id
	, _Number AS document_number
    , price_changes_products.Номенклатура_ID AS product_id
    , price_changes_products.Цена as new_price            
FROM [vw_ИзменениеЦен] price_changes WITH(NOLOCK)   
    JOIN [vw_ИзменениеЦен_Товары] price_changes_products WITH(NOLOCK)  
		ON price_changes_products.[Ссылка] = price_changes._IDRRef 
	JOIN [vw_ПодразделенияКомпании] divisions
		ON divisions.ТипЦенРеализации_ID=price_changes.ТипЦен_ID
WHERE price_changes.ДатаНачалаДействия BETWEEN '{{ data_interval_start.subtract(days=params.date_range)| add_1c_offset_years | convert_to_local_timezone }}' and '{{ data_interval_end| add_1c_offset_years | convert_to_local_timezone }}'
    AND price_changes._Posted=0x01 AND price_changes._Marked=0x00
)

SELECT 
	DATEADD(YEAR,-2000,COALESCE(promo.start_datetime,changes.start_datetime)) AS start_datetime
	, CONVERT(NCHAR(34),COALESCE(promo.division_id,changes.division_id),1) AS division_id
	, CONVERT(NCHAR(34),COALESCE(promo.price_type_id,changes.price_type_id),1) AS price_type_id
	, COALESCE(promo.document_number,changes.document_number) AS document_number
	, CONVERT(NCHAR(34),COALESCE(promo.product_id,changes.product_id),1) AS product_id
	, COALESCE(promo.new_price,changes.new_price) AS new_price
	, CASE WHEN promo.new_price IS NOT NULL THEN 1 ELSE 0 END AS is_promo
	, product._Code AS product_code
FROM CTE_PRICE_CHANGES changes 
	FULL OUTER JOIN CTE_PROMO promo
		ON promo.division_id=changes.division_id AND promo.product_id=changes.product_id  AND changes.start_datetime < promo.end_datetime
	INNER JOIN [vw_Номенклатура] product 
		ON product._IDRRef=COALESCE(promo.product_id,changes.product_id)
