WITH date_series AS (
    SELECT
        toDate('2021-01-01') + INTERVAL number DAY AS date
    FROM numbers(365 * 10) -- Adjust the range for the number of years
),
final AS (

SELECT
    date
    , toYear(date) AS year
    , toMonth(date) AS month
    , toDayOfMonth(toLastDayOfMonth(date)) AS days_in_month
    , toDayOfMonth(date) AS day
    , toDayOfWeek(date) AS day_of_week
    , toQuarter(date) AS quarter

    , dateName('weekday', date) AS day_of_week_en
    , CASE dateName('weekday', date)
        WHEN 'Monday' THEN 'Понедельник'
        WHEN 'Tuesday' THEN 'Вторник'
        WHEN 'Wednesday' THEN 'Среда'
        WHEN 'Thursday' THEN 'Четверг'
        WHEN 'Friday' THEN 'Пятница'
        WHEN 'Saturday' THEN 'Суббота'
        WHEN 'Sunday' THEN 'Воскресенье'
    END AS day_of_week_ru

    , dateName('month', date) AS month_en
    , CASE month_en
        WHEN 'January' THEN 'Январь'
        WHEN 'February' THEN 'Февраль'
        WHEN 'March' THEN 'Март'
        WHEN 'April' THEN 'Апрель'
        WHEN 'May' THEN 'Май'
        WHEN 'June' THEN 'Июнь'
        WHEN 'July' THEN 'Июль'
        WHEN 'August' THEN 'Август'
        WHEN 'September' THEN 'Сентябрь'
        WHEN 'October' THEN 'Октябрь'
        WHEN 'November' THEN 'Ноябрь'
        WHEN 'December' THEN 'Декабрь'
    END AS month_ru

FROM date_series
)

SELECT * FROM final
