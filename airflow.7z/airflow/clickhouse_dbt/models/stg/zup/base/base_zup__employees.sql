WITH source AS (

    SELECT * FROM {{ source('raw_dbt','zup_employees_raw') }}

)

, renamed AS (
    SELECT
        {{transform_string('"Должность"')}} AS job_title
        , {{transform_string('"ФизЛицо"')}} AS description
        , {{transform_string('CAST("ИНН" AS String)') }} AS TIN
        , {{transform_string('"Подразделение"') }} AS division
        , {{transform_decimal('"Оклад"')}} AS salary_amount
        , {{transform_string('"ГрафикРаботы"')}} AS work_schedule
        , {{transform_string('CAST("Телефон" AS String)')}} AS phone_number
    FROM source
)
SELECT * FROM renamed