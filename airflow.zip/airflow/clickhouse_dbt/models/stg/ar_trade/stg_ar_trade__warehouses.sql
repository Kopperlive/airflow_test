WITH warehouses AS (
    SELECT * FROM {{ ref('base_ar_trade__warehouses') }}
),

regions AS (
    SELECT * FROM {{ ref('base_ar_trade__regions') }}
),

final AS (
    SELECT 
        --  ids
          warehouses.id AS id
        , warehouses.parent_id AS parent_id
        , warehouses.division_id as division_id

        -- code
        , warehouses.code AS code

        -- names
        , warehouses.description AS description
        
        --other values
        , {{transform_string('regions.description')}} AS region

        --booleans
        , warehouses.is_deleted AS is_deleted
        , warehouses.is_item as is_item

    FROM warehouses
        LEFT JOIN regions ON 
            warehouses.region_id=regions.id
)

SELECT * FROM final
