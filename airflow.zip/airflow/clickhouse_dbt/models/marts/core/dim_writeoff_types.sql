WITH source AS (
    SELECT * FROM {{ ref('stg_ar_trade__writeoff_types') }}
)

, final AS (
    SELECT *
    FROM source
)

SELECT * FROM final
