{{
    config(
        materialized='table'
    )
}}
-- getting level of every item in the hierarchy
WITH RECURSIVE hierarchy_levels AS (
    SELECT
        id
        , parent_id
        , description
        , is_item
        , 1 AS level
    FROM
        {{ ref('stg_ar_trade__products') }}
    WHERE
        parent_id = toUUID('00000000-0000-0000-0000-000000000000')
    UNION ALL
    SELECT
        c.id
        , c.parent_id
        , c.description
        , is_item
        , p.level + 1 AS level
    FROM
        {{ ref('stg_ar_trade__products') }} AS c
    INNER JOIN
        hierarchy_levels AS p ON
    c.parent_id = p.id
)

-- join to each other 6 times to get all of its ancestors 
, hierarchy_levels_with_all_6_ancestors AS (
    SELECT


        -- current product/category
        current_product.id AS id
        , current_product.parent_id AS parent_id
        , current_product.level AS level

        -- its ancestors
        , CAST(multiIf(
            ancestor_1.level = 5
            , ancestor_1.id
            , toUUID('00000000-0000-0000-0000-000000000000')
        ) AS UUID)
            AS fifth_category_id

        , CAST(multiIf(
            ancestor_1.level = 4
            , ancestor_1.id
            , ancestor_2.level = 4
            , ancestor_2.id
            , toUUID('00000000-0000-0000-0000-000000000000')
        ) AS UUID) AS fourth_category_id

        , CAST(multiIf(
            ancestor_1.level = 3
            , ancestor_1.id
            , ancestor_2.level = 3
            , ancestor_2.id
            , ancestor_3.level = 3
            , ancestor_3.id
            , toUUID('00000000-0000-0000-0000-000000000000')
        ) AS UUID) AS third_category_id

        , CAST(multiIf(
            ancestor_1.level = 2
            , ancestor_1.id
            , ancestor_2.level = 2
            , ancestor_2.id
            , ancestor_3.level = 2
            , ancestor_3.id
            , ancestor_4.level = 2
            , ancestor_4.id
            , toUUID('00000000-0000-0000-0000-000000000000')
        ) AS UUID) AS second_category_id

        , CAST(multiIf(
            ancestor_1.level = 1
            , ancestor_1.id
            , ancestor_2.level = 1
            , ancestor_2.id
            , ancestor_3.level = 1
            , ancestor_3.id
            , ancestor_4.level = 1
            , ancestor_4.id
            , ancestor_5.level = 1
            , ancestor_5.id
            , toUUID('00000000-0000-0000-0000-000000000000')
        ) AS UUID) AS first_category_id




    FROM hierarchy_levels AS current_product
    LEFT JOIN hierarchy_levels AS ancestor_1
        ON current_product.parent_id = ancestor_1.id
    LEFT JOIN hierarchy_levels AS ancestor_2
        ON ancestor_1.parent_id = ancestor_2.id
    LEFT JOIN hierarchy_levels AS ancestor_3
        ON ancestor_2.parent_id = ancestor_3.id
    LEFT JOIN hierarchy_levels AS ancestor_4
        ON ancestor_3.parent_id = ancestor_4.id
    LEFT JOIN hierarchy_levels AS ancestor_5
        ON ancestor_4.parent_id = ancestor_5.id
    WHERE 1 = 1

)

SELECT * FROM hierarchy_levels_with_all_6_ancestors
