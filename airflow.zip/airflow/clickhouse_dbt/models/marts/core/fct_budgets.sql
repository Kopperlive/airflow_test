WITH source AS (
    SELECT * FROM {{ ref('budgets') }}
)

, renamed AS (

    SELECT

        {{transform_string('month')}} AS month
        , CAST(year AS UInt32) AS year
        , {{transform_decimal('amount_with_VAT')}} AS amount_with_VAT
        , {{transform_decimal('amount')}} AS amount
        , {{transform_decimal('gross_margin')}} AS gross_margin

    FROM source

)


SELECT * FROM renamed
