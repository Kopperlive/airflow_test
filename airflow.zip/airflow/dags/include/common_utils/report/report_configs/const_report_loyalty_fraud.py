ENG_COLUMNS = [
    "MartName",
    "Number",
    "LastName",
    "FirstName",
    "Secondname",
    "Phone",
    "TransactionTime",
    "PosName",
    "ChequeID",
    "Freq",
    "AccrualBonus",
    "AccrualAmount",
    "TotalBonus",
    "TotAmount",
]
RUS_COLUMNS = [
    "Маркет",
    "Карта",
    "Фамилия",
    "Имя",
    "Отчество",
    "Телефон",
    "День",
    "Касса",
    "Номер Чека",
    "Количество чеков",
    "Сумма Бонусов",
    "Сумма Чека",
    "Общая сумма бонусов",
    "Общая сумма",
]
FILTER_COLUMNS = [
    "Date",
    "MartName",
    "Number",
    "LastName",
    "FirstName",
    "Secondname",
    "Phone",
    "PosName",
    "TransactionTime",
    "ChequeID",
]

ENG_TO_RUS_COLUMNS = dict(zip(ENG_COLUMNS, RUS_COLUMNS))

FREQUENCY_NAME = {"daily": "Ежедневный", "weekly": "Еженедельный"}
