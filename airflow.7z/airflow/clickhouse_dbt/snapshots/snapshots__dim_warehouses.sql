{% snapshot snapshots__dim_warehouses %}
    select * from {{ ref('stg_ar_trade__warehouses') }}
{% endsnapshot %}