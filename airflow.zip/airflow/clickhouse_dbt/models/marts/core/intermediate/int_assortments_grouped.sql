WITH source AS (
    SELECT * FROM {{ ref("base_ar_trade__assortments") }}
),
distinct_rows AS (
    SELECT DISTINCT
        date
        , recorder_id
        , division_id
        , product_id
        , vat_rate_id
        , is_entered
        , cost_price_with_VAT
        , is_base_assortment
    FROM source
)
SELECT * FROM distinct_rows