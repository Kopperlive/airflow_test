WITH source AS (

    SELECT * FROM {{ ref("int_transfers_grouped") }}

)

, final AS (
    SELECT * FROM source
)


SELECT * FROM final
