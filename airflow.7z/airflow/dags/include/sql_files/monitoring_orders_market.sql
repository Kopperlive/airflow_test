SELECT 
    DATEADD(YEAR,-2000,T9._Date_Time) AS _Date_Time,
    T9._Number,
    T9.[СуммаДокумента] AS Amount,
    T10._Description as Author,
    CONVERT(NCHAR(34),T9.Контрагент_ID,1) as Supplier_ID,
    CONVERT(NCHAR(34),T9.СкладКомпании_ID,1) as Warehouse_ID

FROM {database}.dbo.[vw_ЗаказПоставщику] T9 WITH(NOLOCK)

JOIN {database}.dbo.[vw_Пользователи] T10 WITH(NOLOCK)
    ON T9.[Автор_ID] = T10._IDRRef

WHERE t9._Date_Time BETWEEN '{data_interval_start}' AND '{data_interval_end}' AND T9.СуммаДокумента !=0 AND T9.СкладКомпании_ID!=0x00000000000000000000000000000000