WITH source AS (

    SELECT * FROM {{ ref('base_ar_trade__writeoffs') }}

)

, grouped AS (

    SELECT
        date

        , id
        , document_number

        , comment
        , author_id

        , division_id
        , warehouse_id
        , contragent_id
        , product_id
        , writeoff_type_id

        , operation_id
        , price_type_id

        , SUM(quantity) AS quantity
        , SUM(cost_price) AS cost_price
        , SUM(cost_price_VAT) AS cost_price_VAT
    FROM source
    GROUP BY ALL
)

SELECT * FROM grouped
