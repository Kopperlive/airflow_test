{% macro transform_snapshot(snapshot_name) %}
WITH snapshot AS (
    SELECT * FROM {{ ref(snapshot_name) }}
)

, final AS (
    SELECT
        *

        EXCEPT (dbt_valid_from, dbt_valid_to, dbt_scd_id, dbt_updated_at)

        --boolean
        , if(isNull(dbt_valid_to), 1, 0) AS is_current

        -- SCD columns
        , if(CAST(dbt_valid_from AS Date)=(SELECT CAST(min(dbt_valid_from) AS Date) FROM snapshot),CAST('1970-01-01' AS Date),CAST(dbt_valid_from AS Date)) AS start_date
        , if(isNull(dbt_valid_to),CAST('2106-02-07' AS Date),CAST(dbt_valid_to AS Date)) AS end_date
        , dbt_updated_at AS inserted_at

    FROM snapshot

    --- what if you updated the table multiple times a day?: Select the last update
    QUALIFY 
        ROW_NUMBER() OVER (
            PARTITION BY 
                id, 
                start_date
            ORDER BY 
                dbt_valid_from DESC
        ) = 1

)

SELECT * FROM final
{% endmacro %}