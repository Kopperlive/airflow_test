WITH source AS (

    SELECT * FROM {{ source('raw_dbt','supplies_raw') }}

)

, renamed AS (

    SELECT
        CAST("_Date_Time" AS Date) AS date

        , {{ transform_hex_to_uuid('_IDRRef') }} AS id
        , {{ transform_string('_Number') }} AS document_number
        , CAST({{ transform_hex_to_uuid('"Автор_ID"') }} AS LowCardinality (UUID)) AS author_id
        , {{ transform_string('"Комментарий"') }} AS comment

        , CAST({{ transform_hex_to_uuid('"ПодразделениеКомпании_ID"') }} AS LowCardinality (UUID)) AS division_id
        , CAST({{ transform_hex_to_uuid('"СкладКомпании_ID"') }} AS LowCardinality (UUID)) AS warehouse_id
        , CAST({{ transform_hex_to_uuid('"Контрагент_ID"') }} AS LowCardinality (UUID)) AS contragent_id
        , {{ transform_hex_to_uuid('"Номенклатура_ID"') }} AS product_id
        , {{ transform_hex_to_uuid('"ЕдиницаИзмерения_ID"') }} AS measurement_id

        , CAST({{ transform_hex_to_uuid('"ХозОперация_ID"') }} AS LowCardinality (UUID)) AS operation_id

        , CAST({{ transform_hex_to_uuid('"ДоговорВзаиморасчетов_ID"') }} AS LowCardinality (UUID)) AS contragent_settlement_id

        , CAST({{ transform_hex_to_uuid('"ТипЦен_ID"') }} AS LowCardinality (UUID)) AS price_type_id
        , CAST({{ transform_hex_to_uuid('"СтавкаНДС_ID"') }} AS LowCardinality (UUID)) AS vat_rate_id

        , {{ transform_hex_to_uuid('"ЗаказПоставщику_ID"') }} AS order_id

        , {{ transform_decimal('"Количество"') }} AS quantity
        , {{ transform_decimal('"СуммаБезНалогов"') }} AS cost_price
        , {{ transform_decimal('"СуммаНДС"') }} AS cost_price_VAT
    FROM source

)

SELECT * FROM renamed
