WITH source AS (

    SELECT * FROM {{ ref("base_ar_trade__remains_movements") }}

)

, warehouses AS (
    SELECT *
    FROM {{ ref('base_ar_trade__warehouses') }}
)

, calendar AS (
    SELECT *
    FROM {{ source('raw_dbt','remains_calendar') }}
)

, grouped AS (

    SELECT
        source.date AS date
        , CAST(source.operation_id AS LowCardinality (UUID)) AS operation_id
        , source.recorder_id AS recorder_id
        , source.recorder_document_number
        , CAST(warehouses.division_id AS LowCardinality (UUID)) AS division_id
        , CAST(source.warehouse_id AS LowCardinality (UUID)) AS warehouse_id
        , CAST(source.contragent_id AS LowCardinality (UUID)) AS contragent_id
        , source.product_id AS product_id

        , source.is_stock_out AS is_stock_out

        , SUM(source.quantity) AS quantity
        , SUM(source.cost_price) AS cost_price
        , SUM(source.cost_price_VAT) AS cost_price_VAT
    FROM source

    JOIN warehouses
        ON source.warehouse_id = warehouses.id

    WHERE source.date < (SELECT MAX(date) FROM calendar) -- there are movements for today's date(they are needed to calculate remains)

    GROUP BY ALL
)

SELECT * FROM grouped
