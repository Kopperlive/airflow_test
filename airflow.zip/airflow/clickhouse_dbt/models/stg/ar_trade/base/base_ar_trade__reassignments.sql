WITH source AS (
    SELECT * FROM {{source('raw_dbt', 'reassignments_raw')}}
),

renamed AS (
    SELECT
        -- dates
        CAST(_Date_Time AS Date) AS date

        -- ids
        , CAST({{transform_hex_to_uuid('"_IDRRef"')}} AS UUID) AS id
        , CAST({{transform_hex_to_uuid('"Автор_ID"')}} AS LowCardinality (UUID)) AS author_id
        , CAST({{transform_hex_to_uuid('"ПодразделениеКомпании_ID"')}} AS LowCardinality (UUID)) AS division_id
        , CAST({{transform_hex_to_uuid('"СкладКомпании_ID"')}} AS LowCardinality (UUID)) AS warehouse_id
        , CAST({{transform_hex_to_uuid('"ТипЦен_ID"')}} AS LowCardinality (UUID)) AS price_type_id
        , CAST({{transform_hex_to_uuid('"ХозОперация_ID"')}} AS LowCardinality (UUID)) AS operation_id
        , CAST({{transform_hex_to_uuid('"СтатьяПричиныПересортицы_ID"')}} AS LowCardinality (UUID)) AS reassignment_reason_id
        , CAST({{transform_hex_to_uuid('"НоменклатураПриход_ID"')}} AS LowCardinality (UUID)) AS incoming_product_id
        , CAST({{transform_hex_to_uuid('"НоменклатураРасход_ID"')}} AS LowCardinality (UUID)) AS outgoing_product_id
        , CAST({{transform_hex_to_uuid('"ЕдиницаИзмеренияПриход_ID"')}} AS LowCardinality (UUID)) AS incoming_measurement_id
        , CAST({{transform_hex_to_uuid('"ЕдиницаИзмеренияРасход_ID"')}} AS LowCardinality (UUID)) AS outgoing_measurement_id

        -- boolean
        , {{transform_binary_to_boolean('"ПонижениеСортности"')}} AS is_downgrading

        -- values
        , {{transform_string('"_Number"')}} AS document_number
        , {{transform_string('"Комментарий"')}} AS comment
        , {{transform_decimal('"КоличествоПриход"')}} AS incoming_quantity
        , {{transform_decimal('"КоличествоРасход"')}} AS outgoing_quantity
        , {{transform_decimal('"ЦенаРозничнаяПриход"')}} AS incoming_price_with_VAT
        , {{transform_decimal('"ЦенаРозничнаяРасход"')}} AS outgoing_price_with_VAT
        , {{transform_decimal('"СуммаРозничнаяПриход"')}} AS incoming_amount_with_VAT
        , {{transform_decimal('"СуммаРозничнаяРасход"')}} AS outgoing_amount_with_VAT
        , {{transform_decimal('"СуммаРозничнаяРасход"')}} - {{transform_decimal('"СуммаРозничнаяПриход"')}} AS reevaluation_amount_with_VAT
    FROM source
)

SELECT * FROM renamed
