WITH source AS (
    SELECT * FROM {{ref("int_price_changes_grouped")}}
),

final AS (
    SELECT * FROM source
)

SELECT * FROM final