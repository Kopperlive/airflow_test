WITH source AS (

    SELECT * FROM {{ source('raw_dbt','contragents_raw') }}

)

, renamed AS (

    SELECT
        -- ids
        {{ transform_binary_to_uuid('_IDRRef') }} AS id
        , {{ transform_binary_to_uuid('_ParentIDRRef') }} AS parent_id
        , {{ transform_binary_to_uuid('"ГоловнойКонтрагент_ID"') }} AS head_contragent_id
        , {{ transform_binary_to_uuid('"ОсновнойДоговорВзаиморасчетов_ID"') }} AS main_settlement_id
        -- codes
        , {{ transform_string('_Code') }} AS code


        -- names
        , {{ transform_string('_Description') }} AS description

        -- other stuff
        , {{ transform_string('"ИНН"') }} AS "TIN"
        , {{ transform_string('"ЭлектронныйАдрес"') }} AS email_address

        -- booleans
        , {{ transform_binary_to_boolean('_Marked') }} AS is_deleted
        , {{ transform_binary_to_boolean('_Folder') }} AS is_item
        , {{ transform_binary_to_boolean('"ОсвобожденОтНДС"') }} AS is_exempt_from_VAT
        , {{ transform_binary_to_boolean('"Импорт"') }} AS is_foreign

    FROM source

)

SELECT * FROM renamed
