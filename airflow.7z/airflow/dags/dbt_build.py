import pendulum
from airflow.decorators import dag, task
from common_utils.telegram_utils import send_error_message_telegram

doc_md = """
Runs all dbt models,seeds in correct order
"""


@dag(
    default_args={
        "owner": "ubaitur5",
        "on_failure_callback": send_error_message_telegram,
    },
    schedule_interval="30 1-11 * * *",
    start_date=pendulum.DateTime(2024, 9, 1),
    doc_md=doc_md,
    tags=["dbt"],
    catchup=False,
)
def dbt_build():

    @task.bash
    def dbt_build():
        return f"dbt build --exclude test_type:data dim_promotions"

    # @task.bash(trigger_rule="all_done")
    # def dbt_test():
    #     return f"dbt test"

    dbt_build()
    # >> dbt_test()


dbt_build()
