import os

import duckdb
import pendulum
from airflow.decorators import dag, task
from airflow.models.taskinstance import TaskInstance
from airflow_clickhouse_plugin.operators.clickhouse import ClickHouseOperator
from common_utils.telegram_utils import send_error_message_telegram
from constants.etl_constants import EMPTY_NULL_PLACEHOLDER
from custom_operators.s3tosql import SqlToS3OperatorImproved

doc_md = """
# ETL Dimensions Division DAG Documentation

## Overview

The `division` DAG is designed to extract, transform, and load (ETL) division-related data into a data warehouse. This DAG handles the dimensional data for divisions, organizing them with detailed attributes like formats, curators, and geographic coordinates. The DAG also implements Slowly Changing Dimensions (SCD) logic to maintain historical records.

## DAG Configuration

- **Schedule**: Daily
- **Start Date**: July 23, 2024
- **Catchup**: False
- **Tags**: 'etl', 'dimensions'

## Tasks Overview

### extract_division_raw

- **Operator**: `SqlToS3OperatorImproved`
- **Description**: Extracts raw division data from the source system and stores it in S3 in parquet format.
- **Source**: Division management system accessed via `AR_TRADE_CONN_ID`.

### extract_division_format_raw

- **Operator**: `SqlToS3OperatorImproved`
- **Description**: Extracts division format data and stores it in S3 in parquet format.
- **Source**: Division management system accessed via `AR_TRADE_CONN_ID`.

### extract_division_curator_raw

- **Operator**: `SqlToS3OperatorImproved`
- **Description**: Extracts data related to division curators and stores it in S3 in parquet format.
- **Source**: Division management system accessed via `AR_TRADE_CONN_ID`.

### extract_division_old

- **Operator**: `ClickHouseOperator`
- **Description**: Extracts the current state of division records from the data warehouse, marking them as 'current', and stores the data in S3 in CSV format.
- **Source**: Data warehouse accessed via `clickhouse_dwh`.

### from_s3_to_duckdb

- **Function**: `from_s3_to_duckdb`
- **Description**: Loads division data from S3 into DuckDB for further processing. The data includes division formats, curators, and geographic coordinates. The task establishes the DuckDB connection, configures S3 access, and loads the datasets.

### transform_division

- **Function**: `transform_division`
- **Description**: Transforms the raw division data in DuckDB by joining it with format, curator, and geographic data, and prepares it for loading into the data warehouse. It adds enriched information such as division format descriptions, curator details, and geographic coordinates.

### division_scd

- **Function**: `division_scd`
- **Description**: Implements Slowly Changing Dimensions (SCD) logic for the division data. This task detects new and updated division records, manages historical records, and updates the data with appropriate start and end dates for each record's validity.

### update_division

- **Operator**: `ClickHouseOperator`
- **Description**: Updates division records in the data warehouse, marking old records as historical and maintaining the start and end dates for each division record.

### load_division

- **Operator**: `ClickHouseOperator`
- **Description**: Loads the transformed and updated division data back into the data warehouse from S3, utilizing parquet files generated during the SCD process.

### remove_temp_files

- **Function**: `remove_temp_files`
- **Description**: Removes temporary files, including the DuckDB database file, to clean up resources and ensure that the next DAG run starts with a fresh environment.

## Data Flow

1. **Extract Data**: Division, division format, and division curator data are extracted from the source system using `SqlToS3OperatorImproved` and stored in S3.
2. **Load into DuckDB**: The extracted data is loaded into DuckDB for further transformation and processing.
3. **Data Transformation**: The raw division data is transformed in DuckDB by joining it with format and curator data, and geographic coordinates, creating an enriched dataset ready for loading into the data warehouse.
4. **Slowly Changing Dimensions**: New and updated division records are identified, and historical records are managed using SCD logic.
5. **Load into Data Warehouse**: The final division data is loaded into the data warehouse, and old records are updated accordingly.
6. **Cleanup**: Temporary files are removed to clean up the environment for the next DAG run.

## Additional Details

- **Data Integrity**: This DAG ensures that division data is accurate and up-to-date by implementing SCD logic, which tracks changes to division data and maintains historical records.
- **Technology Stack**: Utilizes Airflow for orchestration, DuckDB for data processing, and ClickHouse for data storage, providing a reliable system for ETL processes.
- **Security**: Secure data handling practices are implemented by configuring S3 access securely and ensuring that data transfer between systems is encrypted and managed through secure channels.


"""

# S3 stuff
S3_CONN_ID = "minio_s3"
BUCKET_NAME = "etl-data-files"
INFO_BUCKET_NAME = "info"
S3_FOLDER = "division"

DUCKDB_FILE = "/tmp/division.db"

AR_TRADE_CONN_ID = "nsp_ar_trade"


@task
def from_s3_to_duckdb(data_interval_end: pendulum.DateTime, ti: TaskInstance):
    """
    Loads division-related data from S3 into DuckDB for processing. This includes data about divisions, division formats,
    and division curators. The function sets up the DuckDB connection, configures S3 access, and loads several datasets
    into DuckDB tables.

    Parameters:
        data_interval_end (pendulum.DateTime): The end date for the current data processing interval.
        ti (TaskInstance): Airflow's TaskInstance object, used for XCom pull to fetch keys of S3 objects.

    Returns:
        None

    Raises:
        duckdb.DuckDBError: If there's an issue with SQL command execution or database interactions.
        IOError: If there are problems accessing or reading from S3.
    """
    conn = duckdb.connect(DUCKDB_FILE)

    division_s3_key = ti.xcom_pull(task_ids="extract_division_raw", key="return_value")

    division_old_s3_key = f"{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}/{S3_FOLDER}/division_old.csv"

    division_format_s3_key = ti.xcom_pull(
        task_ids="extract_division_format_raw", key="return_value"
    )
    division_curator_s3_key = ti.xcom_pull(
        task_ids="extract_division_curator_raw", key="return_value"
    )

    conn.sql(
        f"CREATE OR REPLACE TABLE division_old AS SELECT * FROM read_csv('s3://{BUCKET_NAME}/{division_old_s3_key}')"
    )

    conn.sql(
        f"CREATE OR REPLACE TABLE division_raw AS SELECT * FROM read_parquet('s3://{BUCKET_NAME}/{division_s3_key}')"
    )

    conn.sql(
        f"CREATE OR REPLACE TABLE division_format_raw AS SELECT * FROM read_parquet('s3://{BUCKET_NAME}/{division_format_s3_key}')"
    )

    conn.sql(
        f"CREATE OR REPLACE TABLE division_curator_raw AS SELECT * FROM read_parquet('s3://{BUCKET_NAME}/{division_curator_s3_key}')"
    )

    conn.sql(
        f"CREATE OR REPLACE TABLE division_coordinate AS SELECT * FROM read_csv('s3://{INFO_BUCKET_NAME}/coordinates.csv')"
    )


@task
def transform_division():
    """
    Transforms raw division data into a structured format suitable for analysis and storage. This transformation
    includes joining raw division data with format and curator information, enriching the divisions with additional
    descriptive data, and preparing the data for dimensional modeling in data warehousing.
    """
    conn = duckdb.connect(DUCKDB_FILE)

    conn.sql(
        f"""CREATE OR REPLACE TABLE division AS
            SELECT
                d._IDRRef AS id,
                d._ParentIDRRef AS parent_id,
                d._Description AS description,
                d.Префикс AS prefix,
                CASE d._Marked WHEN 1 THEN 'Деактивированный' WHEN 0 THEN 'Активный' END  AS activity_status,
                CASE WHEN TRIM(d.Адрес)='' THEN '{EMPTY_NULL_PLACEHOLDER}' ELSE d.Адрес END AS address,
                COALESCE(f._Description,'{EMPTY_NULL_PLACEHOLDER}') AS format,
                COALESCE(CASE WHEN TRIM(c._Description)='' THEN NULL ELSE c._Description END,'{EMPTY_NULL_PLACEHOLDER}') AS curator,
                d._Code AS code,
                CAST(d.SHOPINDEX AS INTEGER) AS shop_index,
                d.КодДляОтчетов AS report_code,
                d.ТипЦенРеализации_ID AS price_type_selling_id,
                d.ТипЦенЗакупки_ID AS price_type_buying_id,
                d.Город_ID AS city_id,
                d.Регион_ID AS region_id,
                g.X AS geocoord_x,
                g.Y AS geocoord_y,
                d.ПлощадьОбщая AS area_total,
                d.ПлощадьТорговогоЗала AS area_trade_hall,
                d.ПлощадьСкладскихПомещений AS area_warehouses,
                d.ПлощадьПредКассовойЗоны as area_pre_cachier_zone,
                d.ПлощадьХозЧасти AS area_administrative_part
            FROM division_raw d
            LEFT JOIN division_format_raw f ON f._IDRRef=d.ФорматМаркета_ID

            LEFT JOIN division_curator_raw c on c._IDRRef=d.Куратор_ID

            LEFT JOIN division_coordinate g ON g.DivisionID=d._IDRRef

        """
    )


@task
def division_scd(
    data_interval_start: pendulum.DateTime,
    data_interval_end: pendulum.DateTime,
    ti: TaskInstance,
):
    """
    Implements Slowly Changing Dimension (SCD) logic for division data. This involves detecting new and updated rows,
    and managing historical records within the dataset. The function adjusts 'start_date' and 'end_date' fields to reflect
    the valid time range for each division record.
    """

    conn = duckdb.connect(DUCKDB_FILE)

    # getting new rows
    conn.sql(
        """
    CREATE OR REPLACE TABLE division_new_rows AS
    (
    SELECT 
        id                      ,
        parent_id               ,
        description             ,
        prefix                  ,
        activity_status         ,
        address                 ,
        format                  ,
        curator                 ,
        code                    ,
        shop_index              ,
        report_code             ,
        price_type_selling_id   ,
        price_type_buying_id    ,
        city_id                 ,
        region_id               ,
        geocoord_x              ,
        geocoord_y              ,
        area_total              ,
        area_trade_hall         ,
        area_warehouses         ,
        area_pre_cachier_zone   ,
        area_administrative_part
    FROM division
    EXCEPT
    SELECT 
        id                      ,
        parent_id               ,
        description             ,
        prefix                  ,
        activity_status         ,
        address                 ,
        format                  ,
        curator                 ,
        code                    ,
        shop_index              ,
        report_code             ,
        price_type_selling_id   ,
        price_type_buying_id    ,
        city_id                 ,
        region_id               ,
        geocoord_x              ,
        geocoord_y              ,
        area_total              ,
        area_trade_hall         ,
        area_warehouses         ,
        area_pre_cachier_zone   ,
        area_administrative_part
    FROM division_old
    )
    """
    )

    # getting updated(changed) rows
    conn.sql(
        """
    CREATE OR REPLACE TABLE division_updated_rows AS
    (
    SELECT 
        id                      ,
        parent_id               ,
        description             ,
        prefix                  ,
        activity_status         ,
        address                 ,
        format                  ,
        curator                 ,
        code                    ,
        shop_index              ,
        report_code             ,
        price_type_selling_id   ,
        price_type_buying_id    ,
        city_id                 ,
        region_id               ,
        geocoord_x              ,
        geocoord_y              ,
        area_total              ,
        area_trade_hall         ,
        area_warehouses         ,
        area_pre_cachier_zone   ,
        area_administrative_part
    FROM division_old
    EXCEPT 
    SELECT 
        id                      ,
        parent_id               ,
        description             ,
        prefix                  ,
        activity_status         ,
        address                 ,
        format                  ,
        curator                 ,
        code                    ,
        shop_index              ,
        report_code             ,
        price_type_selling_id   ,
        price_type_buying_id    ,
        city_id                 ,
        region_id               ,
        geocoord_x              ,
        geocoord_y              ,
        area_total              ,
        area_trade_hall         ,
        area_warehouses         ,
        area_pre_cachier_zone   ,
        area_administrative_part
    FROM division
    )
    """
    )

    # if table in dwh is empty fill it with data_interval_start (1970-1-1) which is minimum possible date in clickhouse
    count_old = conn.sql("SELECT COUNT(*) FROM division_old").fetchone()[0]
    if count_old == 0:
        data_interval_start = pendulum.DateTime(1970, 1, 1)

    # for new rows set start date to today
    conn.sql(
        f"ALTER TABLE division_new_rows ADD COLUMN start_date Date DEFAULT '{data_interval_start.to_date_string()}'"
    )

    # for new rows set end_date to the maximum possible date in clickhouse
    conn.sql(
        "ALTER TABLE division_new_rows ADD COLUMN end_date Date DEFAULT '2149-06-06'"
    )

    # for new rows set is_current to 'Текущий'
    conn.sql(
        "ALTER TABLE division_new_rows ADD COLUMN is_current String DEFAULT 'Текущий'"
    )

    conn.sql("LOAD httpfs;")

    # push new rows to s3
    filename = "division_new_rows.parquet"
    s3_key = f"{BUCKET_NAME}/{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}/{S3_FOLDER}/{filename}"
    conn.sql(f"COPY division_new_rows TO 's3://{s3_key}';")
    ti.xcom_push(key="s3_key", value=s3_key)

    # push updated(changed rows) to s3
    updated_filename = "division_updated_rows.parquet"
    updated_s3_key = f"{BUCKET_NAME}/{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}/{S3_FOLDER}/{updated_filename}"
    conn.sql(f"COPY division_updated_rows TO 's3://{updated_s3_key}';")
    ti.xcom_push(key="updated_s3_key", value=updated_s3_key)


@task
def remove_temp_files():
    os.remove(DUCKDB_FILE)


@dag(
    default_args={
        "owner": "ubaitur5",
        "on_failure_callback": send_error_message_telegram,
    },
    schedule_interval="@daily",
    template_searchpath=["/opt/airflow/dags/include/sql_files/"],
    doc_md=doc_md,
    start_date=pendulum.DateTime(2024, 7, 23),
    tags=["etl", "dimensions"],
    catchup=False,
)
def division():

    extract_division_raw = SqlToS3OperatorImproved(
        task_id="extract_division_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query="""
        SELECT 
            CONVERT(NCHAR(34),_IDRRef,1) AS _IDRRef,
            CONVERT(NCHAR(34),_ParentIDRRef,1) AS _ParentIDRRef,
            _Code,
            _Description,
            Префикс,
            Адрес,
            CONVERT(NCHAR(34),ФорматМаркета_ID,1) AS ФорматМаркета_ID,
            CONVERT(NCHAR(34),Куратор_ID,1) AS Куратор_ID,
            CONVERT(int,_Marked) AS _Marked,
            ПлощадьОбщая,
            ПлощадьТорговогоЗала,
            ПлощадьХозЧасти,
            ПлощадьСкладскихПомещений,
            ПлощадьПредКассовойЗоны,
            КодДляОтчетов,
            CONVERT(NCHAR(34),ТипЦенРеализации_ID,1) AS ТипЦенРеализации_ID,
            CONVERT(NCHAR(34),ТипЦенЗакупки_ID,1) AS ТипЦенЗакупки_ID,
            CONVERT(NCHAR(34),Город_ID,1) AS Город_ID,
            CONVERT(NCHAR(34),Регион_ID,1) AS Регион_ID,
            SHOPINDEX
        FROM vw_ПодразделенияКомпании
        """,
        s3_bucket=BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="division_raw.parquet",
        replace=True,
        aws_conn_id=S3_CONN_ID,
        file_format="parquet",
        pd_kwargs={"index": False},  # pandas parameters to pass into .to_parquet()
    )

    extract_division_format_raw = SqlToS3OperatorImproved(
        task_id="extract_division_format_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query="""
        SELECT 
            CONVERT(nchar(34),_IDRRef,1) AS _IDRRef,
            _Description
        FROM vw_ФорматыМаркетов
        """,
        s3_bucket=BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="market_format_raw.parquet",
        replace=True,
        aws_conn_id=S3_CONN_ID,
        file_format="parquet",
        pd_kwargs={"index": False},  # pandas parameters to pass into .to_parquet()
    )

    extract_division_curator_raw = SqlToS3OperatorImproved(
        task_id="extract_division_curator_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query="""
        SELECT 
            CONVERT(nchar(34),_IDRRef,1) AS _IDRRef,
            _Description
        FROM vw_КураторыПодразделений
        """,
        s3_bucket=BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="trademarks_raw.parquet",
        replace=True,
        aws_conn_id=S3_CONN_ID,
        file_format="parquet",
        pd_kwargs={"index": False},  # pandas parameters to pass into .to_parquet()
    )

    extract_division_old = ClickHouseOperator(
        task_id="extract_division_old",
        database="dwh",
        settings={"format_csv_null_representation": ""},
        sql=(
            f"""
            INSERT INTO FUNCTION
            s3(
                '{{{{ conn.minio_s3.extra_dejson.endpoint_url_for_writing }}}}/{BUCKET_NAME}/{{{{data_interval_end.year}}}}/{{{{data_interval_end.month}}}}/{{{{data_interval_end.day}}}}/{S3_FOLDER}/division_old.csv',
                '{{{{ conn.minio_s3.extra_dejson.aws_access_key_id}}}}',
                '{{{{ conn.minio_s3.extra_dejson.aws_secret_access_key}}}}',
                'CSVWithNames'
                )
            SELECT 
                id                      ,
                parent_id               ,
                description             ,
                prefix                  ,
                activity_status         ,
                address                 ,
                format                  ,
                curator                 ,
                code                    ,
                shop_index              ,
                report_code             ,
                price_type_selling_id   ,
                price_type_buying_id    ,
                city_id                 ,
                region_id               ,
                geocoord_x              ,
                geocoord_y              ,
                area_total              ,
                area_trade_hall         ,
                area_warehouses         ,
                area_pre_cachier_zone   ,
                area_administrative_part

            FROM division
            WHERE is_current='Текущий'
            SETTINGS s3_create_new_file_on_insert = 1,s3_truncate_on_insert=1
            """,
            # result of the last query is pushed to XCom
        ),
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    load_division = ClickHouseOperator(
        task_id="load_division",
        database="dwh",
        sql=(
            """

            INSERT INTO division
            (
                id                      ,
                parent_id               ,
                description             ,
                prefix                  ,
                activity_status         ,
                address                 ,
                format                  ,
                curator                 ,
                code                    ,
                shop_index              ,
                report_code             ,
                price_type_selling_id   ,
                price_type_buying_id    ,
                city_id                 ,
                region_id               ,
                geocoord_x              ,
                geocoord_y              ,
                area_total              ,
                area_trade_hall         ,
                area_warehouses         ,
                area_pre_cachier_zone   ,
                area_administrative_part,
                start_date,
                end_date,
                is_current
            )
            SELECT 
                id                      ,
                parent_id               ,
                description             ,
                prefix                  ,
                activity_status         ,
                address                 ,
                format                  ,
                curator                 ,
                code                    ,
                shop_index              ,
                report_code             ,
                price_type_selling_id   ,
                price_type_buying_id    ,
                city_id                 ,
                region_id               ,
                geocoord_x              ,
                geocoord_y              ,
                area_total              ,
                area_trade_hall         ,
                area_warehouses         ,
                area_pre_cachier_zone   ,
                area_administrative_part,
                start_date,
                end_date,
                is_current

            FROM  s3(
                '{{conn.minio_s3.extra_dejson.endpoint_url }}/{{ti.xcom_pull(task_ids='division_scd',key='s3_key')}}',
                'parquet'
                );
            """,
            # result of the last query is pushed to XCom
        ),
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    update_division = ClickHouseOperator(
        task_id="update_division",
        database="dwh",
        sql=(
            """
            ALTER TABLE division
            UPDATE end_date='{{data_interval_start|ds}}',is_current='Исторический' WHERE id IN (SELECT  id FROM s3(
                            '{{conn.minio_s3.extra_dejson.endpoint_url }}/{{ti.xcom_pull(task_ids='division_scd',key='updated_s3_key')}}',
                            'parquet'
                            )) AND is_current = 'Текущий'
            """,
            # result of the last query is pushed to XCom
        ),
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    (
        [
            extract_division_raw,
            extract_division_curator_raw,
            extract_division_format_raw,
            extract_division_old,
        ]
        >> from_s3_to_duckdb()
        >> transform_division()
        >> division_scd()
        >> update_division
        >> load_division
        >> remove_temp_files()
    )


division()
