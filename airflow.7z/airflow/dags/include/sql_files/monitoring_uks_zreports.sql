SELECT 
    CAST(SDATE AS Date) AS [Date],
	shopindex AS [SHOPINDEX],
    cashnumber AS [CASHNUMBER],
    znumber AS [ZNUMBER],
    COUNT(DISTINCT CHECKNUMBE) AS ChequeCount,
    SUM(TotalCur) AS ChequeSum
FROM CASHSAIL WITH (NOLOCK)
WHERE CAST(sdate AS DATE) BETWEEN ?
    AND ?
    AND [shopindex]=?
GROUP BY shopindex,
        cashnumber,
        znumber,
        CAST(SDATE AS Date)
ORDER BY Date,
         cashnumber,
         znumber