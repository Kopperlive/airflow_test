SELECT
	  A._IDRRef
	, DATEADD(YEAR, -2000, A.[_Date_Time]) AS [_Date_Time]
	, A._Number
	, A.Автор_ID
	, A.ПодразделениеКомпании_ID
	, A.Комментарий
	, A.СкладКомпании_ID
	, A.ТипЦен_ID
	, A.ХозОперация_ID
	, A.СтатьяПричиныПересортицы_ID
	, B.НоменклатураПриход_ID
	, B.НоменклатураРасход_ID 
	, B.ЕдиницаИзмеренияПриход_ID
	, B.ЕдиницаИзмеренияРасход_ID
	, КоличествоПриход
	, КоличествоРасход
	, ЦенаРозничнаяПриход		
	, ЦенаРозничнаяРасход		
	, СуммаРозничнаяПриход		
	, СуммаРозничнаяРасход		
	, ПонижениеСортности
FROM vw_ПересортицаТоваров A WITH (NOLOCK)
	INNER JOIN vw_ПересортицаТоваров_Товары B WITH (NOLOCK)
		ON A._IDRRef = B.Ссылка
	WHERE A._Posted = 0x01 -- Только проведенные документы
		AND A._Marked = 0x00 -- Только не удалённые документы
		-- Ежедневное обновление данных за предыдущий и текущий месяц
		AND A._Date_Time >= '{{get_data_interval_start(data_interval_end).add(years=2000) | ds_nodash}}' AND A._Date_Time < '{{data_interval_end.add(years=2000) | ds_nodash}}'

	-- AND DATEADD(YEAR, -2000, CONVERT(DATE, _Date_Time)) >= '{{get_data_interval_start(data_interval_end)}}'
    -- AND DATEADD(YEAR, -2000, CONVERT(DATE, _Date_Time)) < '{{data_interval_end}}'

    -- Первичная выгрузка всех данных с августа 2023
    -- AND DATEADD(YEAR, -2000, CONVERT(DATE, _Date_Time)) >= '2023-08-01 00:00:00.000'
