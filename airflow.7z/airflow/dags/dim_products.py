import pendulum
from airflow.decorators import dag, task_group
from airflow.operators.bash import BashOperator
from common_utils.etl_tasks import create_or_replace_table, dbt_build
from common_utils.telegram_utils import send_error_message_telegram
from custom_operators.s3tosql import SqlToS3OperatorImproved

doc_md = ""

# S3 stuff
S3_CONN_ID = "minio_s3"
S3_BUCKET_NAME = "etl-data-files-test"
S3_FOLDER = "dimensions"

AR_TRADE_CONN_ID = "nsp_ar_trade"
DWH_CONN_ID = "clickhouse_dwh"


@task_group
def extract():

    extract_essential_products = SqlToS3OperatorImproved(
        task_id="extract_essential_products",
        sql_conn_id=AR_TRADE_CONN_ID,
        query="""
        SELECT
            GR._IDRRef
            , POD.Подразделение_ID
            , PR.Номенклатура_ID
            , GR._Description
        FROM vw_СлужебныеСпискиТоваровИКонтрагентов GR WITH(NOLOCK) 
        INNER JOIN vw_СлужебныеСпискиТоваровИКонтрагентов_Товары PR WITH(NOLOCK)
            ON GR._IDRRef=PR.Ссылка
        LEFT OUTER JOIN vw_СлужебныеСпискиТоваровИКонтрагентов_Подразделения POD WITH(NOLOCK)
                ON GR._IDRRef = POD.Ссылка
        WHERE GR.ID = 100 --Видимо обозначение что это список топ100
            AND GR._Marked=0x00
        """,
        s3_bucket=S3_BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="essential_products_raw.parquet",
        replace=True,
        aws_conn_id=S3_CONN_ID,
        file_format="parquet",
        pd_kwargs={"index": False},
    )

    extract_products_raw = SqlToS3OperatorImproved(
        task_id="extract_products_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query="""
        SELECT 
            _IDRRef
            , _ParentIDRRef
            , _Code
            , _Description
            , НаименованиеПолное
            , Наименование1
            , Артикул
            , _Folder
            , _Marked
            , Халал
            , Импорт
            , ЭтоСертификат
            , СтатусНоменклатуры_ID
            , СрокВозврата
            , ТипНоменклатуры_ID
            , СтранаПроисхождения_ID
            , ТоварнаяМарка_ID
            , ЦеновойСегмент_ID
            , ЭтоВозвратныйТовар
            , ВесНетто
            , ВесБрутто
            , КоличествоВупаковке
        FROM vw_Номенклатура
        """,
        s3_bucket=S3_BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="products_raw.parquet",
        replace=True,
        aws_conn_id=S3_CONN_ID,
        file_format="parquet",
        pd_kwargs={"index": False},
    )

    extract_price_segments_raw = SqlToS3OperatorImproved(
        task_id="extract_price_segments_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query="""
        SELECT 
            _IDRRef
            , _Description
        FROM vw_ЦеновыеСегменты
        """,
        s3_bucket=S3_BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="price_segments_raw.parquet",
        replace=True,
        aws_conn_id=S3_CONN_ID,
        file_format="parquet",
        pd_kwargs={"index": False},
    )

    extract_trademarks_raw = SqlToS3OperatorImproved(
        task_id="extract_trademarks_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query="""
        SELECT 
            _IDRRef
            , _Description
        FROM vw_ТоварныеМарки
        """,
        s3_bucket=S3_BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="trademarks_raw.parquet",
        replace=True,
        aws_conn_id=S3_CONN_ID,
        file_format="parquet",
        pd_kwargs={"index": False},
    )

    extract_product_statuses_raw = SqlToS3OperatorImproved(
        task_id="extract_product_statuses_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query="""
        SELECT 
            _IDRRef
            , _Description
            , Описание
        FROM vw_СтатусыНоменклатуры
        """,
        s3_bucket=S3_BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="statuses_raw.parquet",
        replace=True,
        aws_conn_id=S3_CONN_ID,
        file_format="parquet",
        pd_kwargs={"index": False},
    )

    extract_product_types_raw = SqlToS3OperatorImproved(
        task_id="extract_product_types_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query="""
        SELECT 
            _IDRRef
            , _Description
        FROM vw_ТипыНоменклатуры
        """,
        s3_bucket=S3_BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="products_types_raw.parquet",
        replace=True,
        aws_conn_id=S3_CONN_ID,
        file_format="parquet",
        pd_kwargs={"index": False},
    )

    extract_countries_raw = SqlToS3OperatorImproved(
        task_id="extract_countries_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query="""
        SELECT
            _IDRRef
            , _Marked
            , _Code
            , _Description
        FROM vw_КлассификаторСтранМира
        """,
        s3_bucket=S3_BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="countries_raw.parquet",
        replace=True,
        aws_conn_id=S3_CONN_ID,
        file_format="parquet",
        pd_kwargs={"index": False},
    )


@task_group
def load():
    create_or_replace_table(
        conn_id=DWH_CONN_ID,
        table_name="products_raw",
        s3_bucket=S3_BUCKET_NAME,
        s3_key="{{ti.xcom_pull(key='return_value',task_ids='extract.extract_products_raw')}}",
    )
    create_or_replace_table(
        conn_id=DWH_CONN_ID,
        table_name="trademarks_raw",
        s3_bucket=S3_BUCKET_NAME,
        s3_key="{{ti.xcom_pull(key='return_value',task_ids='extract.extract_trademarks_raw')}}",
    )
    create_or_replace_table(
        conn_id=DWH_CONN_ID,
        table_name="price_segments_raw",
        s3_bucket=S3_BUCKET_NAME,
        s3_key="{{ti.xcom_pull(key='return_value',task_ids='extract.extract_price_segments_raw')}}",
    )
    create_or_replace_table(
        conn_id=DWH_CONN_ID,
        table_name="product_statuses_raw",
        s3_bucket=S3_BUCKET_NAME,
        s3_key="{{ti.xcom_pull(key='return_value',task_ids='extract.extract_product_statuses_raw')}}",
    )
    create_or_replace_table(
        conn_id=DWH_CONN_ID,
        table_name="countries_raw",
        s3_bucket=S3_BUCKET_NAME,
        s3_key="{{ti.xcom_pull(key='return_value',task_ids='extract.extract_countries_raw')}}",
    )
    create_or_replace_table(
        conn_id=DWH_CONN_ID,
        table_name="product_types_raw",
        s3_bucket=S3_BUCKET_NAME,
        s3_key="{{ti.xcom_pull(key='return_value',task_ids='extract.extract_product_types_raw')}}",
    )

    create_or_replace_table(
        conn_id=DWH_CONN_ID,
        table_name="essential_products_raw",
        s3_bucket=S3_BUCKET_NAME,
        s3_key="{{ti.xcom_pull(key='return_value',task_ids='extract.extract_essential_products')}}",
    )


@dag(
    default_args={
        "owner": "ubaitur5",
        "on_failure_callback": send_error_message_telegram,
    },
    schedule_interval="0 1-11 * * *",
    template_searchpath=["/opt/airflow/dags/include/sql_files/"],
    start_date=pendulum.DateTime(2024, 7, 23),
    doc_md=doc_md,
    tags=["etl", "dimensions"],
    catchup=False,
)
def dim_products():

    extract() >> load() >> dbt_build(indirect_selection="buildable")


dim_products()
