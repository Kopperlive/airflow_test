WITH source AS (

    SELECT * FROM {{ source('raw_dbt','sales_raw') }}

)

, renamed AS (

    SELECT
        --dates
        CAST("_Period" AS Date) AS date

        --ids
        , CAST({{ transform_hex_to_uuid('"ПодразделениеКомпании_ID"') }} AS LowCardinality (UUID)) AS division_id
        , CAST({{ transform_hex_to_uuid('"СкладКомпании_ID"') }} AS LowCardinality (UUID)) AS warehouse_id
        , CAST({{ transform_hex_to_uuid('"Поставщик_ID"') }} AS LowCardinality (UUID)) AS contragent_id
        , {{ transform_hex_to_uuid('"Номенклатура_ID"') }} AS product_id

        , CAST({{ transform_hex_to_uuid('"ХозОперация_ID"') }} AS LowCardinality (UUID)) AS operation_id
        , CAST({{ transform_hex_to_uuid('"ДоговорВзаиморасчетов_ID"') }} AS LowCardinality (UUID)) AS contragent_settlement_id
        , CAST({{ transform_hex_to_uuid('"Покупатель_ID"') }} AS LowCardinality (UUID)) AS buyer_id
        , CAST({{ transform_hex_to_uuid('"СтатусПартии_ID"') }} AS LowCardinality (UUID)) AS supply_type_id
        , CAST({{ transform_hex_to_uuid('"СтавкаНДС_ID"') }} AS LowCardinality (UUID)) AS vat_rate_id

        --boolean
        , {{ transform_binary_to_boolean('"БезналичныйРасчет"') }} AS is_cashless_payment

        --values
        , {{ transform_decimal('"Количество"') }} AS quantity
        , {{ transform_decimal('"Сумма"') }} - amount_VAT AS amount
        , {{ transform_decimal('"СуммаНДС"') }} AS amount_VAT
        , {{ transform_decimal('"СуммаСкидки"') }} AS amount_discount
        , {{ transform_decimal('"Себестоимость"') }} AS cost_price
        , {{ transform_decimal('"СуммаНДСВходящий"') }} AS cost_price_VAT
    FROM source

)

SELECT * FROM renamed
