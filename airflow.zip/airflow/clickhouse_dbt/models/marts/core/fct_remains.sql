WITH source AS (

    SELECT * FROM {{ ref("int_remains_for_every_day") }}

)

, final AS (
    SELECT * FROM source
)


SELECT * FROM final
