import json

import numpy as np
import pandas as pd
import pendulum
import pyodbc
from airflow.decorators import dag, task, task_group
from airflow.exceptions import AirflowSkipException
from airflow.hooks.base import BaseHook
from airflow.models import Variable
from airflow.models.taskinstance import TaskInstance
from airflow.operators.python import get_current_context
from airflow.providers.microsoft.mssql.hooks.mssql import MsSqlHook
from airflow_clickhouse_plugin.hooks.clickhouse import ClickHouseHook
from common_utils.report.s3_utils import read_df_from_s3, save_df_to_s3
from common_utils.sql_utils import read_sql_file
from common_utils.telegram_utils import send_error_message_telegram
from custom_operators.s3tosql import SqlToS3OperatorImproved

# Queries used in report (all of them stored in include/sql_files)
QUERY_MARKET_SERVERS = "etl_uks_market_servers.sql"
QUERY_CHEQUES = "monitoring_uks_zreports.sql"
QUERY_AR_TRADE_ZREPORTS = "monitoring_ar_trade_zreports.sql"

# because we don't want to read it every time we query a market
QUERY_CHEQUES_STRING = read_sql_file(QUERY_CHEQUES)


# S3 stuff
S3_CONN_ID = "minio_s3"
BUCKET_NAME = "monitoring"
REPORT_NAME = "monitoring_zreports_cassa"

# DB stuff
PROD_DWH_CONN_ID = "clickhouse_dwh"
AR_TRADE_CONN_ID = "nsp_ar_trade"


UID = Variable.get("Reader")
PWD = Variable.get("Reader_password")


# Get data from last N days
DATE_RANGE = 31


def connect_pyodbc(server="SRV-TEST-DWH", db="DWH"):
    MS_CONN_STR = f"DRIVER=ODBC Driver 17 for SQL Server;SERVER={server};DATABASE={db};PORT=1433;UID={UID};PWD={PWD}"
    conn = pyodbc.connect(MS_CONN_STR, timeout=10)
    return conn


def _execute_query_to_df_with_hook(
    query: str, MSSQL_CONN_ID=AR_TRADE_CONN_ID, params: tuple = None
) -> pd.DataFrame:
    """Helper function: execute query, return result as a Pandas Dataframe"""
    hook = MsSqlHook(mssql_conn_id=MSSQL_CONN_ID)
    conn = hook.get_conn()
    df = pd.read_sql(query, conn, params=params)
    return df


def _execute_query_to_df_with_pyodbc(
    query: str, ip: str, db: str, params: tuple = None
) -> pd.DataFrame:
    MS_CONN_STR = f"DRIVER=ODBC Driver 17 for SQL Server;SERVER={ip};PORT=1433;UID={UID};PWD={PWD};Database={db}"

    conn = pyodbc.connect(MS_CONN_STR, timeout=10)

    print("Params:", params)

    df = pd.read_sql(
        query,
        conn,
        params=params,
    )

    conn.close()

    return df


@task()
def extract_list_of_market_servers(
    data_interval_end: pendulum.DateTime, ti: TaskInstance
):
    """
    Extracts a list of market servers from a SQL database, modifies it by removing servers that have migrated to a unified DNS (UKS_DNS),
    and appends this unified DNS to the list. This task then saves the modified list to an S3 bucket and pushes the file's S3 key to XCom
    for subsequent use in other tasks.

    The function performs several steps:
    1. Extracts the initial list of market servers using a predefined SQL query from a file.
    2. Appends a DataFrame with the unified DNS for migrated markets.
    3. Queries for shop indexes that have been migrated to the unified DNS in the last 5 days.
    4. Removes any market servers from the original list that are now part of the migrated DNS.
    5. Concatenates the DNS for migrated markets with the remaining market server list.
    6. Saves the final DataFrame as a CSV file to an S3 bucket.
    7. Pushes the S3 key of the saved file to XCom.

    Parameters:
        data_interval_end (pendulum.DateTime): The end date for the data interval, used to timestamp the saved file.
        ti (TaskInstance): Airflow's TaskInstance object, used to perform XCom operations within the task.

    Returns:
        dict: A dictionary representation of the DataFrame containing the final list of market servers,
              where each key represents a column, and the corresponding value is a list of data points for that column.
              This is used to facilitate the creation of dynamically mapped tasks.

    Side Effects:
        - Saves a CSV file to an S3 bucket.
        - Pushes the S3 key of the saved file to Airflow's XCom, which can be used by subsequent tasks.
        - The DataFrame to dictionary conversion helps in setting up dynamic tasks based on the list of market servers.

    Example of use:
        - This task is typically part of an Airflow DAG that handles ETL processes for retail market data,
          where dynamic task mapping is required based on the list of active and recently migrated market servers.
    """
    query = read_sql_file(QUERY_MARKET_SERVERS)
    df_market_servers = _execute_query_to_df_with_hook(query, AR_TRADE_CONN_ID)

    print(df_market_servers["ConnectionString"])

    # Getting IP of markets from Connection string
    df_market_servers["market_ip"] = (
        df_market_servers["ConnectionString"].str.split(pat="=").str[-1]
    )

    df_market_servers["uks_db"] = (
        df_market_servers["ConnectionString"]
        .str.split(pat="=")
        .str[-2]
        .str.split(";")
        .str[0]
    )
    df_market_servers.drop(["ConnectionString"], axis=1, inplace=True)

    filename = "market_servers.csv"

    file_s3_key = save_df_to_s3(
        df=df_market_servers,
        aws_conn_id=S3_CONN_ID,
        bucket_name=BUCKET_NAME,
        report_name=REPORT_NAME,
        time_granularity="hourly",
        filename=filename,
        data_interval_end=data_interval_end,
    )

    # Push the file's S3 key to XCom for further use
    ti.xcom_push(key="file_s3_key", value=file_s3_key)

    # converting our dataframe to dictionary so we can create dynamic mapped tasks over this dataframe,particulary for task.expand_kwagrs()
    return df_market_servers.to_dict("records")


@task_group(group_id="extract_load_from_markets")
def extract_load(market_ip: str, market_code: str, shop_index: str, uks_db: str):
    """
    IMPORTANT: why am i returning values from tasks,instead of doing xcom_push?
        It is because all tasks in this task group are  dynamic mapped tasks,it means that when I need to do xcom_pull, I will need to do it like this:
            file_s3_key = ti.xcom_pull(key='file_s3_key',task_ids='extract_data_from_markets') -- it will return not one value but list of all values generated by this mapped task,e.g.
                                                                            ['2024/6/1/Ф01.csv','2024/6/1/Ф02.csv','2024/6/1/Ф03.csv'....]



    The reason I placed 4 tasks in one group instead of separating into two groups (extract,load) is because in this case second group(load) will only start
    after all mapped tasks in extract group finished.

    A task group that orchestrates the extraction and loading of market data from different market servers to a central data warehouse and then transfers this data to an SMB location.

    This group consists of a sequence of tasks that perform the following operations:
    1. Extract data from an external market server's database using a specified SQL file.
    2. Save the extracted data to an S3 bucket.
    3. Transfer the saved data from the S3 bucket to an SMB server using FTP.
    4. Perform a bulk insert of the data from the SMB server into a SQL Server database table.
    5. Clean up by deleting the transferred file from the SMB server.

    Parameters:
        market_ip (str): IP address of the market server from which data is to be extracted.
        market_code (str): A unique code identifying the market, which is used for naming the output files and as an identifier in logs and other tracking.
        divisionIDRef (str): A division identifier that is likely used in the SQL query to filter data specific to a division.

    The task group facilitates tracking and management of data flow from individual markets by using dynamic mapping for each market server. This setup allows for scalable and manageable ETL processes for multiple market servers simultaneously, improving efficiency and error handling in data transfer operations.

    Usage:
        The `extract_load` task group is used within an Airflow DAG to manage the data extraction and loading process from multiple market servers. It is dynamically expanded based on the list of market servers extracted by another task in the DAG, ensuring each market's data is handled individually.

    Returns:
        None: This task group orchestrates other tasks but does not return any values directly. It handles data flow and management internally within the defined tasks.
    """

    @task(
        map_index_template="{{ my_custom_map_index }}",
        retries=3,  # TODO: SET TO 3
        retry_delay=pendulum.duration(minutes=3),
        # retry_exponential_backoff=True,  # enable  auto increasing retry_delay,it will be increased by two times each time it runs,for example, 1st retry: 1h,2nd retry: 2h, 3rd retry:4h
    )
    def extract_data_from_markets(
        market_ip: str,
        market_code: str,
        uks_db: str,
        shop_index: str,
        data_interval_end: pendulum.DateTime,
    ):
        """
        Extracts data from an external market database, saves it to an S3 bucket, and returns the S3 key for further operations.

        The function reads a SQL query from a file, executes it against a specified market's database server, fetches the results, and stores them as a CSV file in an S3 bucket.

        Parameters:
            sql_file (str): The path to the SQL file containing the query to execute.
            market_ip (str): The IP address of the market server from which data will be extracted.
            market_code (str): A unique code identifying the market, used in file naming.
            divisionIDRef (str)
            data_interval_end (pendulum.DateTime): The end of the data interval for which the data is fetched, used for timestamping the stored file.

        Returns:
            str: The S3 key under which the extracted data file is saved. This key is used for subsequent data transfer tasks.

        """

        # Setting up map_index to market code and ip(so we can observe from web UI which mapped task is running )
        context = get_current_context()
        custom_map_index = f"{market_code}:{market_ip}:{uks_db}"
        context["my_custom_map_index"] = custom_map_index

        df_cheques = _execute_query_to_df_with_pyodbc(
            QUERY_CHEQUES_STRING,
            market_ip,
            uks_db,
            params=(
                data_interval_end.subtract(days=DATE_RANGE).to_date_string(),
                data_interval_end.subtract(days=1).to_date_string(),
                shop_index,
            ),
        )

        if df_cheques.shape[0] == 0:
            raise AirflowSkipException("Empty cheques data!")

        filename = f"{uks_db}_cheques.csv"
        file_s3_key = save_df_to_s3(
            df=df_cheques,
            aws_conn_id=S3_CONN_ID,
            bucket_name=BUCKET_NAME,
            report_name=REPORT_NAME,
            time_granularity="hourly",
            filename=filename,
            data_interval_end=data_interval_end,
        )
        return file_s3_key

    @task
    def transform_missing_z_reports(
        market_s3_key: str,
        market_code: str,
        uks_db: str,
        ti: TaskInstance,
        data_interval_end: pendulum.DateTime,
    ):
        context = get_current_context()
        context["my_custom_map_index"] = market_code

        df_market = read_df_from_s3(
            aws_conn_id=S3_CONN_ID,
            bucket_name=BUCKET_NAME,
            file_s3_key=market_s3_key,
        )

        ar_trade_s3_key = ti.xcom_pull(
            task_ids="extract_ar_trade_zreports", key="return_value"
        )

        print("S3 Key:")
        print(ar_trade_s3_key)
        df_ar_trade = read_df_from_s3(
            aws_conn_id=S3_CONN_ID,
            bucket_name=BUCKET_NAME,
            file_s3_key=ar_trade_s3_key,
        )
        print(df_ar_trade)

        df_merged = df_market.merge(
            df_ar_trade,
            on=["ZNUMBER", "SHOPINDEX", "CASHNUMBER"],
            how="left",
            suffixes=("_uks", "_ar"),
        )

        df_missing_zreports = df_merged[
            (df_merged["ChequeCount_ar"].isna())
            | (df_merged["ChequeCount_ar"] != df_merged["ChequeCount_uks"])
        ]

        if df_missing_zreports.shape[0] == 0:
            raise AirflowSkipException("No missing z reports!")

        filename = f"{uks_db}_missing_z_reports.csv"
        file_s3_key = save_df_to_s3(
            df=df_missing_zreports,
            aws_conn_id=S3_CONN_ID,
            bucket_name=BUCKET_NAME,
            report_name=REPORT_NAME,
            time_granularity="hourly",
            filename=filename,
            data_interval_end=data_interval_end,
        )
        return file_s3_key

    @task
    def insert_to_clickhouse(db: str, result_s3_key: str):
        context = get_current_context()
        context["my_custom_map_index"] = db

        hook = ClickHouseHook(clickhouse_conn_id=PROD_DWH_CONN_ID)

        s3_hook = BaseHook.get_connection(conn_id=S3_CONN_ID)
        s3_hook_extra = s3_hook.extra
        s3_endpoint = json.loads(s3_hook_extra)["endpoint_url"]

        query = f"""
        INSERT INTO monitoring.z_reports (
                date
                , shop_index
                , cash_number
                , z_number
                , cheque_count_uks
                , cheque_count_ar
                , cheque_sum_uks
                , cheque_sum_ar
            )
            SELECT
                Date
                , SHOPINDEX
                , CASHNUMBER
                , ZNUMBER
                , ChequeCount_uks
                , ChequeCount_ar
                , ChequeSum_uks
                , ChequeSum_ar

            FROM s3(
                    '{s3_endpoint}/{BUCKET_NAME}/{result_s3_key}')
        """

        print("Executing query:\n", query)
        hook.execute(sql=query)

    market_s3_key = extract_data_from_markets(
        market_ip, market_code, uks_db, shop_index
    )
    missing_zreport_s3_key = transform_missing_z_reports(
        market_s3_key, market_code, uks_db
    )
    insert_to_clickhouse(uks_db, missing_zreport_s3_key)


@dag(
    default_args={
        "retries": 2,
        "retry_delay": pendulum.duration(minutes=1),
        "owner": "ubaitur5",
        "priority_weight": -5,
        "on_failure_callback": send_error_message_telegram,
    },
    schedule_interval="*/30 * * * *",
    start_date=pendulum.DateTime(2024, 5, 1),
    catchup=False,
    template_searchpath=[
        "/opt/airflow/dags/include/sql_files/"
    ],  # So we can just pass *.sql file name to MsSqlOperator instead of specifying full path
    tags=["uks", "monitoring"],
)
def monitoring_zreports_cassa():

    extract_ar_trade_zreports = SqlToS3OperatorImproved(
        task_id="extract_ar_trade_zreports",
        sql_conn_id=AR_TRADE_CONN_ID,
        query=QUERY_AR_TRADE_ZREPORTS,
        s3_bucket=BUCKET_NAME,
        report_name=REPORT_NAME,
        time_granularity="hourly",
        filename="AR_TRADE_Zreports.csv",
        params={"date_range": DATE_RANGE},
        replace=True,
        aws_conn_id=S3_CONN_ID,
        pd_kwargs={"index": False},  # pandas parameters to pass into .to_csv()
    )

    extract_list_servers = extract_list_of_market_servers()
    extract_ar_trade_zreports >> extract_list_servers

    # # creating dynamic mapping tasks(for every value from extract_list_servers it will run function extract_load)
    extract_load.expand_kwargs(extract_list_servers)


monitoring_zreports_cassa()
