WITH products AS (
    SELECT * FROM {{ref('vw_products')}}
),
divisions AS (
    SELECT * FROM {{ref('dim_divisions')}}
),
cheques AS (
    SELECT * FROM {{ source('uks','cheques') }}
)


SELECT
    c.date,
    d.curator AS curator_name,
    d.description AS division_name,
    p.first_category AS first_category,
    p.second_category AS second_category,
    p.third_category AS third_category,
    p.fourth_category AS fourth_category,
    p.fifth_category AS fifth_category,
    p.description AS product_name,
    c.id AS cheque_id,
    c.price_with_VAT,
    c.quantity,
    c.amount_with_VAT
FROM uks.cheques AS c
    INNER JOIN products AS p ON 
        (c.product_code = p.code)
    INNER JOIN divisions AS d ON 
        (d.shop_index = c.shop_index) AND (d.is_current = 1) AND (d.report_code NOT LIKE '%СП%')
