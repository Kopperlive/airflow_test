import os

import duckdb
import pendulum
from airflow.decorators import dag, task
from airflow.models.taskinstance import TaskInstance
from airflow_clickhouse_plugin.operators.clickhouse import ClickHouseOperator
from common_utils.telegram_utils import send_error_message_telegram
from constants.etl_constants import EMPTY_NULL_PLACEHOLDER_FOR_REFERENCES
from custom_operators.s3tosql import SqlToS3OperatorImproved
from duckdb.typing import BLOB, VARCHAR

doc_md = """
# ETL Dimensions Warehouse DAG Documentation

## Overview

The `warehouse` DAG is structured to extract, transform, and load (ETL) data related to warehouses into a data warehouse environment. It manages dimensions concerning warehouse attributes and relationships, effectively handling both data extraction from various sources and its subsequent transformation and integration into a data warehouse.

## DAG Configuration

- **Schedule**: Daily
- **Catchup**: False
- **Tags**: 'etl', 'dimensions'

## Tasks Overview

### extract_warehouse_raw

- **Operator**: `SqlToS3OperatorImproved`
- **Description**: Extracts raw warehouse data from the source system and stores it in S3 in parquet format.
- **Source**: Warehouse management system accessed via `AR_TRADE_CONN_ID`.

### extract_warehouse_old

- **Operator**: `ClickHouseOperator`
- **Description**: Retrieves the current state of warehouses marked as 'current' from the data warehouse to manage updates and ensure data continuity.
- **Database**: Utilizes `clickhouse_dwh` for operations.

### from_s3_to_duckdb

- **Function**: `from_s3_to_duckdb`
- **Description**: Loads data from S3 into DuckDB, setting up necessary configurations for data manipulation and further processing within DuckDB.

### transform_warehouse

- **Function**: `transform_warehouse`
- **Description**: Transforms and structures the raw warehouse data within DuckDB, including converting identifiers from binary to hexadecimal and normalizing various attributes.

### warehouse_scd

- **Function**: `warehouse_scd`
- **Description**: Manages Slowly Changing Dimensions (SCD) for warehouse data, tracking changes over time to maintain historical accuracy in the data warehouse.

### load_warehouse

- **Operator**: `ClickHouseOperator`
- **Description**: Loads the transformed warehouse data back into the data warehouse from S3, utilizing the transformed data stored in parquet files.

### update_warehouse

- **Operator**: `ClickHouseOperator`
- **Description**: Updates records in the data warehouse to reflect recent changes, marking old records as historical and updating end dates where necessary.

## Additional Details

- **Data Handling**: This DAG handles warehouse data with care to ensure data integrity and accuracy in the warehouse's representation within the data warehouse. The transformations and updates are designed to maintain a comprehensive history of changes without losing the context of any modifications.
- **Technology Stack**: Utilizes Airflow for orchestration, DuckDB for data processing, and ClickHouse for data storage, providing a robust system for ETL processes.
- **Security**: Implements secure data handling practices by configuring S3 access securely and ensuring that data transfer between systems is encrypted and managed through secure channels.


"""

# S3 stuff
S3_CONN_ID = "minio_s3"
BUCKET_NAME = "etl-data-files"
S3_FOLDER = "warehouse"

DUCKDB_FILE = "/tmp/warehouse.db"

AR_TRADE_CONN_ID = "nsp_ar_trade"


def binary_to_hex(binary_value):
    """
    Converts a binary value to a hexadecimal string representation. This utility function is useful for converting
    binary IDs from databases that do not handle binary data natively in queries.

    Parameters:
        binary_value (bytes): The binary value to be converted.

    Returns:
        str: A string representation of the hexadecimal value prefixed with '0x', or None if the input is None.

    Examples:
        >>> binary_to_hex(b'\x00\x01')
        '0x0001'
    """
    if binary_value is None:
        return None
    return "0x" + binary_value.hex().upper()


@task
def from_s3_to_duckdb(data_interval_end: pendulum.DateTime, ti: TaskInstance):
    """
    Retrieves warehouse-related data from S3 and loads it into DuckDB for further processing. This task pulls multiple
    datasets including the current state of warehouses and additional attributes from different S3 keys set in prior tasks.
    """

    conn = duckdb.connect(DUCKDB_FILE)

    warehouse_s3_key = ti.xcom_pull(
        task_ids="extract_warehouse_raw", key="return_value"
    )

    warehouse_old_s3_key = f"{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}/{S3_FOLDER}/warehouse_old.csv"

    conn.sql(
        f"CREATE OR REPLACE TABLE warehouse_raw AS SELECT * FROM read_parquet('s3://{BUCKET_NAME}/{warehouse_s3_key}')"
    )
    conn.sql(
        f"CREATE OR REPLACE TABLE warehouse_old AS SELECT * FROM read_csv('s3://{BUCKET_NAME}/{warehouse_old_s3_key}')"
    )
    conn.sql("SELECT * FROM warehouse_raw").show()


@task
def transform_warehouse():
    """
    Transforms raw warehouse data into a structured format suitable for data warehousing. This function enhances the raw
    data by converting binary fields to hexadecimal, normalizing descriptions, and linking related attributes like
    division and region IDs from separate tables.
    """

    conn = duckdb.connect(DUCKDB_FILE)

    conn.create_function("binary_to_hex", binary_to_hex, [BLOB], VARCHAR)
    conn.sql(
        f"""CREATE OR REPLACE TABLE warehouse AS

        SELECT 
            binary_to_hex(_IDRRef) AS id,
            binary_to_hex(_ParentIDRRef) AS parent_id,
            CASE binary_to_hex(_Marked) WHEN '0x01' THEN 'Деактивированный' ELSE 'Активный' END as activity_status,
            CASE binary_to_hex(_Folder)
                WHEN '0x01' THEN
                    'Строка'
                ELSE
                    'Папка' END as type,
            _Code AS code,
            TRIM(_Description) AS description,
            COALESCE(binary_to_hex(Подразделение_ID),'{EMPTY_NULL_PLACEHOLDER_FOR_REFERENCES}') AS division_id,
            COALESCE(binary_to_hex(Регион_ID),'{EMPTY_NULL_PLACEHOLDER_FOR_REFERENCES}') AS region_id
        from warehouse_raw
            
        """
    )


@task
def warehouse_scd(
    data_interval_start: pendulum.DateTime,
    data_interval_end: pendulum.DateTime,
    ti: TaskInstance,
):
    """
    Implements Slowly Changing Dimension (SCD) logic for warehouse data by managing how data updates between cycles are
    handled to maintain a historical record. New and updated records are identified, and their historical states are managed.
    """

    conn = duckdb.connect(DUCKDB_FILE)
    conn.sql(
        """
    CREATE OR REPLACE TABLE warehouse_new_rows AS
    (
    SELECT 
        id                  ,
        parent_id           ,
        activity_status     ,
        type                ,
        code                ,
        description         ,
        division_id         ,
        region_id   
    FROM warehouse
    EXCEPT
    SELECT 
        id                  ,
        parent_id           ,
        activity_status     ,
        type                ,
        code                ,
        description         ,
        division_id         ,
        region_id   
    FROM warehouse_old
    )
    """
    )

    conn.sql(
        """
    CREATE OR REPLACE TABLE warehouse_updated_rows AS
    (
    SELECT 
        id                  ,
        parent_id           ,
        activity_status     ,
        type                ,
        code                ,
        description         ,
        division_id         ,
        region_id   
    FROM warehouse_old
    EXCEPT 
    SELECT 
        id                  ,
        parent_id           ,
        activity_status     ,
        type                ,
        code                ,
        description         ,
        division_id         ,
        region_id   
    FROM warehouse
    )
    """
    )

    count_old = conn.sql("SELECT COUNT(*) FROM warehouse_old").fetchone()[0]
    if count_old == 0:
        data_interval_start = pendulum.DateTime(1970, 1, 1)

    conn.sql(
        f"ALTER TABLE warehouse_new_rows ADD COLUMN start_date Date DEFAULT '{data_interval_start.to_date_string()}'"
    )
    conn.sql(
        "ALTER TABLE warehouse_new_rows ADD COLUMN end_date Date DEFAULT '2149-06-06'"
    )
    conn.sql(
        "ALTER TABLE warehouse_new_rows ADD COLUMN is_current String DEFAULT 'Текущий'"
    )

    conn.sql("LOAD httpfs")
    filename = "warehouse_new_rows.parquet"
    s3_key = f"{BUCKET_NAME}/{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}/{S3_FOLDER}/{filename}"
    conn.sql(f"COPY warehouse_new_rows TO 's3://{s3_key}';")
    ti.xcom_push(key="s3_key", value=s3_key)

    updated_filename = "warehouse_updated_rows.parquet"
    updated_s3_key = f"{BUCKET_NAME}/{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}/{S3_FOLDER}/{updated_filename}"
    conn.sql(f"COPY warehouse_updated_rows TO 's3://{updated_s3_key}';")
    ti.xcom_push(key="updated_s3_key", value=updated_s3_key)


@task
def remove_temp_files():
    os.remove(DUCKDB_FILE)


@dag(
    default_args={
        "owner": "ubaitur5",
        "on_failure_callback": send_error_message_telegram,
    },
    schedule_interval="@daily",
    template_searchpath=["/opt/airflow/dags/include/sql_files/"],
    start_date=pendulum.DateTime(2024, 7, 23),
    doc_md=doc_md,
    tags=["etl", "dimensions"],
    catchup=False,
)
def warehouse():

    extract_warehouse_raw = SqlToS3OperatorImproved(
        task_id="extract_warehouse_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query="""
        SELECT 
            _IDRRef,
            _ParentIDRRef,
            _Marked,
            _Folder,
            _Code,
            _Description,
            Подразделение_ID,
            Регион_ID 
        FROM vw_СкладыКомпании 
        """,
        s3_bucket=BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="warehouse_raw.parquet",
        replace=True,
        aws_conn_id=S3_CONN_ID,
        file_format="parquet",
        pd_kwargs={"index": False},  # pandas parameters to pass into .to_parquet()
    )

    extract_warehouse_old = ClickHouseOperator(
        task_id="extract_warehouse_old",
        database="dwh",
        settings={"format_csv_null_representation": ""},
        sql=(
            f"""
            INSERT INTO FUNCTION
            s3(
                '{{{{ conn.minio_s3.extra_dejson.endpoint_url_for_writing }}}}/{BUCKET_NAME}/{{{{data_interval_end.year}}}}/{{{{data_interval_end.month}}}}/{{{{data_interval_end.day}}}}/{S3_FOLDER}/warehouse_old.csv',
                '{{{{ conn.minio_s3.extra_dejson.aws_access_key_id}}}}',
                '{{{{ conn.minio_s3.extra_dejson.aws_secret_access_key}}}}',
                'CSVWithNames'
                )
            SELECT 
                id                  ,
                parent_id           ,
                activity_status     ,
                type                ,
                code                ,
                description         ,
                division_id         ,
                region_id   
            FROM warehouse
            WHERE is_current='Текущий'
            SETTINGS s3_create_new_file_on_insert = 1,s3_truncate_on_insert=1
            """,
            # result of the last query is pushed to XCom
        ),
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    load_warehouse = ClickHouseOperator(
        task_id="load_warehouse",
        database="dwh",
        sql=(
            """
            INSERT INTO warehouse
            (
                id                  ,
                parent_id           ,
                activity_status     ,
                type                ,
                code                ,
                description         ,
                division_id         ,
                region_id           ,
                start_date          ,
                end_date            ,
                is_current  
            )
            SELECT 
                id                  ,
                parent_id           ,
                activity_status     ,
                type                ,
                code                ,
                description         ,
                division_id         ,
                region_id           ,
                start_date          ,
                end_date            ,
                is_current  
            FROM  s3(
                '{{conn.minio_s3.extra_dejson.endpoint_url }}/{{ti.xcom_pull(task_ids='warehouse_scd',key='s3_key')}}',
                'parquet'
                );
            """,
            # result of the last query is pushed to XCom
        ),
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    update_warehouse = ClickHouseOperator(
        task_id="update_warehouse",
        database="dwh",
        sql=(
            """
            ALTER TABLE warehouse
            UPDATE end_date='{{data_interval_start|ds}}',is_current='Исторический' WHERE id IN (SELECT  id FROM s3(
                            '{{conn.minio_s3.extra_dejson.endpoint_url }}/{{ti.xcom_pull(task_ids='warehouse_scd',key='updated_s3_key')}}',
                            'parquet'
                            )) AND is_current = 'Текущий'
            """,
            # result of the last query is pushed to XCom
        ),
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    (
        [extract_warehouse_old, extract_warehouse_raw]
        >> from_s3_to_duckdb()
        >> transform_warehouse()
        >> warehouse_scd()
        >> update_warehouse
        >> load_warehouse
        >> remove_temp_files()
    )


warehouse()
