WITH source AS (
    SELECT * FROM {{source('raw_dbt', 'stocktakes_raw')}}
),

renamed AS (
    SELECT
        -- dates
        CAST(_Date_Time AS Date) AS date

        -- ids
        , {{transform_hex_to_uuid('"_IDRRef"')}} AS id
        , CAST({{transform_hex_to_uuid('"Автор_ID"')}} AS LowCardinality (UUID)) AS author_id
        , CAST({{transform_hex_to_uuid('"ПодразделениеКомпании_ID"')}} AS LowCardinality (UUID)) AS division_id
        , CAST({{transform_hex_to_uuid('"СкладКомпании_ID"')}} AS LowCardinality (UUID)) AS warehouse_id
        , CAST({{transform_hex_to_uuid('"ТипЦен_ID"')}} AS LowCardinality (UUID)) AS price_type_id
        , CAST({{transform_hex_to_uuid('"ХозОперация_ID"')}} AS LowCardinality (UUID)) AS operation_id
        , CAST({{transform_hex_to_uuid('"Номенклатура_ID"')}} AS LowCardinality (UUID)) AS product_id
        , CAST({{transform_hex_to_uuid('"ЕдиницаИзмерения_ID"')}} AS LowCardinality (UUID)) AS measurement_id

        -- values
        , {{transform_string('"_Number"')}} AS document_number
        , {{transform_string('"Комментарий"')}} AS comment
        -- , {{transform_decimal('"Коэффициент"')}} AS coefficient
        , {{transform_decimal('"КоличествоКнижн"')}} AS recorded_quantity
        , {{transform_decimal('"КоличествоФакт"')}} AS actual_quantity
        , {{transform_decimal('"Цена"')}} AS cost_price_with_VAT
        , {{transform_decimal('"ЦенаОтпускная"')}} AS price_with_VAT
        , {{transform_decimal('"СуммаКнижн"')}} AS recorded_cost_price_amount
        , {{transform_decimal('"СуммаФакт"')}} AS actual_cost_price_amount
    FROM source
)

SELECT * FROM renamed
