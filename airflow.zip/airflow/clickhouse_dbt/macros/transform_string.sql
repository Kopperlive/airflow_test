{% macro transform_string(column_name) -%}
    CAST( multiIf( {{ column_name }} IS NULL OR empty(trim(replaceRegexpAll({{column_name}}, '[\\p{C}\\p{Z}]', ''))), 'Не заполнено', trim({{ column_name }})) AS String)
{%- endmacro %}