WITH source AS (
    SELECT * FROM {{ref('base_zup__employees')}}
)
SELECT * FROM source