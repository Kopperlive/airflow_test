WITH source AS (
    SELECT * FROM {{source('raw_dbt', 'price_changes_raw')}}
),

renamed AS (
    SELECT
        {{transform_hex_to_uuid('"_IDRRef"')}} AS id
        , CAST("_Date_Time" AS Date) AS created_date
        , CAST("ДатаНачалаДействия" AS Date) AS date
        , {{transform_string('"_Number"')}} AS document_number
        , {{transform_string('"Комментарий"')}} AS comment

        -- ids
        , CAST({{transform_hex_to_uuid('"Автор_ID"')}} AS LowCardinality(UUID)) AS author_id
        , CAST({{transform_hex_to_uuid('"ПодразделениеКомпании_ID"')}} AS LowCardinality(UUID)) AS division_id
        , CAST({{transform_hex_to_uuid('"Контрагент_ID"')}} AS LowCardinality(UUID)) AS contragent_id
        , CAST({{transform_hex_to_uuid('"ТипЦен_ID"')}} AS LowCardinality(UUID)) AS price_type_id
        , CAST({{transform_hex_to_uuid('"ХозОперация_ID"')}} AS LowCardinality(UUID)) AS operation_id
        , CAST({{transform_hex_to_uuid('"СкладКомпании_ID"')}} AS LowCardinality(UUID)) AS warehouse_id
        , CAST({{transform_hex_to_uuid('"Номенклатура_ID"')}} AS LowCardinality(UUID)) AS product_id
        , CAST({{transform_hex_to_uuid('"ЕдиницаИзмерения_ID"')}} AS LowCardinality(UUID)) AS measurement_id

        -- values
        , {{transform_decimal('"Цена"')}} AS price
        , {{transform_decimal('"ЦенаБазовая"')}} AS base_price
    FROM source
)

SELECT * FROM renamed