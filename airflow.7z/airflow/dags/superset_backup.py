# Standard libraries imports
from json import loads as jsonload

import pendulum

# Airflow imports
from airflow.decorators import dag
from airflow.models import Variable
from airflow.providers.ssh.operators.ssh import SSHOperator

# Custom imports
from common_utils.telegram_utils import send_error_message_telegram

S3_BUCKET_NAME = "backups"

# Instances with their schedules and config details
# This strucure is made for futre scaling if additional instances to be backuped
instances = [
    {
        "name": "bi",
        "schedule": "0 3 * * *",
        "config_variable": "superset_bi_config",
        "password_variable": "superset_bi_db_password",
    },
    {
        "name": "supplier",
        "schedule": "5 3 * * *",
        "config_variable": "superset_supplier_config",
        "password_variable": "superset_supplier_db_password",
    },
]


# Function to fetch and validate the configuration for each instance
def get_instance_config(instance_name, config_variable):
    try:
        # Load the JSON configuration from Airflow Variables
        instance_config = jsonload(Variable.get(config_variable))

        # Ensure the configuration contains all necessary keys
        required_keys = ["db_host", "db_user", "db_name"]
        for key in required_keys:
            if key not in instance_config:
                raise KeyError(
                    f"Missing required config key: {key} for instance {instance_name}"
                )

        return instance_config

    except Exception as e:
        raise ValueError(f"Error retrieving config for {instance_name}: {str(e)}")


# Function to dynamically create the DAG for each instance
def create_superset_backup_dag(
    instance_name, schedule, config_variable, password_variable
):
    @dag(
        dag_id=f"superset_{instance_name}_metadata_backup",
        default_args={
            "owner": "yerkebulanask",
            "on_failure_callback": send_error_message_telegram,
            "retries": 3,
            "retry_delay": pendulum.duration(minutes=5),
        },
        schedule_interval=schedule,
        start_date=pendulum.datetime(2024, 12, 9),
        doc_md=f"""
        # Back up for {instance_name} superset instance metadata DB

        This DAG manages the backup of the `{instance_name}` superset metadata database. 
        It ensures the database is backed up daily and stored securely in an S3 bucket.

        ## Tasks Overview:
        1. **Create Backup Locally**: Dump the database locally on the server with MinIO.
        2. **Upload to S3**: Move the backup file to a MinIO bucket.
        """,
        tags=["superset", instance_name, "backup", "s3"],
        catchup=False,
    )
    def superset_metadata_backup():
        # Fetch instance configuration from the Airflow variable
        instance_config = get_instance_config(instance_name, config_variable)

        # Extract the necessary configuration details
        db_host = instance_config["db_host"]
        db_user = instance_config["db_user"]
        db_name = instance_config["db_name"]
        db_password = Variable.get(password_variable)

        # Backup file path
        backup_filepath = f"/tmp/{instance_name}_metadata_db_backup.sql"
        backup_filename = backup_filepath.split("/")[-1]

        # Task 1: Create backup locally
        create_backup_locally = SSHOperator(
            task_id=f"create_backup_locally_{instance_name}",
            ssh_conn_id="ssh__s3",
            command=(
                f"PGPASSWORD={db_password} pg_dump -h {db_host} -U {db_user} "
                f"-p 5432 -d {db_name} > {backup_filepath}"
            ),
            conn_timeout=30,
            cmd_timeout=900,  # 15 minutes
        )

        # Task 2: Upload backup to MinIO
        upload_to_s3 = SSHOperator(
            task_id=f"upload_to_s3_{instance_name}",
            ssh_conn_id="ssh__s3",
            command=(
                f"~/minio-binaries/mc mv {backup_filepath} local/{S3_BUCKET_NAME}/"
                f"{{{{ data_interval_end.strftime('%Y/%m/%d') }}}}/"
                f"{instance_name}_db_metadata/{backup_filename}"
            ),
            conn_timeout=30,
            cmd_timeout=1800,  # 30 minutes
        )

        # Task dependencies: Create backup locally, then upload to S3
        create_backup_locally >> upload_to_s3

    return superset_metadata_backup()


# Dynamically create DAGs for each instance in the `instances` list
for instance in instances:
    globals()[f"superset_backup_{instance['name']}"] = create_superset_backup_dag(
        instance_name=instance["name"],
        schedule=instance["schedule"],
        config_variable=instance["config_variable"],
        password_variable=instance["password_variable"],
    )
