import json
from io import BytesIO, StringIO

import pandas as pd
import pendulum
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
from airflow.providers.ftp.hooks.ftp import FTPHook


def save_df_to_s3(
    df: pd.DataFrame,
    aws_conn_id: str,
    bucket_name: str,
    report_name: str,
    filename: str,
    data_interval_end: pendulum.DateTime,
    time_granularity: str = "daily",
    index: bool = False,
) -> str:
    """
    Save a DataFrame to an S3 bucket as a CSV file. The file path within the bucket is dynamically
    constructed using the specified report name, filename, and a date derived from the `data_interval_end`.

    Parameters
    ----------
    df : pd.DataFrame
        The pandas DataFrame to save. The DataFrame is saved without the index.
    aws_conn_id : str
        The connection ID for AWS (MinIO), used to authenticate and access the specified S3 bucket.
    bucket_name : str
        The name of the S3 bucket where the file will be stored.
    report_name : str
        A descriptor for the type of report the DataFrame represents; used in the file path.
    filename : str
        The name of the file to be saved in the S3 bucket.
    data_interval_end : pendulum.DateTime
        A Pendulum datetime object representing the end of the data interval. This is used to
        structure the directory path by year, month, and day.

    Returns
    -------
    str
        The S3 key (full path) where the DataFrame has been stored as a CSV file.

    Example
    -------
    >>> df = pd.DataFrame({'A': [1, 2], 'B': [3, 4]})
    >>> aws_conn_id = 'your-aws-connection-id'
    >>> bucket_name = 'your-s3-bucket'
    >>> report_name = 'sales_report'
    >>> filename = 'daily_sales.csv'
    >>> end_date = pendulum.now()
    >>> s3_key = save_df_to_s3(df, aws_conn_id, bucket_name, report_name, filename, end_date)
    >>> print(s3_key)
    '2023/5/15/sales_report/daily_sales.csv'
    """
    s3_hook = S3Hook(aws_conn_id=aws_conn_id)
    csv_buffer = StringIO()
    df.to_csv(csv_buffer, index=index)

    datetime_part = (
        f"{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}"
    )

    if time_granularity == "hourly":
        datetime_part += f"/{data_interval_end.hour}"

    file_s3_key = f"{datetime_part}/{report_name}/{filename}"

    s3_hook.load_string(
        string_data=csv_buffer.getvalue(),
        bucket_name=bucket_name,
        key=file_s3_key,
        replace=True,
    )
    csv_buffer.close()
    return file_s3_key


def read_df_from_ftp(
    ftp_conn_id: str, file_path: str, sep: str = ",", index_col: list = None
):
    """
    Works only on CSV format!
    """

    ftp_hook = FTPHook(ftp_conn_id=ftp_conn_id)

    with ftp_hook.get_conn() as ftp_conn:
        # Create a buffer to store the CSV data
        file_content = []
        ftp_conn.retrbinary(f"RETR {file_path}", file_content.append)

    # Join the list into a single string and load it into StringIO
    csv_data = "".join([chunk.decode("utf-8") for chunk in file_content])
    file_stream = StringIO(csv_data)

    # Load the CSV data into a pandas DataFrame
    df = pd.read_csv(file_stream, sep=sep, index_col=index_col)
    return df


def read_df_from_s3(
    aws_conn_id: str,
    bucket_name: str,
    file_s3_key: str,
    index_col: list = None,
    sep: str = ",",
) -> pd.DataFrame:
    """
    Read a CSV file from an S3 bucket and convert it to a pandas DataFrame. This function uses
    an S3Hook to access the specified bucket and key to retrieve the CSV data, which it then
    loads into a DataFrame.

    Parameters
    ----------
    aws_conn_id : str
        The connection ID for AWS (MinIO), used to authenticate and access the specified S3 bucket.
    bucket_name : str
        The name of the S3 bucket from which the CSV file will be read.
    file_s3_key : str
        The key (path) of the CSV file within the S3 bucket.

    Returns
    -------
    pd.DataFrame
        A DataFrame containing the data read from the CSV file stored in S3.

    Example
    -------
    >>> aws_conn_id = 'your-aws-connection-id'
    >>> bucket_name = 'your-s3-bucket'
    >>> file_s3_key = 'path/to/your/file.csv'
    >>> df = read_df_from_s3(aws_conn_id, bucket_name, file_s3_key)
    >>> print(df.head())
    """
    s3_hook = S3Hook(aws_conn_id=aws_conn_id)
    data = s3_hook.read_key(bucket_name=bucket_name, key=file_s3_key)
    df = pd.read_csv(StringIO(data), index_col=index_col, sep=sep)
    return df


def save_binary_file_to_s3(
    aws_conn_id: str,
    bucket_name: str,
    report_name: str,
    file_bytes: BytesIO,
    filename: str,
    data_interval_end: pendulum.DateTime,
) -> str:
    """
    Save a binary file, represented as a BytesIO object, to an S3 bucket. The file is stored under a path
    constructed from the current date, report name, and filename provided. This function uses an S3Hook
    for file operations, allowing the file to be written directly as bytes.

    Parameters
    ----------
    aws_conn_id : str
        The connection ID for AWS, used to authenticate and access the specified S3 bucket.
    bucket_name : str
        The name of the S3 bucket where the file will be stored.
    report_name : str
        A descriptor for the type of report the file represents; used in the file path.
    file_bytes : BytesIO
        The binary file to be saved, wrapped in a BytesIO object to handle the byte stream.
    filename : str
        The name of the file to be saved in the S3 bucket.
    data_interval_end : pendulum.DateTime
        A Pendulum datetime object representing the end of the data interval. This is used to
        construct the directory path by year, month, and day.

    Returns
    -------
    str
        The S3 key (full path) where the binary file has been stored.

    Example
    -------
    >>> from io import BytesIO
    >>> file_content = BytesIO(b'Your binary data here')
    >>> aws_conn_id = 'your-aws-connection-id'
    >>> bucket_name = 'your-s3-bucket'
    >>> report_name = 'daily_data_report'
    >>> filename = 'report.pdf'
    >>> end_date = pendulum.now()
    >>> s3_key = save_binary_file_to_s3(aws_conn_id, bucket_name, report_name, file_content, filename, end_date)
    >>> print(s3_key)
    '2023/5/15/daily_data_report/report.pdf'
    """
    # Seek to the beginning of the stream
    file_bytes.seek(0)
    # Save it to S3
    s3_hook = S3Hook(aws_conn_id=aws_conn_id)

    # But file path in S3 storage is today
    file_s3_key = f"{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}/{report_name}/{filename}"
    s3_hook.load_bytes(
        bytes_data=file_bytes.getvalue(),
        bucket_name=bucket_name,
        key=file_s3_key,
        replace=True,
    )

    # Close the buffer
    file_bytes.close()

    return file_s3_key


def read_binary_file_from_s3(
    aws_conn_id: str, bucket_name: str, file_s3_key: str
) -> BytesIO:
    """
    Read a binary file from an S3 bucket and return it as a BytesIO object. This function uses
    an S3Hook to access the specified bucket and key to retrieve the binary data of the file,
    which it then wraps in a BytesIO object to facilitate further binary operations in Python.

    Parameters
    ----------
    aws_conn_id : str
        The connection ID for AWS, used to authenticate and access the specified S3 bucket.
    bucket_name : str
        The name of the S3 bucket from which the binary file will be read.
    file_s3_key : str
        The key (path) of the binary file within the S3 bucket.

    Returns
    -------
    BytesIO
        A BytesIO object containing the binary data of the file.

    Example
    -------
    >>> aws_conn_id = 'your-aws-connection-id'
    >>> bucket_name = 'your-s3-bucket'
    >>> file_s3_key = 'path/to/your/file.bin'
    >>> file_content = read_binary_file_from_s3(aws_conn_id, bucket_name, file_s3_key)
    >>> print(file_content.getvalue())  # Assuming the binary data can be represented as a string
    b'binary content of the file'
    """
    s3_hook = S3Hook(aws_conn_id=aws_conn_id)
    obj = s3_hook.get_key(bucket_name=bucket_name, key=file_s3_key)
    file_binary = obj.get()["Body"].read()
    return BytesIO(file_binary)


def save_dict_to_s3(
    dc: dict,
    aws_conn_id: str,
    bucket_name: str,
    report_name: str,
    filename: str,
    data_interval_end: pendulum.DateTime,
) -> str:
    """
    Save a dictionary to an S3 bucket as a JSON file. The file path within the bucket is dynamically
    constructed using the specified report name, filename, and a date derived from the `data_interval_end`.

    Parameters
    ----------
    dc : Dictionary
        The dictionary to save.
    aws_conn_id : str
        The connection ID for AWS (MinIO), used to authenticate and access the specified S3 bucket.
    bucket_name : str
        The name of the S3 bucket where the file will be stored.
    report_name : str
        A descriptor for the type of report the DataFrame represents; used in the file path.
    filename : str
        The name of the file to be saved in the S3 bucket.
    data_interval_end : pendulum.DateTime
        A Pendulum datetime object representing the end of the data interval. This is used to
        structure the directory path by year, month, and day.

    Returns
    -------
    str
        The S3 key (full path) where the DataFrame has been stored as a json file.

    """
    s3_hook = S3Hook(aws_conn_id=aws_conn_id)
    json_buffer = StringIO()

    json.dump(dc, json_buffer)

    file_s3_key = f"{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}/{report_name}/{filename}"
    s3_hook.load_string(
        string_data=json_buffer.getvalue(),
        bucket_name=bucket_name,
        key=file_s3_key,
        replace=True,
    )
    json_buffer.close()
    return file_s3_key


def read_dict_from_s3(aws_conn_id: str, bucket_name: str, file_s3_key: str) -> dict:
    """
    Read a json file from an S3 bucket and convert it to a python dictionary.
    Parameters
    ----------
    aws_conn_id : str
        The connection ID for AWS (MinIO), used to authenticate and access the specified S3 bucket.
    bucket_name : str
        The name of the S3 bucket from which the CSV file will be read.
    file_s3_key : str
        The key (path) of the JSON file within the S3 bucket.

    Returns
    -------
    Python Dictionary

    """

    s3_hook = S3Hook(aws_conn_id=aws_conn_id)
    data = s3_hook.read_key(bucket_name=bucket_name, key=file_s3_key)

    # Convert json to dictionary
    data_dict = json.loads(StringIO(data).getvalue())

    return data_dict
