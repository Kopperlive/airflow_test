from airflow.providers.telegram.hooks.telegram import TelegramHook


def send_error_message_telegram(
    context: dict, telegram_conn_id="bi_titans_bot"
) -> None:
    """
    Sends an error notification message via Telegram when an Airflow task fails. This function constructs a message
    containing details about the DAG, the specific task that failed, and the exception message, then sends this
    message to a configured Telegram group or chat using the specified Telegram connection ID.

    Parameters
    ----------
    context : dict
        The context dictionary provided by Airflow which contains metadata about the task instance. Key elements used
        include:
        - 'dag' for accessing the DAG ID (`context['dag'].dag_id`),
        - 'task_instance' for accessing the task ID (`context['task_instance'].task_id`),
        - 'exception' for the error message thrown by the task (`context['exception']`).
    telegram_conn_id : str, optional
        The connection ID for the Telegram bot, used to send the message. Defaults to 'bi_titans_bot'. This ID should be
        set up in Airflow's connection settings with the appropriate bot token and chat ID.

    Examples
    --------
    >>> context = {
    ...     'dag': <DAG>,
    ...     'task_instance': <TaskInstance>,
    ...     'exception': "Example error message."
    ... }
    >>> send_error_message_telegram(context)

    Notes
    -----
    To use this function, ensure that you have the `TelegramHook` configured properly in your Airflow setup with the
    correct bot token and chat ID linked to the `telegram_conn_id`. The function does not return any values; it solely
    sends a message to Telegram. Error handling for the Telegram API call should be implemented if operational
    reliability is critical.
    """

    message = f"""
    Airflow Alert: Task Failed
    Owner: @{context['dag'].owner}
    DAG: {context['dag'].dag_id}
    Task: {context['task_instance'].task_id}
    """

    if "my_custom_map_index" in context:
        mapped_index_name = f"Mapped index name: {context['my_custom_map_index']}\n"
        message += mapped_index_name

    message += f"Error: {context['exception']}"

    telegram_hook = TelegramHook(telegram_conn_id=telegram_conn_id)
    telegram_hook.send_message({"text": message, "parse_mode": None})
