import pendulum
from airflow.models import Variable
from common_utils.sql_utils import read_sql_file


def build_delete_partition_query(
    month_range: int, data_interval_end: pendulum.DateTime
):
    """
    Constructs a SQL query to drop partitions in a database table based on a given end date and a predefined number of months.

    This function dynamically creates a list of SQL commands to drop partitions from a table. The partitions are identified by
    month and year, calculated backward from a specified end date. This is used to manage data retention and storage
    optimization in a data warehouse.

    Parameters:
        month_range (int): how many months backwards to delete
        data_interval_end (pendulum.DateTime): The end date of the data interval. Partitions up to this date and going
        back by a number of months specified by the 'FACTS_MONTH_RANGE' Airflow variable will be targeted for deletion.

    Returns:
        str: A single string containing concatenated SQL commands for dropping the specified partitions. Each partition
        command is separated by a comma, ready to be executed or appended to a further SQL command.

    Example:
        >>> build_delete_partition_query(pendulum.datetime(2024, 12, 31))
        "DROP PARTITION '202412', DROP PARTITION '202411', DROP PARTITION '202410'"
    """
    data_interval_end = data_interval_end.subtract(days=1)
    partitions = []
    for i in range(month_range + 1):
        partition = data_interval_end.subtract(months=i).format("YYYYMM")
        partitions.append(f"DROP PARTITION '{partition}'")
    return ",".join(partitions)


def get_data_interval_start(
    data_interval_end: pendulum.DateTime, month_range: int = None
):
    """
    Calculates the start date of a data interval based on the provided end date and a specific number of months
    defined by the 'FACTS_MONTH_RANGE' Airflow variable. This start date is used to define the scope of data
    processing tasks in a DAG.

    The function adjusts the provided end date by subtracting one day and then subtracts a number of months specified
    by 'FACTS_MONTH_RANGE'. It returns the starting day of the month for the resultant date, effectively setting the
    boundary for data operations that should consider data starting from the beginning of that month.

    Parameters:
        month_range (int): how many months backwards to start from
        data_interval_end (pendulum.DateTime): The end date of the data interval, from which the start date will
        be calculated.

    Returns:
        pendulum.DateTime: The calculated start date of the data interval, adjusted to the beginning of the month.
        This start date is used to set the range for data processing tasks in terms of month and year.

    Example:
        >>> get_data_interval_start(pendulum.datetime(2024, 12, 31))
        DateTime(2024, 9, 1, 0, 0, 0, tzinfo=Timezone('UTC'))

    Notes:
        - The subtraction of one day from the 'data_interval_end' is to ensure that the calculation correctly aligns
        with the end of the previous day, avoiding any off-by-one errors in monthly calculations.
    """

    if month_range is None:
        month_range = int(Variable.get("facts_month_range"))

    data_interval_end = data_interval_end.subtract(days=1)
    return data_interval_end.subtract(months=month_range).start_of("month")


def build_bcp_command(context, jinja_env, sql_file: str, destination: str):
    query = read_sql_file(sql_file)
    cmd = f'/opt/mssql-tools18/bin/bcp "{query}" queryout {destination}  -c -t"|" -D -S 1C-AR-CENTRE -d AR_TRADE -U {{{{var.json.reader_credentials.user}}}} -P {{{{var.json.reader_credentials.password}}}}'
    # return jinja_env.from_string(cmd).render(context)
    return context["task"].render_template(cmd, context, jinja_env)
