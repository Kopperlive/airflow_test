WITH source AS (

    SELECT * FROM {{ ref("base_ar_trade__orders") }}

)

, grouped AS (

    SELECT
        date
        , delivery_date

        , id
        , document_number

        , comment
        , author_id

        , division_id
        , warehouse_id
        , contragent_id
        , product_id
        , measurement_id

        , operation_id

        , contragent_settlement_id

        , price_type_id
        , vat_rate_id


        , is_sent_to_contragent

        , SUM(quantity) AS quantity
        , SUM(cost_price) AS cost_price
        , SUM(cost_price_VAT) AS cost_price_VAT
    FROM source
    GROUP BY ALL
)

SELECT * FROM grouped
