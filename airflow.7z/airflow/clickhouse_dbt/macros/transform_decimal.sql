{% macro transform_decimal(column_name) -%}
    CAST(round(toDecimal64(COALESCE({{column_name}},0),4),3) AS Decimal64(3))
{%- endmacro %}