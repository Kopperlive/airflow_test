SELECT
    _Date_Time,
    CONVERT(NCHAR(34),Автор_ID ,1) AS Автор_ID,
    _Number,
    CONVERT(NCHAR(34),ПодразделениеКомпании_ID,1) AS ПодразделениеКомпании_ID,
    CONVERT(NCHAR(34),Контрагент_ID,1) AS Контрагент_ID,
    CONVERT(NCHAR(34),ДоговорВзаиморасчетов_ID,1) AS ДоговорВзаиморасчетов_ID,
    CONVERT(NCHAR(34),СкладКомпании_ID,1) AS СкладКомпании_ID,
    CONVERT(NCHAR(34),ТипЦен_ID,1) AS ТипЦен_ID,
    CONVERT(NCHAR(34),ХозОперация_ID,1) AS ХозОперация_ID,
    CONVERT(NCHAR(34),Номенклатура_ID,1) AS Номенклатура_ID,
    CONVERT(NCHAR(34),СтавкаНДС_ID,1) AS СтавкаНДС_ID,
    CONVERT(NCHAR(34),ПричинаВозврата_ID,1) AS  ПричинаВозврата_ID,
    CONVERT(NCHAR(34),Партия_ID,1) AS Партия_ID,
    Количество,
    Сумма,
    СуммаНДС
from vw_ВозвратПоставщику r WITH(NOLOCK)
    INNER JOIN vw_ВозвратПоставщику_Товары rt WITH(NOLOCK)
        ON rt.Ссылка = r._IDRRef
           AND r._Date_Time >= '{{get_data_interval_start(data_interval_end,params.month_range).add(years=2000) | ds_nodash}}' AND r._Date_Time<'{{data_interval_end.add(years=2000) | ds_nodash}}'
           AND r._Marked = 0x00
           AND r._Posted = 0x01
UNION ALL
SELECT 
    _Date_Time,
    CONVERT(NCHAR(34),Автор_ID ,1) AS Автор_ID,
    _Number,
    CONVERT(NCHAR(34),ПодразделениеКомпании_ID,1) AS ПодразделениеКомпании_ID,
    CONVERT(NCHAR(34),Контрагент_ID,1) AS Контрагент_ID,
    CONVERT(NCHAR(34),ДоговорВзаиморасчетов_ID,1) AS ДоговорВзаиморасчетов_ID,
    CONVERT(NCHAR(34),СкладКомпании_ID,1) AS СкладКомпании_ID,
    CONVERT(NCHAR(34),ТипЦен_ID,1) AS ТипЦен_ID,
    CONVERT(NCHAR(34),ХозОперация_ID,1) AS ХозОперация_ID,
    CONVERT(NCHAR(34),Номенклатура_ID,1) AS Номенклатура_ID,
    CONVERT(NCHAR(34),СтавкаНДС_ID,1) AS СтавкаНДС_ID,
    NULL,
    NULL,
    rzt.Количество,
    rzt.СуммаВсего,
    rzt.СуммаНДС
FROM vw_РеализацияТоваров rz WITH(NOLOCK)
    JOIN vw_РеализацияТоваров_Товары rzt WITH(NOLOCK)
        ON rz._Marked = 0x00
           AND rz._Date_Time >= '{{get_data_interval_start(data_interval_end,params.month_range).add(years=2000) | ds_nodash}}' AND rz._Date_Time<'{{data_interval_end.add(years=2000) | ds_nodash}}'
           and rz._Posted = 0x01
           AND rz.ХозОперация_ID = 0xA2B59E27A5FF571144D071F1993F5173
           AND rzt.Ссылка = rz._IDRRef


