import smtplib
from email.message import EmailMessage

from airflow.providers.amazon.aws.hooks.s3 import S3Hook


def send_email(
    sender_email: str,
    sender_pwd: str,
    recipient_email: str,
    subject: str,
    content: str,
    aws_conn_id: str = None,
    bucket_name: str = None,
    excel_file_key: str = None,
    zip_file_key: str = None,
    html_table: str = None,
    cc: str = None,
) -> None:
    """
    Send an email with optional attachments and HTML content. This function supports sending emails with
    attachments that are retrieved from an S3 bucket (specifically MinIO S3 in this context). It can also
    send an HTML table as part of the email content.

    Parameters
    ----------
    sender_email : str
        The email address of the sender.
    sender_pwd : str
        The password for the sender's email account. This is used to authenticate with the SMTP server.
    recipient_email : str
        The email address of the recipient.
    subject : str
        The subject of the email.
    content : str
        The main text content of the email. If `html_table` is provided, this content will be overwritten.
    aws_conn_id : str, optional
        The connection ID for AWS, used to access S3. If not provided, attachments cannot be sent.
    bucket_name : str, optional
        The name of the S3 bucket from which to retrieve attachments.
    excel_file_key : str, optional
        The S3 key for an Excel file to attach to the email.
    zip_file_key : str, optional
        The S3 key for a zip file to attach to the email.
    html_table : str, optional
        HTML content to send within the email body. This can be any valid HTML, but typically used to send tables.
    cc : str, optional
        A comma-separated string of email addresses to carbon copy.

    Raises
    ------
    Exception
        If `aws_conn_id` or `bucket_name` is None when attempting to attach a file.

    Examples
    --------
    >>> send_email(
    ...     sender_email="your-email@example.com",
    ...     sender_pwd="your-password",
    ...     recipient_email="recipient@example.com",
    ...     subject="Meeting Reminder",
    ...     content="Please remember our meeting at 10 AM tomorrow.",
    ...     aws_conn_id="your-aws-connection-id",
    ...     bucket_name="your-s3-bucket",
    ...     excel_file_key="path/to/your/file.xlsx",
    ...     html_table="<table><tr><td>Hello</td></tr></table>"
    ... )
    """
    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = sender_email
    msg["To"] = recipient_email

    # If email address provided for carbon copy
    if cc:
        msg.add_header("Cc", cc)

    msg.set_content(content)

    # Add the content to the email as HTML
    if html_table:
        msg.add_alternative(html_table, subtype="html")

    def _get_from_s3(file_key):
        if aws_conn_id is None or bucket_name is None:
            raise Exception
        s3_hook = S3Hook(aws_conn_id=aws_conn_id)
        obj = s3_hook.get_key(bucket_name=bucket_name, key=file_key)
        file = obj.get()["Body"].read()
        filename = file_key.split("/")[-1]
        return file, filename

    # Add attachment if Excel file given
    if excel_file_key:
        excel_file, file_name = _get_from_s3(excel_file_key)
        msg.add_attachment(
            excel_file,
            maintype="application",
            subtype="vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            filename=file_name,
        )

    # Add attachment if zip file given
    if zip_file_key:
        zip_file, file_name = _get_from_s3(zip_file_key)
        msg.add_attachment(
            zip_file, maintype="application", subtype="zip", filename=file_name
        )

    # 993
    with smtplib.SMTP_SSL(host="mail.asia.kg", port=465) as smtp:
        smtp.login(sender_email, sender_pwd)
        smtp.send_message(msg)
