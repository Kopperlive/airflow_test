{% snapshot snapshots__dim_essential_products %}
    select * from {{ ref('base_ar_trade__essential_products') }}
{% endsnapshot %}