-- WITH {start_date:Date} AS date_from,{end_date:Date} AS date_to,
{{ config(
    materialized='table',
) }}
WITH divisions AS (
    SELECT * FROM {{ref('dim_divisions')}}
)
, cheques AS (
    SELECT * FROM {{ source('uks','cheques') }}
)
, fct_sales AS (
    SELECT * FROM {{ref('fct_sales')}}
)
, writeoffs AS (
    SELECT * FROM {{ref('fct_writeoffs')}}
)
, plans AS (
    SELECT * FROM {{ref('fct_plans')}}
)
, dates AS (
    SELECT * FROM {{ref('dim_dates')}}
)
, sales_by_date_division AS (
    SELECT 
        date
        , division_id
        , SUM(amount + amount_VAT) AS amount_with_VAT
    FROM fct_sales
    WHERE date>='2025-01-01'
    -- where date
    -- between date_from AND date_to

    GROUP BY date
           , division_id
   )
, sales_with_plan AS (
    SELECT 
        sales_by_date_division.date AS date
        , sales_by_date_division.division_id AS division_id
        , sales_by_date_division.amount_with_VAT
        , (plans.amount / dates.days_in_month) AS plan_per_day_amount_with_VAT
    FROM sales_by_date_division

        INNER JOIN dates
            ON sales_by_date_division.date = dates.date

        LEFT JOIN plans
            ON dates.month_ru = plans.month
               AND dates.year=2025
               AND sales_by_date_division.division_id = plans.division_id
   )
, cheques_by_date_division AS (
    SELECT 
        date
        , shop_index
        , id
        , SUM(amount_with_VAT) AS cheque_sum
    FROM cheques
    WHERE date>='2025-01-01'
    -- between date_from AND date_to

    GROUP BY date
           , shop_index
           , id
   )
, cheques_add_average_check_and_quantity AS (
    SELECT 
        date
        , shop_index
        , AVG(cheque_sum)   AS avg_cheque_amount_with_VAT
        , COUNT(distinct id) AS cheques_quantity
    FROM cheques_by_date_division
    GROUP BY date
           , shop_index
   )
, writeoffs_by_date_division AS (
    SELECT 
        date
        , division_id
        , SUM(cost_price + cost_price_VAT) AS cost_price_with_VAT
    FROM writeoffs
    WHERE date>='2025-01-01'
    -- between date_from AND date_to

    GROUP BY date
           , division_id
   )
, combined_sales_writeoffs_cheques AS (
    SELECT 
        CAST(COALESCE(sales_with_plan.date, writeoffs_by_date_division.date) AS Date) AS date
        , CAST(divisions.description AS String) AS market
        , sales_with_plan.amount_with_VAT AS sales_amount_with_VAT
        , sales_with_plan.plan_per_day_amount_with_VAT AS plan_sales_amount_with_VAT
        , writeoffs_by_date_division.cost_price_with_VAT AS writeoff_cost_price_with_VAT
        , cheques.avg_cheque_amount_with_VAT
        , cheques.cheques_quantity
    FROM sales_with_plan
        FULL OUTER JOIN writeoffs_by_date_division
                        ON writeoffs_by_date_division.date = sales_with_plan.date
                            AND writeoffs_by_date_division.division_id = sales_with_plan.division_id
        INNER JOIN divisions
                   ON divisions.id = COALESCE(sales_with_plan.division_id, writeoffs_by_date_division.division_id)
                       AND divisions.is_current = 1
        LEFT OUTER JOIN cheques_add_average_check_and_quantity cheques
                   ON cheques.shop_index = divisions.shop_index
                       AND (divisions.report_code NOT LIKE '%СП%')
                       AND cheques.date=sales_with_plan.date
   )

SELECT * FROM combined_sales_writeoffs_cheques 