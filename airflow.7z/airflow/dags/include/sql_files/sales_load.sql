INSERT INTO sales
    (
    date,
    division_id,
    warehouse_id,
    contragent_id,
    buyer_id,
    contragent_settlement_id,
    product_id,
    supply_type_id,
    operation_id,
    payment_method_id,
    vat_rate_id,
    quantity,
    amount,
    amount_VAT,
    amount_discount,
    cost_price,
    cost_price_VAT
    )
SELECT 
    date,
    division_id,
    warehouse_id,
    contragent_id,
    buyer_id,
    contragent_settlement_id,
    product_id,
    supply_type_id,
    operation_id,
    payment_method_id,
    vat_rate_id,
    round(toDecimal64(quantity,4),3) AS quantity,
    round(toDecimal64(amount,4),2) AS amount,
    round(toDecimal64(amount_VAT,4),2) AS amount_VAT,
    round(toDecimal64(amount_discount,4),2) AS amount_discount,
    round(toDecimal64(cost_price,4),2) AS cost_price,
    round(toDecimal64(cost_price_VAT,4),2) AS cost_price_VAT
FROM  s3(
    '{{conn.minio_s3.extra_dejson.endpoint_url }}/{{ti.xcom_pull(task_ids='transform_sales',key='s3_key')}}',
    'parquet'
    );
