{% snapshot snapshots__dim_divisions %}
    select * from {{ ref('stg_ar_trade__divisions') }}
{% endsnapshot %}