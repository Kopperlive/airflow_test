import os
from datetime import timedelta

import pendulum
from airflow.providers.amazon.aws.transfers.local_to_s3 import (
    LocalFilesystemToS3Operator,
)
from common_utils.telegram_utils import send_error_message_telegram

from airflow import DAG

# Define default arguments for the DAG
default_args = {
    "owner": "ubaitur5",
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
    "on_failure_callback": send_error_message_telegram,
}

# Define paths
DBT_PROJECT_DIR = "/opt/airflow/clickhouse_dbt"
DBT_TARGET_DIR = os.path.join(DBT_PROJECT_DIR, "target")

# Define S3 bucket and prefix
S3_BUCKET = "etc"  # Replace with your actual bucket name
S3_PREFIX = "dbt-artifacts"  # You can adjust this prefix as needed

# Create the DAG
dag = DAG(
    "upload_dbt_artifacts_to_s3",
    default_args=default_args,
    description="Upload dbt artifacts to S3",
    schedule_interval="@daily",  # Adjust as needed
    start_date=pendulum.DateTime(2025, 3, 23),
    catchup=False,
    tags=["dbt"],
)

# Create tasks for uploading each file
upload_catalog = LocalFilesystemToS3Operator(
    task_id="upload_catalog",
    filename=os.path.join(DBT_TARGET_DIR, "catalog.json"),
    dest_key=f"{S3_PREFIX}/catalog.json",
    dest_bucket=S3_BUCKET,
    aws_conn_id="minio_s3",  # Ensure this connection is configured in Airflow
    replace=True,
    dag=dag,
)

upload_manifest = LocalFilesystemToS3Operator(
    task_id="upload_manifest",
    filename=os.path.join(DBT_TARGET_DIR, "manifest.json"),
    dest_key=f"{S3_PREFIX}/manifest.json",
    dest_bucket=S3_BUCKET,
    aws_conn_id="minio_s3",
    replace=True,
    dag=dag,
)

upload_run_results = LocalFilesystemToS3Operator(
    task_id="upload_run_results",
    filename=os.path.join(DBT_TARGET_DIR, "run_results.json"),
    dest_key=f"{S3_PREFIX}/run_results.json",
    dest_bucket=S3_BUCKET,
    aws_conn_id="minio_s3",
    replace=True,
    dag=dag,
)

# Set task dependencies (you can upload files in parallel)
# Or define a specific order if needed
