SELECT			   
    DATEADD(YEAR,-2000,T1._Period) AS _Period
    , T2._IDRRef
    , T2._Number
    , T2.Комментарий
	, T2.[ПодразделениеКомпании_ID]
    , T1.[Номенклатура_ID]
    , D1.[Контрагент_ID]
    , T2.[СкладКомпании_ID]
    , T2.[ХозОперация_ID]
    , T2.[СтатьяСписанияТМЦ_ID]
    , T2.[Автор_ID]
    , T2.[ТипЦен_ID]
    , T1.[СуммаУпр]
    , T1.[СуммаНДС]
    , T1.[Количество]
FROM [vw_ПартииТоваровКомпании] T1 WITH (NOLOCK)
INNER JOIN [vw_СписаниеТоваров] T2 WITH (NOLOCK)
    ON T2._IDRRef = T1._RecorderRRef
        AND T2._Marked = 0x00
        AND T2._Posted = 0x01
		AND T1._Period >= '{{get_data_interval_start(data_interval_end).add(years=2000) | ds_nodash}}' AND T1._Period < '{{data_interval_end.add(years=2000) | ds_nodash}}'
		AND T1._Active = 0x01
		AND T1._RecordKind = 1
		AND T1._RecorderTREf = 0x0000021A
LEFT JOIN [vw_ПоступлениеТоваров] D1 --Поступление Товаров
    ON D1._IDRRef = T1.Партия_ID
		