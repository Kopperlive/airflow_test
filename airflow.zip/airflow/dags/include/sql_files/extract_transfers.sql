SELECT 
    DATEADD(YEAR,-2000,[_Date_Time]) AS _Date_time
    , _IDRRef
    , [_Number]
    , Автор_ID
    , ПодразделениеКомпании_ID
    , РегламентированныйУчет
    , [Комментарий]
    , СкладКомпании_НОМЕР
    , СкладПолучатель_НОМЕР
	, Номенклатура_ID
    , СкладКомпании_ID
    , СкладПолучатель_ID
    , ТипЦен_ID
    , ХозОперация_ID
	, [ИДДокументаОтгрузки]
	, СтавкаНДС_ID
	, ЕдиницаИзмерения_ID
	, ЗакрытиеЗаказовПокупателей
	, mvt.Количество
	, mvt.СуммаРозничная --amount
	, mvt.Сумма --cost_price
	, mvt.СуммаНДС

FROM vw_ПеремещениеТоваров mv WITH (NOLOCK)
	LEFT JOIN vw_ПеремещениеТоваров_Товары mvt WITH(NOLOCK)
         ON mvt.Ссылка=mv._IDRRef
WHERE mv._Marked=0x00 AND mv._Posted=0x01 
AND _Date_Time >= '{{get_data_interval_start(data_interval_end).add(years=2000) | ds_nodash}}' AND _Date_Time < '{{data_interval_end.add(years=2000) | ds_nodash}}'
AND mvt.Количество IS NOT NULL AND mvt.Сумма IS NOT NULL