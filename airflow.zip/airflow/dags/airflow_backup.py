import pendulum
from airflow.decorators import dag
from airflow.providers.ssh.operators.ssh import SSHOperator
from common_utils.telegram_utils import send_error_message_telegram

S3_BUCKET_NAME = "backups"


@dag(
    default_args={
        "owner": "ubaitur5",
        "on_failure_callback": send_error_message_telegram,
    },
    schedule_interval="15 2 * * *",
    start_date=pendulum.DateTime(2025, 3, 23),
    tags=["backup", "airflow-maintenance"],
    catchup=False,
    max_active_runs=1,
)
def airflow_backup():
    backup_filename = "airflow_etl_backup.sql"
    backup_tmp_filepath = f"/tmp/{backup_filename}"
    backup_s3_folder = "airflow_etl"

    # Task 1: Create backup locally
    create_backup_locally = SSHOperator(
        task_id=f"create_backup_locally",
        ssh_conn_id="ssh__s3",
        command=(
            f"PGPASSWORD={{{{conn.airflow_db.password}}}} pg_dump -h {{{{conn.airflow_db.host}}}} -U {{{{conn.airflow_db.login}}}} "
            f"-p 5432 -d {{{{conn.airflow_db.schema}}}} > {backup_tmp_filepath}"
        ),
        conn_timeout=30,
        cmd_timeout=300,  # 5 minutes
    )

    # Task 2: Upload backup to MinIO
    upload_to_s3 = SSHOperator(
        task_id=f"upload_to_s3",
        ssh_conn_id="ssh__s3",
        command=(
            f"~/minio-binaries/mc mv {backup_tmp_filepath} local/{S3_BUCKET_NAME}/"
            f"{{{{ data_interval_end.strftime('%Y/%m/%d') }}}}/"
            f"{backup_s3_folder}/{backup_filename}"
        ),
        conn_timeout=30,
        cmd_timeout=300,  # 5 minutes
    )

    # Task dependencies: Create backup locally, then upload to S3
    create_backup_locally >> upload_to_s3


airflow_backup()
