import os

import duckdb
import pendulum
from airflow.decorators import dag, task
from airflow.models import Variable
from airflow.models.taskinstance import TaskInstance
from airflow.operators.bash import BashOperator
from airflow_clickhouse_plugin.operators.clickhouse import ClickHouseOperator
from common_utils.etl_utils import build_delete_partition_query
from common_utils.sql_utils import read_sql_file
from common_utils.telegram_utils import send_error_message_telegram
from constants.etl_constants import EMPTY_NULL_PLACEHOLDER_FOR_REFERENCES

doc_md = """
# Documentation for ETL Facts Remains DAG

## Overview

The `remains` DAG orchestrates the extraction, transformation, and loading of remains data from source systems into a data warehouse, with additional steps to export processed data to an S3 bucket. It leverages DuckDB for data processing and ClickHouse for final data storage, ensuring a robust and scalable handling of remains data.

## DAG Configuration

- **Schedule**: Runs daily
- **Catchup**: False (does not perform catch-up runs for past dates).
- **Concurrency**: Allows only one run at a time with `max_active_runs` set to 1.
- **Tags**: Includes tags `["etl", "facts"]` for easy filtering and identification within the Airflow UI.

## Task Details

### 1. `extract_remains_next_month` and `extract_remains_movements`
- **Type**: `BashOperator`
- **Description**: These tasks use the `bcp` utility to extract remains data from a Microsoft SQL Server database into CSV files. `extract_remains_next_month` focuses on data for the upcoming month, while `extract_remains_movements` captures movement data.
- **Outputs**: CSV files stored at `/tmp/remains_next_month.csv` and `/tmp/remains_movements.csv`.

### 2. `load_to_duckdb`
- **Type**: Python task (@task decorator)
- **Description**: Loads the CSV data into DuckDB, creating tables `remains_next_month_raw` and `remains_movements_raw` for further processing.
- **Dependencies**: Follows `extract_remains_next_month` and `extract_remains_movements`.

### 3. `transform_remains_accumulative`
- **Type**: Python task (@task decorator)
- **Description**: Transforms and aggregates data from raw tables into structured tables suitable for analysis: `remains_next_month` and `remains_movements`, and then combines these into `remains_accumulative`.
- **Dependencies**: Executes after `load_to_duckdb`.

### 4. `transform_remains_all_combinations`
- **Type**: Python task (@task decorator)
- **Description**: Generates a comprehensive dataset of all possible date-product-warehouse-contragent combinations using the data from `remains_accumulative`.
- **Dependencies**: Follows `transform_remains_accumulative`.

### 5. `transform_remains_for_every_day`
- **Type**: Python task (@task decorator)
- **Description**: Final transformation step that prepares daily granular data and exports it to S3 in Parquet format. Uses window functions to compute rolling totals.
- **Dependencies**: Executes after `transform_remains_all_combinations`.

### 6. `drop_partitions` and `load_remains`
- **Type**: `ClickHouseOperator`
- **Description**: `drop_partitions` manages data retention by dropping older partitions in ClickHouse, and `load_remains` loads the transformed data from S3 into ClickHouse.
- **Dependencies**: `drop_partitions` runs after `transform_remains_for_every_day`, followed by `load_remains`.

### 7. `remove_temp_files`
- **Type**: Python task (@task decorator)
- **Description**: Cleans up temporary files created during the DAG execution to free up disk space and maintain order.
- **Dependencies**: Concludes the DAG after `load_remains`.

## Execution Flow

The DAG starts by extracting data, loading it into DuckDB for processing, transforming it through several stages, and finally loading the processed data into ClickHouse and exporting to S3. The flow ensures that each step is prepared by the previous steps' outputs, maintaining data integrity and processing continuity.
"""

# S3 stuff
BUCKET_NAME = "etl-data-files"
S3_FOLDER = "remains"

DUCKDB_TEMP_FILE = "/tmp/remains.db"

# tempory place to store results from bcp utility
REMAINS_NEXT_MONTH_TEMP_FILE = "/tmp/remains_next_month.csv"
REMAINS_MOVEMENTS_TEMP_FILE = "/tmp/remains_movements.csv"

## how many months to delete backwards
FACTS_MONTH_RANGE = int(Variable.get("facts_month_range"))
# FACTS_MONTH_RANGE = 0


REMAINS_NEXT_MONTH_QUERY = read_sql_file("remains_next_month.sql")
REMAINS_MOVEMENTS_QUERY = read_sql_file("remains_movements.sql").format(
    month_range=FACTS_MONTH_RANGE
)


def get_data_interval_start(month_range: int, data_interval_end: pendulum.DateTime):
    """
    Calculates the start date of a data interval based on the provided end date and a specific number of months
    defined by the 'FACTS_MONTH_RANGE' Airflow variable. This start date is used to define the scope of data
    processing tasks in a DAG.

    The function adjusts the provided end date by subtracting one day and then subtracts a number of months specified
    by 'FACTS_MONTH_RANGE'. It returns the starting day of the month for the resultant date, effectively setting the
    boundary for data operations that should consider data starting from the beginning of that month.

    Parameters:
        month_range (int): how many months backwards to start from
        data_interval_end (pendulum.DateTime): The end date of the data interval, from which the start date will
        be calculated.

    Returns:
        pendulum.DateTime: The calculated start date of the data interval, adjusted to the beginning of the month.
        This start date is used to set the range for data processing tasks in terms of month and year.

    Example:
        >>> get_data_interval_start(pendulum.datetime(2024, 12, 31))
        DateTime(2024, 9, 1, 0, 0, 0, tzinfo=Timezone('UTC'))

    Notes:
        - The subtraction of one day from the 'data_interval_end' is to ensure that the calculation correctly aligns
        with the end of the previous day, avoiding any off-by-one errors in monthly calculations.
    """
    data_interval_end = data_interval_end.subtract(days=1)
    return (
        data_interval_end.subtract(months=month_range).start_of("month").add(days=1)
    )  # adding one day to the start of the month because we calculate remains for the previous day


def get_next_month_start_date(data_interval_end: pendulum.DateTime):
    """
    Calculates the start date of the month following the specified data interval end date, except when the
    current month is the same as the data interval end month. In such cases, it returns a predefined distant future date.

    This function primarily supports scenarios where data processing needs to skip current month operations or extend
    to a distant future date to prevent premature data processing.

    Parameters:
        data_interval_end (pendulum.DateTime): The end date for the current data processing interval.

    Returns:
        pendulum.DateTime: Returns the start date of the next month unless the current month is the same as
        the interval end month, in which case it returns November 1, 3999.

    Examples:
        >>> get_next_month_start_date(pendulum.datetime(2024, 12, 31))
        DateTime(2025, 1, 1, 0, 0, 0, tzinfo=Timezone('UTC'))

        >>> get_next_month_start_date(pendulum.now())
        DateTime(3999, 11, 1, 0, 0, 0, tzinfo=Timezone('UTC'))

    Notes:
        - This function ensures that data processing does not accidentally include incomplete data from the current month
          by pushing the start date far into the future when the interval end matches the current month.
        - The date '3999-11-01' is used as an arbitrarily distant future date to effectively halt processing steps that
          rely on this function for date calculations during the current month.
    """
    # data_interval_end = data_interval_end.subtract(days=1)
    current_month = pendulum.today().format("YYYYMM")
    if current_month == data_interval_end.format("YYYYMM"):
        return pendulum.DateTime(
            3999, 11, 1
        )  # in 1C the current month is 5999-11-1 but in sql file we are adding 2000 years

    return (
        data_interval_end.subtract(days=1).add(months=1).start_of("month")
    )  # get start of the next month if it is not current month


@task
def load_to_duckdb():
    """
    Loads data from CSV files into DuckDB, creating or replacing tables for two specific datasets: 'remains_next_month_raw'
    and 'remains_movements_raw'. This function serves as a crucial initial step in the ETL process, staging raw data
    in DuckDB before it undergoes transformation.

    It reads data from two predefined CSV file paths (stored in global variables), parsing them into tables with specified
    column names. This ensures that the data structure is consistent and correctly aligned for subsequent processing tasks.

    No parameters are required as the function operates based on predefined file paths and column names.

    Returns:
        None: This function performs database operations (creating or replacing tables) but does not return any value.

    Raises:
        IOError: If the CSV files do not exist at the specified paths or cannot be read.
        duckdb.DuckDBError: If there is an issue executing the SQL commands, such as syntax errors or problems with
        data types that prevent table creation.

    Example:
        >>> load_to_duckdb()
        # This will attempt to load data from '/tmp/remains_next_month.csv' and '/tmp/remains_movements.csv' into DuckDB.

    Notes:
        - The function ensures that any existing tables with the same names are replaced, providing a clean slate
        for each ETL run.
        - The CSV file paths and column names are hardcoded based on the project's configuration and expected input
        structure.
        - It is assumed that the DuckDB database file specified by 'DUCKDB_TEMP_FILE' is accessible and writable.
    """

    conn = duckdb.connect(DUCKDB_TEMP_FILE)

    # names parameter specifies column names since bcp doesn't export data with column names
    conn.sql(
        f"""CREATE OR REPLACE TABLE remains_next_month_raw AS SELECT * FROM read_csv('{REMAINS_NEXT_MONTH_TEMP_FILE}',names= [ 
            '_Period',
            'СкладКомпании_ID',
            'Поставщик_ID',
            'Номенклатура_ID',
            'Количество',
            'Сумма',
            'СуммаНДС'
         ])"""
    )

    conn.sql(
        f"""CREATE OR REPLACE TABLE remains_movements_raw AS SELECT * FROM read_csv('{REMAINS_MOVEMENTS_TEMP_FILE}',names= [ 
            '_Period',
            'СкладКомпании_ID',
            'Поставщик_ID',
            'Номенклатура_ID',
            '_RecordKind',
            'Количество',
            'Сумма',
            'СуммаНДС'
         ])"""
    )
    conn.close()


@task
def transform_remains_accumulative():
    """
    Transforms and aggregates the remains data loaded into DuckDB from two sources: 'remains_next_month_raw' and
    'remains_movements_raw'. This function creates new tables 'remains_next_month' and 'remains_movements', which
    respectively process the raw data into a format suitable for analysis and further operations.

    This transformation includes adjusting date formats, aggregating quantities, costs, and VAT, and creating a combined
    table 'remains_accumulative' that merges the data from the next month and movements tables with proper adjustments.

    Returns:
        None: This function performs database operations but does not return any values.

    Raises:
        duckdb.DuckDBError: If there is a failure in executing SQL commands due to issues such as data type mismatches
        or syntax errors within the SQL queries.

    Example:
        >>> from airflow.models.taskinstance import TaskInstance
        >>> transform_remains_accumulative(pendulum.datetime(2024, 12, 31), TaskInstance(task=task, execution_date=pendulum.datetime(2024, 12, 31)))
        # This would process the data for the interval ending on December 31, 2024.

    Notes:
        - The function assumes the presence of raw data tables: 'remains_next_month_raw' and 'remains_movements_raw'.
        - It creates intermediate tables to facilitate the transformation, handling large data volumes by grouping and
          aggregating essential metrics.
        - After processing, it combines the data into 'remains_accumulative', considering both additions and subtractions
          of stock as specified by '_RecordKind' from 'remains_movements_raw'.
    """
    conn = duckdb.connect(DUCKDB_TEMP_FILE)

    conn.sql(
        """
        CREATE OR REPLACE TABLE remains_next_month AS
        SELECT 
            CAST(CASE WHEN _Period =  DATE '5999-11-01' THEN current_date ELSE  _Period  - INTERVAL 2000 YEAR END AS DATE) as date,--if it is 5999-11-01 set to today's date
            СкладКомпании_ID AS warehouse_id,
            Поставщик_ID AS contragent_id,
            Номенклатура_ID AS product_id,
            SUM(Количество) AS quantity,
            SUM(Сумма) AS cost_price,
            SUM(СуммаНДС) AS cost_price_VAT
        FROM remains_next_month_raw
        GROUP BY 
             date,
             warehouse_id,
             contragent_id,
             product_id
             """
    )
    conn.sql(
        """
        CREATE OR REPLACE TABLE remains_movements AS
        SELECT 
            CAST(_Period AS DATE) - INTERVAL 2000 YEAR AS date,
            СкладКомпании_ID AS warehouse_id,
            Поставщик_ID AS contragent_id,
            Номенклатура_ID AS product_id,
            SUM(CASE _RecordKind WHEN 0 THEN -Количество ELSE Количество END) AS quantity,
            SUM(CASE _RecordKind WHEN 0 THEN -Сумма ELSE Сумма END) AS cost_price,
            SUM(CASE _RecordKind WHEN 0 THEN -СуммаНДС ELSE СуммаНДС END) AS cost_price_VAT
        FROM remains_movements_raw
        GROUP BY 
             date,
             warehouse_id,
             contragent_id,
             product_id
             """
    )

    # Create accumulative table combining both next month and movements data
    conn.sql(
        f"""

        CREATE OR REPLACE TABLE remains_accumulative AS
        SELECT 
            date,
            warehouse_id,
            COALESCE(contragent_id,'{EMPTY_NULL_PLACEHOLDER_FOR_REFERENCES}') AS contragent_id,
            product_id,
            SUM(quantity) AS quantity,
            SUM(cost_price) AS cost_price,
            SUM(cost_price_VAT) AS cost_price_VAT
        FROM (
            SELECT
                n.date,
                n.warehouse_id,
                n.contragent_id,
                n.product_id,
                n.quantity,
                n.cost_price,
                n.cost_price_VAT
            FROM remains_next_month  n
            UNION ALL
            SELECT
                m.date,
                m.warehouse_id,
                m.contragent_id,
                m.product_id,
                m.quantity,
                m.cost_price,
                m.cost_price_VAT
            FROM remains_movements m
        )
        GROUP BY  
            date,
            warehouse_id,
            COALESCE(contragent_id,'{EMPTY_NULL_PLACEHOLDER_FOR_REFERENCES}'),
            product_id
        HAVING SUM(quantity)!=0 or SUM(cost_price) !=0 -- filtering out empty rows
        """
    )

    conn.close()


@task
def transform_remains_all_combinations(data_interval_end: pendulum.DateTime):
    """
    Generates a comprehensive dataset that includes all possible combinations of dates, warehouses, contragents, and
    products by crossing distinct product combinations from accumulated remains data with a full calendar. This is
    essential for ensuring complete data coverage in analytical queries and reports.

    The function constructs a 'calendar' table based on the range specified from the start of the data interval
    up to the end of the next month or the current processing month, ensuring all days are covered. It then combines
    this calendar with distinct product details to form the 'remains_all_combinations' table.

    Parameters:
        data_interval_end (pendulum.DateTime): The end date of the data processing interval, used to determine the
        range of the calendar and subsequently, the range of date combinations to be prepared.

    Returns:
        None: This function performs database operations to create tables but does not return any values.

    Raises:
        duckdb.DuckDBError: If there is an issue executing SQL commands, such as data type mismatches or syntax errors
        in the SQL queries used to create the tables.

    Example:
        >>> transform_remains_all_combinations(pendulum.datetime(2024, 12, 31))
        # This would create the 'calendar' and 'remains_all_combinations' tables up to and including December 31, 2024.

    Notes:
        - The start date for the calendar is calculated using the 'get_data_interval_start' function based on the provided
          end date and configured month range.
        - The function uses the 'get_next_month_start_date' to adjust the end date for the calendar, ensuring that
          operations for the current month are postponed if the processing date aligns with the current month.
        - It is crucial that 'remains_accumulative' contains up-to-date and accurate data before this function is
          executed to ensure that all possible combinations are accurately represented.
    """
    conn = duckdb.connect(DUCKDB_TEMP_FILE)

    # Determine the start date for the next month to set up the calendar range
    start_next_month = get_next_month_start_date(data_interval_end)

    # If the calculated start of next month is a 1c current month, revert to current interval end
    if start_next_month == pendulum.DateTime(3999, 11, 1):
        start_next_month = data_interval_end

    # Create a calendar table with all dates from the start of the data interval to the start of the next month
    conn.sql(
        f"""
        CREATE OR REPLACE TABLE calendar AS 

        WITH RECURSIVE CALENDAR_CTE AS(
            SELECT CAST('{get_data_interval_start(FACTS_MONTH_RANGE,data_interval_end)}' AS DATE) AS date
            UNION ALL
            SELECT date + INTERVAL 1 DAY
            FROM CALENDAR_CTE
            WHERE Date < '{start_next_month}'
        )
        SELECT date FROM CALENDAR_CTE
    """
    )

    # Create a table with distinct product details from accumulated remains data
    conn.sql(
        """
        CREATE OR REPLACE TABLE remains_distinct_products AS 
        SELECT 
            DISTINCT 
                warehouse_id,
                contragent_id,
                product_id
        FROM remains_accumulative
    """
    )

    # Combine distinct product details with the calendar to cover all date and product combinations
    conn.sql(
        """
        CREATE OR REPLACE TABLE remains_all_combinations AS
        SELECT  
           date,
           warehouse_id,
           contragent_id,
           product_id
        FROM remains_distinct_products CROSS JOIN calendar
    """
    )

    conn.close()


@task
def transform_remains_for_every_day(
    data_interval_end: pendulum.DateTime, ti: TaskInstance
):
    """
    Transforms and prepares daily remains data by combining and structuring data from accumulated remains with all
    possible date, warehouse, contragent, and product combinations. This function finalizes the data structure for
    detailed daily analysis and exports the transformed data to an S3 bucket in Parquet format.

    The process involves using window functions to calculate running totals and final amounts of quantities, costs,
    and VAT across all combinations. The result is a detailed dataset that provides a snapshot of remains for each
    day, suitable for time-series analysis and daily reporting.

    Parameters:
        data_interval_end (pendulum.DateTime): The end date of the data processing interval, used to define the scope
        of data to be processed and exported.
        ti (TaskInstance): The TaskInstance object provided by Airflow, used here for pushing export paths to XCom for
        subsequent tasks.

    Returns:
        None: This function performs complex SQL transformations and file operations but does not return any value.

    Raises:
        duckdb.DuckDBError: If there is a failure in executing SQL commands, potentially due to issues like data type
        mismatches or syntax errors within the SQL queries.
        IOError: If there are issues accessing or writing to the S3 bucket, or if the connection settings are incorrect.

    Example:
        >>> from airflow.models.taskinstance import TaskInstance
        >>> transform_remains_for_every_day(pendulum.datetime(2024, 12, 31), TaskInstance(task=task, execution_date=pendulum.datetime(2024, 12, 31)))
        # This function will process the data and export it for the interval ending on December 31, 2024.

    Notes:
        - The function first sets a memory limit for DuckDB to ensure efficient processing without overwhelming the system.
        - It constructs and populates the 'remains_for_every_day' table by right joining the 'remains_accumulative' data
          with all date combinations to ensure every possible day is accounted for.
        - The window function further refines this data to include rolling sums for quantities, costs, and VAT which are
          crucial for daily balance calculations.
        - The final data is exported to an S3 bucket using DuckDB's HTTP File System (httpfs) extension, with configuration
          details for S3 access directly included in the function.
        - Ensure that the S3 bucket and path configurations are secured and managed outside of the function for
          production environments.
    """
    conn = duckdb.connect(DUCKDB_TEMP_FILE)

    conn.sql("SET memory_limit = '5GB';")

    # Right join accumulative remains data with all possible date and product combinations
    conn.sql(
        """
    CREATE OR REPLACE TABLE remains_for_every_day
    AS
    SELECT
        c.date,
        c.warehouse_id,
        c.contragent_id,
        c.product_id,
        r.quantity,
        r.cost_price,
        r.cost_price_VAT
    FROM remains_accumulative r
        RIGHT JOIN remains_all_combinations c
            ON r.date=c.date AND r.warehouse_id = c.warehouse_id AND r.contragent_id=c.contragent_id AND r.product_id=c.product_id
    """
    )

    df = conn.sql(
        "SELECT warehouse_id,count(*) AS row_count FROM remains_for_every_day GROUP BY warehouse_id ORDER by count(*) DESC"
    ).df()

    CHUNK_SIZE = 5

    chunks = []

    # filling up chunks
    for index, row in df.iterrows():
        max_warehouse_id = row["warehouse_id"]

        if max_warehouse_id in [
            inner for outer in chunks for inner in outer
        ]:  # if it is already processed skip it
            break

        # add current warehouse(which is max at the moment and delete from dataframe)
        chunk = [max_warehouse_id]
        index = df[df["warehouse_id"] == max_warehouse_id].index
        df.drop(index, inplace=True)

        for i in range(CHUNK_SIZE):
            # getting warehouse with minimum row_count at the moment
            min_warehouse_id = conn.sql(
                "SELECT arg_min(warehouse_id,row_count) FROM df"
            ).fetchall()[0][0]

            if min_warehouse_id is None:
                break

            chunk.append(min_warehouse_id)
            index = df[df["warehouse_id"] == min_warehouse_id].index
            df.drop(index, inplace=True)

        chunks.append(chunk)

    conn.sql(
        """
    CREATE TABLE IF NOT EXISTS remains_for_every_day_with_window_function 
     (
        date TIMESTAMP,
        warehouse_id VARCHAR,
        contragent_id VARCHAR,
        product_id VARCHAR,
        quantity DOUBLE,
        cost_price DOUBLE,
        cost_price_VAT double
     )
    """
    )

    # for every chunk of warehouses calculate remains for everyday and then add into main table
    for chunk in chunks:
        query = f"""
        CREATE TEMP TABLE temp_table AS
        SELECT
                date - INTERVAL 1 DAY AS date,
                warehouse_id,
                contragent_id,
                product_id,
                SUM(quantity) OVER(PARTITION BY warehouse_id,contragent_id,product_id ORDER BY date DESC) AS quantity,
                SUM(cost_price) OVER(PARTITION BY warehouse_id,contragent_id,product_id ORDER BY date DESC) AS cost_price,
                SUM(cost_price_VAT) OVER(PARTITION BY warehouse_id,contragent_id,product_id ORDER BY date DESC) AS cost_price_VAT
        FROM remains_for_every_day
        WHERE  warehouse_id IN {tuple(chunk)}
        """
        print("Executing query: \n", query)
        conn.sql(query)

        conn.sql(  # insert processed chunk into final table
            """INSERT INTO remains_for_every_day_with_window_function 
                SELECT * FROM temp_table 
                WHERE round(quantity,3)!=0 OR round(cost_price,2)!=0 OR round(cost_price_VAT,2)!=0
            """
        )

        conn.sql("DROP TABLE temp_table")

    # Prepare and execute export to S3
    conn.sql("LOAD httpfs;")

    remains_filename = "remains.parquet"
    remains_s3_key = f"{BUCKET_NAME}/{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}/{S3_FOLDER}/{remains_filename}"
    conn.sql(
        f"COPY remains_for_every_day_with_window_function TO 's3://{remains_s3_key}';"
    )

    # TODO: undo
    conn.sql("DROP TABLE remains_for_every_day_with_window_function")

    conn.close()
    ti.xcom_push(key="s3_key", value=remains_s3_key)


@task
def remove_temp_files():
    os.remove(DUCKDB_TEMP_FILE)
    os.remove(REMAINS_NEXT_MONTH_TEMP_FILE)
    os.remove(REMAINS_MOVEMENTS_TEMP_FILE)


@dag(
    default_args={
        "owner": "ubaitur5",
        "on_failure_callback": send_error_message_telegram,
    },
    schedule_interval="0 1 * * *",
    template_searchpath=["/opt/airflow/dags/include/sql_files/"],
    start_date=pendulum.DateTime(2024, 1, 1),
    doc_md=doc_md,
    tags=["etl", "facts"],
    max_active_runs=1,
    catchup=False,
    user_defined_macros={
        "build_delete_partition_query": build_delete_partition_query,
        "get_data_interval_start": get_data_interval_start,
        "get_next_month_start_date": get_next_month_start_date,
    },
)
def remains():

    extract_remains_next_month = BashOperator(
        task_id="extract_remains_next_month",
        bash_command=f"""/opt/mssql-tools18/bin/bcp "
            {REMAINS_NEXT_MONTH_QUERY}
        " queryout {REMAINS_NEXT_MONTH_TEMP_FILE} -c -t, -D -S WIN-STANDBY -d AR_TRADE -U SR -P SR20@#""",
    )

    extract_remains_movements = BashOperator(
        task_id="extract_remains_movements",
        bash_command=f"""/opt/mssql-tools18/bin/bcp "
            {REMAINS_MOVEMENTS_QUERY}
        " queryout {REMAINS_MOVEMENTS_TEMP_FILE} -c -t, -D -S WIN-STANDBY -d AR_TRADE -U SR -P SR20@#""",
    )

    ## here we get division_id by joining to warehouse table in clickhouse dwh
    load_remains = ClickHouseOperator(
        task_id="load_remains",
        database="dwh",
        sql="remains_load.sql",
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    drop_partitions = ClickHouseOperator(
        task_id="drop_partitions",
        database="dwh",
        sql=f"ALTER TABLE remains {{{{build_delete_partition_query({FACTS_MONTH_RANGE},data_interval_end)}}}}",
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    (
        [extract_remains_next_month, extract_remains_movements]
        >> load_to_duckdb()
        >> transform_remains_accumulative()
        >> transform_remains_all_combinations()
        >> transform_remains_for_every_day()
        >> drop_partitions
        >> load_remains
        >> remove_temp_files()
    )


remains()
