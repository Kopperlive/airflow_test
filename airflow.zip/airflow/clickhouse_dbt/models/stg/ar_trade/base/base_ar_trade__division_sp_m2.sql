WITH source AS (
    SELECT * FROM {{ ref('division_sp_m2') }}
)

, renamed AS (
    SELECT

        {{ transform_string('code') }} AS code
        , CAST(m2 AS Decimal(19, 2)) AS m2
    FROM source
)


SELECT * FROM renamed
