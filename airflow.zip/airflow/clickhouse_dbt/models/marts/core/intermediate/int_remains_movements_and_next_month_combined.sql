WITH movements AS (
    SELECT * FROM {{ ref('base_ar_trade__remains_movements') }}
)

, next_month AS (
    SELECT * FROM {{ ref('base_ar_trade__remains_next_month') }}
)

, calendar AS (
    SELECT *
    FROM {{ source('raw_dbt','remains_calendar') }}
)

, final AS (
    SELECT
        date
        , warehouse_id
        , contragent_id
        , product_id
        , SUM(quantity) AS quantity
        , SUM(cost_price) AS cost_price
        , SUM(cost_price_VAT) AS cost_price_VAT
    FROM (
        SELECT
            date
            , warehouse_id
            , contragent_id
            , product_id
            , if(is_stock_out = 0, -quantity, quantity) AS quantity
            , if(is_stock_out = 0, -cost_price, cost_price) AS cost_price
            , if(is_stock_out = 0, -cost_price_VAT, cost_price_VAT) AS cost_price_VAT

        FROM movements
        WHERE date >= (select MIN(date) FROM calendar) --we need to take 2nd day in a month,cause we calculate backwards

        UNION ALL

        SELECT
            date
            , warehouse_id
            , contragent_id
            , product_id
            , quantity
            , cost_price
            , cost_price_VAT
        FROM next_month
    )
    GROUP BY ALL
)

SELECT * FROM final
