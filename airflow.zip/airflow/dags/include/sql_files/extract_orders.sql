SELECT 
       _IDRRef
       , DATEADD(YEAR,-2000,z._Date_Time) AS _Date_Time
       , DATEADD(YEAR,-2000,z.СрокПоставки) AS СрокПоставки
       , z._Number
       , Автор_ID
       , ПодразделениеКомпании_ID
       , Контрагент_ID
       , ДоговорВзаиморасчетов_ID
       , ЕдиницаИзмерения_ID
       , Комментарий
       , ТипЦен_ID
       , ХозОперация_ID
       , СкладКомпании_ID
       , z.ПитонСтатус
       , Номенклатура_ID
	   , СтавкаНДС_ID
       , zt.Сумма
       , zt.СуммаНДС
       , zt.Количество

FROM [vw_ЗаказПоставщику] z WITH(NOLOCK)
    INNER JOIN [vw_ЗаказПоставщику_Товары] AS zt WITH(NOLOCK)
        ON z._Date_Time >= '{{get_data_interval_start(data_interval_end).add(years=2000) | ds_nodash}}' AND z._Date_Time<'{{data_interval_end.add(years=2000) | ds_nodash}}'
           AND z._IDRRef = zt.Ссылка
           AND z._Marked = 0x00
           AND z._Posted = 0x01