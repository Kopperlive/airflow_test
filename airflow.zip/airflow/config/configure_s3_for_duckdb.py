import duckdb
import os

endpoint = os.environ.get('S3_ENDPOINT')
access_key = os.environ.get('S3_ACCESS_KEY')
private_key = os.environ.get('S3_SECRET_KEY')


conn = duckdb.connect()

# Change ENDPOINT key to the minio instance and fill the missing keys
query = f"""
CREATE PERSISTENT SECRET my_secret (
    TYPE S3,
    ENDPOINT '{endpoint}',
    URL_STYLE 'path',
    USE_SSL false,
    KEY_ID '{access_key}',
    SECRET '{private_key}'
);
"""

conn.sql(query)
