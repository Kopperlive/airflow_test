SELECT 
	DATEADD(YEAR,-2000,m.ДатаВводаВАссортимент) AS _Date_Time
	, m._Number
	, m._IDRRef
	, m.Автор_ID
	, m.Комментарий
	, p.ПодразделениеКомпании_ID
	, m.ХозОперация_ID
	, m.ТипЦен_ID
	, s.Номенклатура_ID
	, s.СтавкаНДС_ID
	, s.Цена

FROM vw_ИзменениеАссортиментаПодразделения m

	JOIN vw_ИзменениеАссортиментаПодразделения_Товары s
		ON m._IDRRef=s.Ссылка

	JOIN vw_ИзменениеАссортиментаПодразделения_Подразделения p
		ON p.Ссылка=m._IDRRef

	WHERE m.ДатаВводаВАссортимент >= '{{get_data_interval_start(data_interval_end).add(years=2000) | ds_nodash}}' AND m.ДатаВводаВАссортимент<'{{data_interval_end.add(years=2000) | ds_nodash}}'
		AND m._Posted=0x01 AND m._Marked=0x00