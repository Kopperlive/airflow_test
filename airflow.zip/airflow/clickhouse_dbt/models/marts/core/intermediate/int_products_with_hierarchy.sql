WITH products AS (
    SELECT * FROM {{ ref('stg_ar_trade__products') }}
)

, hierarchy AS (
    SELECT * FROM {{ ref('int_products_hierarchy') }}
)

, final AS (
    SELECT
        products.id AS id
        , products.parent_id AS parent_id
        , hierarchy.level AS level_in_the_hierarchy
        , CAST(hierarchy.fifth_category_id AS UUID) AS fifth_category_id
        , hierarchy.fourth_category_id AS fourth_category_id
        , hierarchy.third_category_id AS third_category_id
        , hierarchy.second_category_id AS second_category_id
        , hierarchy.first_category_id AS first_category_id
        , products.code AS code
        , products.articul AS articul
        , products.status_abbreviation AS status_abbreviation
        , products.status_description AS status_description
        , products.description AS description
        , products.description_full AS description_full
        , products.description_kg AS description_kg
        , products.type AS type
        , products.trademark AS trademark
        , products.price_segment AS price_segment
        , products.country AS country
        , products.is_deleted AS is_deleted
        , products.is_item AS is_item
        , products.is_halal AS is_halal
        , products.is_import AS is_import
        , products.is_certificate AS is_certificate
        , products.is_returnable AS is_returnable
        , products.net_weight AS net_weight
        , products.gross_weight AS gross_weight
        , products.quantity_per_package AS quantity_per_package

    FROM products
    INNER JOIN hierarchy
        ON products.id = hierarchy.id
)

SELECT * FROM final
