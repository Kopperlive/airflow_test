import os


def read_sql_file(file_name: str) -> str:
    """
    Reads the contents of an SQL file from a specified directory and returns it as a string. The function
    assumes that the SQL file is stored within the 'dags/include/sql_files' directory of the Apache Airflow
    installation (typically at '/opt/airflow').

    Parameters
    ----------
    file_name : str
        The name of the SQL file to be read. The file name should include any file extension, typically '.sql'.

    Returns
    -------
    str
        The content of the SQL file as a single string.

    Examples
    --------
    >>> sql_content = read_sql_file('example_query.sql')
    >>> print(sql_content)
    -- SQL content displayed here

    Notes
    -----
    This function is specifically designed to be used within the Apache Airflow environment, where it's common
    to store SQL files in a structured directory. The path is hardcoded to match the expected directory structure
    in a typical Airflow installation. If the directory structure differs, or if the function is used in a different
    environment, the path in the function must be modified accordingly.
    """
    # Define the path to the SQL file
    sql_file_path = "/opt/airflow/dags/include/sql_files/" + file_name
    # get the current working directory

    with open(sql_file_path, "r") as file:
        return file.read()


def to_sql_hex(binary: bytes) -> str:
    """Convert binary to hexadecimal and add 0x as SQL requires"""
    return "0x" + binary.hex().upper()
