from airflow.exceptions import AirflowException
from airflow.providers.amazon.aws.transfers.sql_to_s3 import SqlToS3Operator


class SqlToS3OperatorImproved(SqlToS3Operator):
    """
    Improved version of SqlToS3Operator.
    What was added:
        - Automatically creates s3_key based on ``s3_bucket``,``report_name``,``filename`` fields,
          path to ``report_name`` is decided with the help of jinja templating of ``data_interval_end`` field.
          For instance save file into ``s3_bucket`` with a key ``2024/6/20/report_turnover/extract_turnover.csv``
        - you can access this value by xcom via key <return_value>,for instance, ``xcom_pull(key="return_value",task_ids="extract_some_data")``


    What was removed:
        - You cannot pass ``s3_key`` since we will be generating this column automatically

    .. seealso::
        For more information on how to use this operator, take a look at the guide:
        :ref:`howto/operator:SqlToS3Operator`

    :param query: the sql query to be executed. If you want to execute a file, place the absolute path of it,
        ending with .sql extension. (templated)
    :param s3_bucket: bucket where the data will be stored. (templated)
    :param report_name: Name of the report to which the file belongs. (templated)
    :param filename: desired filename for the file. (templated)
    :param replace: whether or not to replace the file in S3 if it previously existed
    :param sql_conn_id: reference to a specific database.
    :param sql_hook_params: Extra config params to be passed to the underlying hook.
        Should match the desired hook constructor params.
    :param parameters: (optional) the parameters to render the SQL query with.
    :param aws_conn_id: reference to a specific S3 connection
    :param verify: Whether or not to verify SSL certificates for S3 connection.
        By default SSL certificates are verified.
        You can provide the following values:

        - ``False``: do not validate SSL certificates. SSL will still be used
                (unless use_ssl is False), but SSL certificates will not be verified.
        - ``path/to/cert/bundle.pem``: A filename of the CA cert bundle to uses.
                You can specify this argument if you want to use a different
                CA cert bundle than the one used by botocore.
    :param file_format: the destination file format, only string 'csv', 'json' or 'parquet' is accepted.
    :param max_rows_per_file: (optional) argument to set destination file number of rows limit, if source data
        is larger than that, it will be dispatched into multiple files.
        Will be ignored if ``groupby_kwargs`` argument is specified.
    :param pd_kwargs: arguments to include in DataFrame ``.to_parquet()``, ``.to_json()`` or ``.to_csv()``.
    :param groupby_kwargs: argument to include in DataFrame ``groupby()``.
    """

    def __init__(
        self,
        report_name: str,
        filename: str,
        time_granularity: str = "daily",
        *args,
        **kwargs,
    ):
        if "s3_key" in kwargs:
            raise AirflowException(
                "The argument s3_key is deprecated, please remove it. "
                "Instead set report_name and filename,everything else will be generated automatically"
            )

        datetime_part = "{{data_interval_end.year}}/{{data_interval_end.month}}/{{data_interval_end.day}}"

        if time_granularity == "hourly":

            datetime_part += "/{{data_interval_end.hour}}"

        s3_key = datetime_part + "/" + report_name + "/" + filename

        super().__init__(s3_key=s3_key, *args, **kwargs)

    def execute(self, context):

        super().execute(context)

        return (
            self.s3_key
        )  # you can access this value by xcom via key <return_value>,for instance, xcom_pull(key="return_value",task_ids="extract_some_data")
