import pendulum
from airflow.decorators import dag
from airflow.providers.ssh.operators.ssh import SSHOperator
from common_utils.telegram_utils import send_error_message_telegram

doc_md = """
# ClickHouse Database Backup Process

This DAG is responsible for managing the backup of ClickHouse databases. It ensures that the database is backed up daily and that backups are stored securely in an S3 bucket. The process is designed to run early in the morning to minimize impact on live operations.

## Process Overview

1. **Create Backup Locally**: The DAG executes a backup of the ClickHouse database, storing it locally on the server where ClickHouse is running. The backup includes configurations and role-based access control settings.
2. **Upload Backup to S3**: Once the backup is created locally, it is then uploaded to an S3 bucket for long-term storage. This ensures that backups are available off-site for disaster recovery purposes.
3. **Notification**: If the backup process encounters any issues, a notification is sent via Telegram using a utility function.

## Details

- **Schedule**: The DAG runs daily at 2 AM UTC, capturing data up to the end of the previous day. This schedule helps ensure that the backup is as current as possible while avoiding peak usage times.
- **Backup Filename**: The backup file is named according to the date it was created, following the format YYYYMMDD, which helps in organizing and retrieving backups based on when they were taken.
"""


@dag(
    default_args={
        "owner": "ubaitur5",
        "on_failure_callback": send_error_message_telegram,
    },
    schedule_interval="0 2 * * *",
    start_date=pendulum.DateTime(2024, 7, 23),
    doc_md=doc_md,
    tags=["clickhouse-maintenance", "backup"],
    catchup=False,
)
def clickhouse_backup():

    backup_filename = "dwh_asia_{{data_interval_end.year}}{{data_interval_end.strftime('%m')}}{{data_interval_end.strftime('%d')}}"
    backup_folder = "{{data_interval_end.year}}/{{data_interval_end.strftime('%m')}}/{{data_interval_end.strftime('%d')}}"

    create_backup_locally = SSHOperator(
        task_id="create_backup_locally",
        ssh_conn_id="ssh__srv-prod-ch",
        command=f"docker exec -u 0 clickhouse-server bash -c 'clickhouse-backup create {backup_filename} --configs --rbac'",
        conn_timeout=20,
        cmd_timeout=900,  # 15 minutes
    )

    upload_backup_to_remote_storage = SSHOperator(
        task_id="upload_backup_to_remote_storage",
        ssh_conn_id="ssh__srv-prod-ch",
        command=f"docker exec -u 0 clickhouse-server bash -c 'S3_PATH='{backup_folder}' clickhouse-backup upload {backup_filename}'",
        conn_timeout=20,
        cmd_timeout=1800,  # 30 minutes
    )

    create_backup_locally >> upload_backup_to_remote_storage


clickhouse_backup()
