WITH products AS (
    SELECT * FROM {{ ref('base_ar_trade__products') }}
)

, product_statuses AS (
    SELECT * FROM {{ ref('base_ar_trade__product_statuses') }}
)

, product_types AS (
    SELECT * FROM {{ ref('base_ar_trade__product_types') }}
)

, trademarks AS (
    SELECT * FROM {{ ref('base_ar_trade__trademarks') }}
)

, price_segments AS (
    SELECT * FROM {{ ref('base_ar_trade__price_segments') }}
)

, countries AS (
    SELECT * FROM {{ ref('base_ar_trade__countries') }}
)

, final AS (
    SELECT
        --ids
        products.id AS id
        , products.parent_id AS parent_id

        -- codes
        , products.code AS code
        , products.articul AS articul
        , {{ transform_string('product_statuses.abbreviation') }} AS status_abbreviation
        , {{ transform_string('product_statuses.description') }} AS status_description

        --names
        , products.description AS description
        , products.description_full AS description_full
        , products.description_kg AS description_kg

        -- other values
        , {{ transform_string('product_types.description') }} AS type
        , {{ transform_string('trademarks.description') }} AS trademark
        , {{ transform_string('price_segments.description') }} AS price_segment
        , {{ transform_string('countries.description') }} AS country

        -- product measurements
        , products.net_weight AS net_weight
        , products.gross_weight AS gross_weight
        , products.quantity_per_package AS quantity_per_package

        -- booleans
        , products.is_deleted AS is_deleted
        , products.is_item AS is_item
        , products.is_halal AS is_halal
        , products.is_import AS is_import
        , products.is_certificate AS is_certificate
        , products.is_returnable AS is_returnable

    FROM products

    LEFT JOIN product_statuses
        ON
        products.product_status_id = product_statuses.id

    LEFT JOIN product_types
        ON
        products.product_type_id = product_types.id

    LEFT JOIN trademarks
        ON
        products.trademark_id = trademarks.id

    LEFT JOIN price_segments
        ON
        products.price_segment_id = price_segments.id

    LEFT JOIN countries
        ON
        products.country_id = countries.id
)

SELECT * FROM final
