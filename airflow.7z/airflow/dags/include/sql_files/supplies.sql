SELECT 
	p._Date_Time,
	p._Number,
	CONVERT(NCHAR(34),p._IDRRef,1) as _IDRRef,
	CONVERT(NCHAR(34),p.Автор_ID,1) AS Автор_ID,
	CONVERT(NCHAR(34),p.Контрагент_ID,1) AS Контрагент_ID,
	CONVERT(NCHAR(34),p.ДоговорВзаиморасчетов_ID,1) AS ДоговорВзаиморасчетов_ID,
	CONVERT(NCHAR(34),p.СкладКомпании_ID,1) AS СкладКомпании_ID,
    CONVERT(NCHAR(34),pt.Номенклатура_ID,1) AS Номенклатура_ID,
	CONVERT(NCHAR(34),p.ТипЦен_ID,1) AS ТипЦен_ID,
	CONVERT(NCHAR(34),p.ХозОперация_ID,1) AS ХозОперация_ID,
	CONVERT(NCHAR(34),p.ПодразделениеКомпании_ID,1) AS ПодразделениеКомпании_ID,
	CONVERT(NCHAR(34),prp.ЗаказПоставщику_ID,1) AS ЗаказПоставщику_ID,
	CONVERT(NCHAR(34),pt.СтавкаНДС_ID,1) AS СтавкаНДС_ID,
	pt.Количество,
	pt.СуммаБезНалогов,
	pt.СуммаНДС
FROM vw_ПоступлениеТоваров AS p WITH (NOLOCK)
	INNER JOIN vw_ПоступлениеТоваров_Товары pt WITH(NOLOCK) 
        ON p._Date_Time >= '{{get_data_interval_start(data_interval_end,params.month_range).add(years=2000) | ds_nodash}}' AND p._Date_Time<'{{data_interval_end.add(years=2000) | ds_nodash}}'
						AND pt.Ссылка = p._IDRRef
						AND p._Marked = 0x00
						AND p._Posted = 0x01

	OUTER APPLY(
		SELECT -- getting corresponding order of the supply 
            TOP 1
            ЗаказПоставщику_ID 
		FROM vw_ПоступлениеТоваров_РаспределениеПоставки pr WITH (NOLOCK)
		WHERE pr.Ссылка=p._IDRRef
	) AS prp 



