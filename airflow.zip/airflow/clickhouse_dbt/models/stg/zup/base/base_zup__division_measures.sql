WITH source AS (

    SELECT * FROM {{ source('raw_dbt','zup_division_measures') }}

)

, renamed AS (
    SELECT
        CAST("Год" AS UInt16) AS year
        , CAST("Месяц" AS UInt16) AS month
        , {{transform_string('"Подразделение"') }} AS division
        , {{transform_decimal('"ФОТ"')}} AS wage_fund
        , {{transform_decimal('"ЧЧ"')}} AS man_hours
        , {{transform_decimal('"ПлановаяЧисленность"')}} AS planned_number_of_employees
        , {{transform_decimal('"ЧасовНеявки"')}} AS hours_absent
        , {{transform_decimal('"ЧасовБольничных"')}} AS hours_sick_leave
    FROM source
)
SELECT * FROM renamed