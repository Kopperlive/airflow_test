WITH source AS (
    SELECT * FROM {{ ref("base_ar_trade__price_changes") }}
),

distinct_rows AS (
    SELECT DISTINCT
        created_date
        , date
        , id
        , document_number
        , comment
        , author_id
        , division_id
        , contragent_id
        , price_type_id
        , operation_id
        , warehouse_id
        , product_id
        , measurement_id
        , price
        , base_price
    FROM source
)

SELECT * FROM distinct_rows