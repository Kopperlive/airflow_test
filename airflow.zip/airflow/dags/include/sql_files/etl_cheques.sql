
DECLARE @end datetime = ? -- data_interval_end
DECLARE @start datetime = DATEADD(DAY, -(?), @end) -- DATE_RANGE

select 
    CONCAT(
             CONVERT([varchar](30), CONVERT([date], c.[sdate])),
             '_',
             CONVERT([varchar](3), c.[shopindex]),
             '_',
             CONVERT([varchar](100), c.[cashnumber]),
             '_',
             CONVERT([varchar](100), c.[znumber]),
             '_',
             CONVERT([varchar](100), c.[checknumbe])
         ) AS [Id]
    ,CAST(c.sdate as date) as [date]
    ,CAST(c.sdatez as date) as [z_report_date]
    ,c.[shopindex] as [shopindex]
    ,c.[cashnumber] as [cashnumber]
    ,c.[znumber] as [zreportnumber]
    ,c.[checknumbe] as [checknumber]
    ,c.[cardarticu] as [articul]
    ,c.[casher] as [cashercode]
    ,CAST(STUFF(RIGHT('0000' + CAST(stime as varchar), 4), 3, 0, ':') as Time) as [time]
    ,c.[id] as [frontolid]
    ,c.[pricecur] as [price]
    ,c.[quantity] as [quantity]
    ,c.[totalcur] as [total]
    ,c.[recmoment] as [recorddatetime]
from [cashsail] c WITH (NOLOCK)
	JOIN CURRESTS z ON 
        c.shopindex=z.shopindex AND c.znumber=z.znumber AND c.cashnumber=z.cashnumber AND c.sdatez=z.sdatez

    WHERE c.[sdate] BETWEEN @start AND @end
    AND c.[shopindex]=?
    AND c.[znumber]!=0

