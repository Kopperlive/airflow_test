import json
import signal
from datetime import timedelta

import duckdb
import fdb
import pandas as pd
import pendulum
from airflow.decorators import dag, task, task_group
from airflow.exceptions import AirflowSkipException
from airflow.hooks.base import BaseHook
from airflow.models import Variable
from airflow.models.taskinstance import TaskInstance
from airflow.operators.python import get_current_context
from airflow.providers.microsoft.mssql.hooks.mssql import MsSqlHook
from airflow_clickhouse_plugin.hooks.clickhouse import ClickHouseHook
from common_utils.report.s3_utils import read_df_from_ftp, save_df_to_s3
from common_utils.sql_utils import read_sql_file
from common_utils.telegram_utils import send_error_message_telegram
from custom_operators.s3tosql import SqlToS3OperatorImproved

doc_md = """
# Monitoring Prices DAG

This DAG is designed to monitor and compare product prices across multiple databases and cash servers. The DAG includes several tasks for extracting price data from various sources, storing it on S3, and ultimately inserting the data into a ClickHouse database for further analysis.

## Purpose
The goal of this DAG is to:
- Extract price data from different databases (e.g., local markets and AR Trade) and cash servers.
- Store intermediate results in S3 for further processing.
- Compare prices across databases and cash servers to ensure consistency.
- Insert the processed data into a ClickHouse database.

## Key Components

### S3 Configuration
- **S3 Connection ID**: `minio_s3`
- **Bucket Name**: `etl-data-files`
- **Folder**: `monitoring_prices`

### Database Connections
- **AR Trade Connection ID**: `nsp_ar_trade`
- **Local Markets Connection ID**: `nsp_markets_db`
- **ClickHouse DWH Connection ID**: `clickhouse_dwh`

### FTP Configuration
- **FTP Connection ID**: `smb_ftp`
- **FTP Cash Servers File Path**: `BI/Кассы/Cashes.csv`
- **FTP DNS**: `NSP-AsiaSMB.frunze.local`

### Queries
- **AR Trade Query File**: `monitoring_prices_ar_trade.sql`
- **Local Markets Query File**: `monitoring_prices_local_markets.sql`

## Task Groups

### 1. **Extract List of Cash Servers**
The `get_list_of_cash_servers` task fetches a list of cash servers from the specified FTP location and stores it as a CSV file in S3. It also pushes the data to XCom for downstream tasks.

### 2. **Extract List of Local Market Databases**
The `get_list_of_local_market_dbs` task retrieves a list of online databases in the local market server and filters out system databases.

### 3. **ETL Process**
The `etl` task group contains tasks that:
   - **Extract Local Market Data**: Extracts price data from each local market database.
   - **Extract Cashes Data**: Extracts price data from cash servers associated with each market database.
   - **Compare Prices**: Compares extracted prices across AR Trade and local market databases and cash servers.

### 4. **Insert Data into ClickHouse**
After processing, the `insert_to_clickhouse` task inserts the results into the ClickHouse DWH for further analysis.

## Scheduling and Dependencies
This DAG runs every hour (`0 * * * *`), ensuring continuous monitoring and timely updates. It uses task dependencies to ensure that each extraction and transformation step completes before proceeding to the next.

## User-defined Filters
This DAG defines two custom Jinja filters:
- **`convert_to_local_timezone`**: Adjusts time to the local timezone.
- **`add_1c_offset_years`**: Adds a 2000-year offset to timestamps to align with 1C system time.

## Tags
This DAG is tagged as:
- `monitoring`
"""


# S3 stuff
S3_CONN_ID = "minio_s3"
BUCKET_NAME = "monitoring"
S3_FOLDER = "monitoring_prices"

# 1C Connections
AR_TRADE_CONN_ID = "nsp_ar_trade"
LOCAL_MARKETS_CONN_ID = "nsp_markets_db"

DWH_CONN_ID = "clickhouse_dwh"


QUERY_AR_TRADE = "monitoring_prices_ar_trade.sql"
QUERY_LOCAL_MARKETS = "monitoring_prices_local_markets.sql"
QUERY_LOCAL_MARKETS_REASSESSMENTS = "monitoring_prices_local_markets_reassessments.sql"

# SMB stuff
FTP_CONN_ID = "smb_ftp"

FTP_CASHES_SERVERS_FILE = "BI/Кассы/Cashes.csv"
FTP_DNS = "NSP-AsiaSMB.frunze.local"

DATE_RANGE = 5


def convert_to_local_timezone(datetime: pendulum.DateTime):
    return datetime.add(hours=6).to_iso8601_string()[:-1]


def add_1c_offset_years(datetime):
    return datetime.add(years=2000)


def execute_query_to_df_with_hook(query: str, MSSQL_CONN_ID: str) -> pd.DataFrame:
    """Helper function: execute query, return result as a Pandas Dataframe"""
    hook = MsSqlHook(mssql_conn_id=MSSQL_CONN_ID)
    conn = hook.get_conn()
    print("Executing the following query:\n", query)
    df = pd.read_sql(query, conn)
    conn.close()
    return df


## For firebird timeout
class TimeoutError(Exception):
    pass


def timeout_handler(signum, frame):
    raise TimeoutError("Connection timed out")


def execute_query_to_df_with_fdb(
    query: str, ip: str, db: str, timeout=20
) -> pd.DataFrame:

    # Implementing our own timeout using *signal* library
    signal.signal(signal.SIGALRM, timeout_handler)
    signal.alarm(timeout)

    cash_credentials_json = Variable.get("cash_credentials")
    cash_credentials_dict = json.loads(cash_credentials_json)

    ## if couldn't connect during *timeout* seconds , raise an exception
    try:
        con = fdb.connect(
            host=ip,
            database=db,
            user=cash_credentials_dict["user"],
            password=cash_credentials_dict["password"],
            charset="UTF8",
        )
        print("Connected successfully")
    except TimeoutError as e:
        print(f"Connection timeout: {e}")
        raise
    except Exception as e:
        print(f"Connection error: {e}")
        raise
    finally:
        signal.alarm(0)  # Always disable the alarm

    df = pd.read_sql(
        query,
        con,
    )
    con.close()
    return df


@task
def get_list_of_cash_servers(ti: TaskInstance, data_interval_end: pendulum.DateTime):
    """
    Gets a list of cash servers from FTP folder

    Args:
        ti (TaskInstance): _description_
        data_interval_end (pendulum.DateTime): _description_
    """
    df = read_df_from_ftp(ftp_conn_id=FTP_CONN_ID, file_path=FTP_CASHES_SERVERS_FILE)

    filename = "cash_servers.csv"
    file_s3_key = save_df_to_s3(
        df=df,
        aws_conn_id=S3_CONN_ID,
        bucket_name=BUCKET_NAME,
        report_name=S3_FOLDER,
        filename=filename,
        time_granularity="hourly",
        data_interval_end=data_interval_end,
    )

    df_dict = df.to_dict(orient="records")

    ti.xcom_push(key="cash_servers", value=df_dict)
    ti.xcom_push(key="s3_key", value=file_s3_key)


@task
def get_list_of_local_market_dbs():
    """
    Gets a list of available databases in centralized local markets server
    """
    hook = MsSqlHook(mssql_conn_id=LOCAL_MARKETS_CONN_ID)
    conn = hook.get_conn()

    # Selecting databases where id>4(databases that have id less than 4 are system databases(master,temp,etc.))
    query = """
    SELECT 
        NAME AS db

    FROM   sys.databases
    WHERE  database_id > 4 AND state_desc = 'ONLINE'  AND NAME LIKE 'AR%'
    ORDER BY db ASC
    """

    df = pd.read_sql(query, conn)
    dict = df.to_dict("records")
    print(repr(dict))
    return dict


@task_group
def etl(db: str):
    @task(
        map_index_template="{{ my_custom_map_index }}",
    )
    def extract_local_market(
        db: str,
        data_interval_start: pendulum.DateTime,
        data_interval_end: pendulum.DateTime,
    ):
        """
        Extract prices data from local db
        """
        context = get_current_context()
        context["my_custom_map_index"] = db

        db_number = int(db.replace("AR", ""))

        query = read_sql_file(QUERY_LOCAL_MARKETS)

        formatted_query = query.format(
            db=db,
            db_number=db_number,
            data_interval_start=convert_to_local_timezone(
                add_1c_offset_years(data_interval_start.subtract(days=DATE_RANGE))
            ),
            data_interval_end=convert_to_local_timezone(
                add_1c_offset_years(data_interval_end)
            ),
        )

        df = execute_query_to_df_with_hook(
            query=formatted_query, MSSQL_CONN_ID=LOCAL_MARKETS_CONN_ID
        )

        filename = f"{db}_price_changes_raw.csv"

        file_s3_key = save_df_to_s3(
            df=df,
            aws_conn_id=S3_CONN_ID,
            bucket_name=BUCKET_NAME,
            report_name=S3_FOLDER,
            time_granularity="hourly",
            filename=filename,
            data_interval_end=data_interval_end,
        )

        return file_s3_key

    @task(
        map_index_template="{{ my_custom_map_index }}",
    )
    def extract_local_market_reassessments(
        db: str,
        data_interval_start: pendulum.DateTime,
        data_interval_end: pendulum.DateTime,
    ):
        """
        Extract price reassessments from local db
        """
        context = get_current_context()
        context["my_custom_map_index"] = db

        db_number = int(db.replace("AR", ""))

        query = read_sql_file(QUERY_LOCAL_MARKETS_REASSESSMENTS)

        formatted_query = query.format(
            db=db,
            db_number=db_number,
            data_interval_start=convert_to_local_timezone(
                add_1c_offset_years(data_interval_start.subtract(days=DATE_RANGE))
            ),
            data_interval_end=convert_to_local_timezone(
                add_1c_offset_years(data_interval_end)
            ),
        )

        df = execute_query_to_df_with_hook(
            query=formatted_query, MSSQL_CONN_ID=LOCAL_MARKETS_CONN_ID
        )

        filename = f"{db}_reassessments_raw.csv"

        file_s3_key = save_df_to_s3(
            df=df,
            aws_conn_id=S3_CONN_ID,
            bucket_name=BUCKET_NAME,
            report_name=S3_FOLDER,
            time_granularity="hourly",
            filename=filename,
            data_interval_end=data_interval_end,
        )

        return file_s3_key

    @task_group()
    def cashes(db: str):
        @task(
            map_index_template="{{ my_custom_map_index }}",
        )
        def extract_cashes_ips(db, ti: TaskInstance):
            """
            Extract list of cash servers for a market
            """
            context = get_current_context()
            context["my_custom_map_index"] = db
            servers_dict = ti.xcom_pull(
                key="cash_servers", task_ids="get_list_of_cash_servers"
            )

            cash_ips = [i for i in servers_dict if i["host"].startswith(db + "-")]

            if len(cash_ips) == 0:
                raise AirflowSkipException(
                    "Found no cash server for the market server!"
                )
            return cash_ips

        @task(
            map_index_template="{{ my_custom_map_index }}",
            execution_timeout=timedelta(minutes=10),
        )
        def extract_cashes(
            db: str, cashes: list[dict], data_interval_end: pendulum.DateTime
        ):
            """
            Extract data from all cashes in a single market
            """
            context = get_current_context()
            context["my_custom_map_index"] = db

            query = """
            SELECT 
                code as product_code,
                pricedata.price as price
            from sprt, remain, pricedata 
            where sprt.id = remain.wareid and remain.id = pricedata.remainid 
            """

            failed_cashes = []

            s3_keys = []
            for conn_str in cashes:
                host = conn_str["host"]

                dbPath = conn_str["mainDbPath"]

                df = pd.DataFrame()

                print(f"Starting on {host}")
                try:
                    df = execute_query_to_df_with_fdb(query=query, ip=host, db=dbPath)
                except Exception as e:
                    print(f"Failed on {host},{e}")
                    failed_cashes.append([host, None, None])
                    continue

                df["cash_host"] = host
                filename = f"{host}_prices_raw.csv"
                file_s3_key = save_df_to_s3(
                    df=df,
                    aws_conn_id=S3_CONN_ID,
                    bucket_name=BUCKET_NAME,
                    report_name=S3_FOLDER,
                    time_granularity="hourly",
                    filename=filename,
                    data_interval_end=data_interval_end,
                )
                s3_keys.append(file_s3_key)
                print(f"Finished on {host}")

            if len(failed_cashes) > 0:
                filename = f"{db}_failed_cashes.csv"
                file_s3_key = save_df_to_s3(
                    df=pd.DataFrame(
                        failed_cashes, columns=["cash_host", "product_code", "price"]
                    ),
                    aws_conn_id=S3_CONN_ID,
                    bucket_name=BUCKET_NAME,
                    time_granularity="hourly",
                    report_name=S3_FOLDER,
                    filename=filename,
                    data_interval_end=data_interval_end,
                )
            if len(s3_keys) == 0:
                raise AirflowSkipException("Couldn't connect to even one cash server!")

            # return s3_keys

        extract_cashes(db=db, cashes=extract_cashes_ips(db))

    @task(
        map_index_template="{{ my_custom_map_index }}",
    )
    def compare_prices_across_servers(
        db: str,
        market_s3_key: str,
        market_reassessment_s3_key: str,
        ti: TaskInstance,
        data_interval_end: pendulum.DateTime,
    ):
        context = get_current_context()
        context["my_custom_map_index"] = db

        ar_trade_s3_key = ti.xcom_pull(
            task_ids="extract_ar_trade_price_changes", key="return_value"
        )

        conn = duckdb.connect()

        ## Data from AR_TRADE
        conn.sql(
            f"""
            CREATE OR REPLACE TABLE ar_trade_prices AS 
                SELECT
                    *
                FROM read_parquet('s3://{BUCKET_NAME}/{ar_trade_s3_key}')
        """
        )

        ## Data from local market
        conn.sql(
            f"""
            CREATE OR REPLACE TABLE market_prices AS 
                SELECT
                    *
                FROM read_csv('s3://{BUCKET_NAME}/{market_s3_key}')
        """
        )

        ## Reassessment data from local market
        conn.sql(
            f"""
            CREATE OR REPLACE TABLE market_reassessments AS 
                SELECT
                    *
                FROM read_csv('s3://{BUCKET_NAME}/{market_reassessment_s3_key}')
        """
        )

        ## Data from cashes of the local market
        conn.sql(
            f"""
            CREATE OR REPLACE TABLE cash_prices AS 
                SELECT
                    *
                FROM read_csv('s3://{BUCKET_NAME}/{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}/{data_interval_end.hour}/{S3_FOLDER}/{db}-*')
        """
        )

        ## Deleting not current divisions that we are comparing prices for  in AR_TRADE data
        conn.sql(
            """
            DELETE FROM ar_trade_prices 
                WHERE division_id NOT IN (SELECT DISTINCT division_id FROM market_prices)
        """
        )

        ## AR_TRADE and local market joined
        conn.sql(
            """
            CREATE OR REPLACE TABLE ar_trade_and_local_joined AS
                 SELECT * FROM (
                 SELECT
                    ar.*
                    , CASE WHEN m.new_price IS NULL THEN 0 ELSE 1 END AS is_delivered_to_market
                    , ROW_NUMBER() OVER(PARTITION BY 
                        ar.division_id,
                        ar.price_type_id,
                        ar.product_id
                        ORDER BY ar.start_datetime DESC
                    ) AS row_number


                 FROM ar_trade_prices ar
                    LEFT JOIN market_prices m ON ar.start_datetime=m.start_datetime
                        AND ar.document_number=m.document_number
                        AND ar.price_type_id=m.price_type_id
                        AND ar.product_id=m.product_id
                        AND ar.new_price=m.new_price
                        AND ar.division_id=m.division_id
                 ) WHERE row_number=1
        """
        )

        ## Add reassessment
        conn.sql(
            """
            CREATE OR REPLACE TABLE combined_with_reassessment AS 
            SELECT 
                arm.*
                , mr.document_number AS reassessment_document_number
                , CASE WHEN mr.new_price IS NULL THEN 0 ELSE 1 END AS is_reassessed
            FROM ar_trade_and_local_joined arm
                LEFT JOIN market_reassessments mr
                    ON arm.division_id=mr.division_id
                        AND arm.product_id=mr.product_id
                        AND arm.price_type_id=mr.price_type_id
                        and arm.new_price=mr.new_price
                        AND arm.is_promo=0
        """
        )

        # Joining cash data
        conn.sql(
            """CREATE OR REPLACE TABLE result AS
                 SELECT
                    cmb.*
                    , cp.*
                    , CASE WHEN cp.price=cmb.new_price THEN 1 ELSE 0 END AS is_delivered_to_cash
                 FROM combined_with_reassessment cmb
                     JOIN cash_prices cp ON cp.product_code=cmb.product_code
        """
        )

        # Delete trash price changes(where the document for changing price is created but the  new price is the same as old price)
        # conn.sql(
        # """
        # DELETE FROM result where new_price=old_price
        # """
        # )

        result_s3_key = f"{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}/{data_interval_end.hour}/{S3_FOLDER}/{db}_result.csv"

        conn.sql(f"COPY result TO 's3://{BUCKET_NAME}/{result_s3_key}'")

        return result_s3_key

    @task
    def insert_to_clickhouse(db: str, result_s3_key: str):
        context = get_current_context()
        context["my_custom_map_index"] = db

        hook = ClickHouseHook(clickhouse_conn_id=DWH_CONN_ID)

        s3_hook = BaseHook.get_connection(conn_id=S3_CONN_ID)
        s3_hook_extra = s3_hook.extra
        s3_endpoint = json.loads(s3_hook_extra)["endpoint_url"]

        query = f"""
        INSERT INTO monitoring.price_changes (
            start_datetime
            ,division_id
            ,cash_host
            ,price_type_id
            ,document_number
            ,product_id
            ,new_price
            ,old_price_in_cash
            ,is_promo
            ,is_delivered_to_market
            ,is_delivered_to_cash
            ,is_reassessed
            ,reassessment_document_number
            )
            SELECT
                start_datetime
                ,division_id
                ,cash_host
                ,price_type_id
                ,document_number
                ,product_id
                ,new_price
                ,PRICE
                ,is_promo
                ,is_delivered_to_market
                ,is_delivered_to_cash
                ,is_reassessed
                ,reassessment_document_number
            FROM s3(
                    '{s3_endpoint}/{BUCKET_NAME}/{result_s3_key}')
        """

        print("Executing query:\n", query)
        hook.execute(sql=query)

    market_s3_key = extract_local_market(db=db)
    market_reassessment_s3_key = extract_local_market_reassessments(db=db)
    cashes_s3_key = cashes(db)

    result_s3_key = compare_prices_across_servers(
        db=db,
        market_s3_key=market_s3_key,
        market_reassessment_s3_key=market_reassessment_s3_key,
    )
    (
        cashes_s3_key
        >> result_s3_key
        >> insert_to_clickhouse(db=db, result_s3_key=result_s3_key)
    )


@dag(
    schedule_interval="0 * * * *",
    template_searchpath=["/opt/airflow/dags/include/sql_files/"],
    default_args={
        "owner": "ubaitur5",
        "priority_weight": -5,
        "on_failure_callback": send_error_message_telegram,
    },
    start_date=pendulum.DateTime(2024, 7, 23),
    doc_md=doc_md,
    tags=["monitoring"],
    catchup=False,
    user_defined_filters={
        "convert_to_local_timezone": convert_to_local_timezone,
        "add_1c_offset_years": add_1c_offset_years,
    },
)
def monitoring_prices():
    extract_ar_trade_price_changes = SqlToS3OperatorImproved(
        task_id="extract_ar_trade_price_changes",
        sql_conn_id=AR_TRADE_CONN_ID,
        query=QUERY_AR_TRADE,
        s3_bucket=BUCKET_NAME,
        report_name=S3_FOLDER,
        time_granularity="hourly",
        filename="ar_trade_price_changes_raw.parquet",
        params={"date_range": DATE_RANGE},
        replace=True,
        aws_conn_id=S3_CONN_ID,
        file_format="parquet",
        pd_kwargs={"index": False},
    )

    list_of_markets = get_list_of_local_market_dbs()

    [extract_ar_trade_price_changes, get_list_of_cash_servers()] >> etl.expand_kwargs(
        list_of_markets
    )


monitoring_prices()
