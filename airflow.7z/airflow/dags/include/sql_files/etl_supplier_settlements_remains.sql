DECLARE @StartDatetime DATETIME2(3) = DATEADD(DAY,-{{params.date_range}},DATEADD(YEAR,2000,'{{data_interval_end | ds}}'))
DECLARE @EndDatetime DATETIME2(3) = DATEADD(SECOND,-1,DATEADD(YEAR,2000,'{{data_interval_end | ds}}'))


-- -- If EndDateTime in current month set it to 5999-11-01
-- IF EOMONTH(@EndDateTime)=EOMONTH(DATEADD(YEAR,2000,GETDATE()))
-- BEGIN
--   SET @EndDatetime='5999-11-01T00:00:00.000'
-- END


SELECT 
      --  CASE WHEN _Period='5999-11-01T00:00:00.000' -- convert to start of the month if true
      --       THEN DATEADD(month, DATEDIFF(month, 0, GETDATE()),0)
      --       ELSE DATEADD(YEAR,-2000,CAST(_Period AS DATE)) 
      --       END AS Date,
       DATEADD(YEAR,-2000,CAST(_Period AS DATE)) AS Date,
       convert(nchar(34),[Сделка_ТИП], 1) as Сделка_ТИП,
       convert(nchar(34), [Сделка_ID], 1) as Сделка_ID,
       convert(int, [Сделка_НОМЕР]) AS [НомерДокумента],
       convert(nchar(34), [ДоговорВзаиморасчетов_ID], 1) as ДоговорВзаиморасчетов_ID, --_Reference226
       '0x00000000000000000000000000000000' AS ХозОперация_ID,
       convert(nchar(34), [Контрагент_ID], 1) as Контрагент_ID,   --_Reference248
       CAST(SUM(СуммаБаз) AS NUMERIC(33, 8)) AS НачОстаток,
       CAST(0.0 AS NUMERIC(27, 8)) AS [Приход],
       CAST(0.0 AS NUMERIC(27, 8)) AS [Расход]
FROM [vw_ВзаиморасчетыКомпании_Остатки] WITH (NOLOCK)
WHERE _Period BETWEEN @StartDatetime AND @EndDatetime
  AND СуммаБаз <> 0
GROUP BY Сделка_ТИП,
         Сделка_ID,
         Сделка_НОМЕР,
         _Period,
         Контрагент_ID,            --_Reference248
         ДоговорВзаиморасчетов_ID --_Reference226
HAVING CAST(SUM(СуммаБаз) AS NUMERIC(33, 8)) <> 0   