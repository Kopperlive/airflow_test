DECLARE @StartDatetime DATETIME2(3) = DATEADD(DAY,-{{params.date_range}},DATEADD(YEAR,2000,'{{data_interval_end | ds_nodash}}'))
DECLARE @EndDatetime DATETIME2(3) = DATEADD(SECOND,-1,DATEADD(YEAR,2000,'{{data_interval_end | ds_nodash}}'))

SELECT 
       DATEADD(YEAR,-2000,CAST(_Period AS DATE)) AS Date,
       convert(nchar(34),[Сделка_ТИП], 1) as Сделка_ТИП,
       convert(nchar(34), [Сделка_ID], 1) as Сделка_ID,
       convert(int, [Сделка_НОМЕР]) AS [НомерДокумента],
       convert(nchar(34), [ДоговорВзаиморасчетов_ID], 1) as ДоговорВзаиморасчетов_ID, --_Reference226
       convert(nchar(34), [ХозОперация_ID], 1) as ХозОперация_ID, --_Reference335
       convert(nchar(34), [Контрагент_ID], 1) as Контрагент_ID,   --_Reference248
       CAST(0.0 AS NUMERIC(33, 8)) AS НачОстаток,
       CAST(SUM(CASE WHEN _RecordKind = 0.0 THEN [СуммаБаз] ELSE 0.0 END) AS NUMERIC(27, 8)) AS [Приход],
       CAST(SUM(CASE WHEN _RecordKind = 0.0 THEN 0.0 ELSE [СуммаБаз] END) AS NUMERIC(27, 8)) AS [Расход]
FROM [vw_ВзаиморасчетыКомпании] WITH (NOLOCK)
WHERE _Period BETWEEN @StartDatetime AND @EndDatetime
  AND _Active = 0x01
GROUP BY [Сделка_ТИП],
         [Сделка_ID],
         [Сделка_НОМЕР],
         _Period,
         ДоговорВзаиморасчетов_ID,
         [ХозОперация_ID], --_Reference335
         [Контрагент_ID]   --_Reference248
HAVING CAST(SUM([СуммаБаз]) AS NUMERIC(27, 8)) <> 0.0;