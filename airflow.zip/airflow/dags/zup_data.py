import pendulum
from airflow.decorators import dag
from common_utils.etl_tasks import dbt_build, ftp_transfer_excel_to_clickhouse
from common_utils.telegram_utils import send_error_message_telegram

doc_md = ""

# S3 stuff
S3_CONN_ID = "minio_s3"
BUCKET_NAME = "etl-data-files-test"
S3_FOLDER = "dimensions"

DWH_CONN_ID = "clickhouse_dwh"

FTP_ZUP_MARKET_DATA_FILEPATH = "zupobmen/ОтчетЗУПпоМесяцам.xlsx"
FTP_ZUP_LIST_EMPLOYEES_FILEPATH = "zupobmen/Список_всех_сотрудников.xlsx"


@dag(
    default_args={
        "owner": "ubaitur5",
        "on_failure_callback": send_error_message_telegram,
    },
    schedule_interval="0 2 * * *",
    template_searchpath=["/opt/airflow/dags/include/sql_files/"],
    start_date=pendulum.DateTime(2024, 7, 23),
    doc_md=doc_md,
    tags=["etl", "dimensions"],
    catchup=False,
)
def zup_data():

    division_measures = ftp_transfer_excel_to_clickhouse(
        ftp_conn_id="smb_ftp",
        ftp_path=FTP_ZUP_MARKET_DATA_FILEPATH,
        s3_filename="zup_division_measures.csv",
        aws_conn_id=S3_CONN_ID,
        s3_bucket_name=BUCKET_NAME,
        s3_folder=S3_FOLDER,
        table_name="zup_division_measures",
    )
    all_employees = ftp_transfer_excel_to_clickhouse(
        ftp_conn_id="smb_ftp",
        ftp_path=FTP_ZUP_LIST_EMPLOYEES_FILEPATH,
        s3_filename="zup_list_all_employees.csv",
        aws_conn_id=S3_CONN_ID,
        s3_bucket_name=BUCKET_NAME,
        s3_folder=S3_FOLDER,
        table_name="zup_list_all_employees",
        date_columns=["Дата приема", "Дата увольнения"],
    )
    [division_measures, all_employees] >> dbt_build(
        models=["dim_employees_zup", "fct_hr_divisions"]
    )


zup_data()
