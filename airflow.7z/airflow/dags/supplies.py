import os

import duckdb
import pendulum
from airflow.decorators import dag, task
from airflow.models import Variable
from airflow.models.taskinstance import TaskInstance
from airflow_clickhouse_plugin.operators.clickhouse import ClickHouseOperator
from common_utils.etl_utils import build_delete_partition_query, get_data_interval_start
from common_utils.telegram_utils import send_error_message_telegram
from constants.etl_constants import EMPTY_NULL_PLACEHOLDER_FOR_REFERENCES
from custom_operators.s3tosql import SqlToS3OperatorImproved

doc_md = """
# Documentation for ETL Supplies DAG

## Overview

The `supplies` DAG orchestrates the extraction, transformation, and loading of supply chain data from source systems into a data warehouse, with additional steps to export processed data to an S3 bucket. It leverages DuckDB for data processing and ClickHouse for final data storage, ensuring robust and scalable handling of supply data.

## DAG Configuration

- **Schedule**: Runs daily.
- **Catchup**: False (does not perform catch-up runs for past dates).
- **Concurrency**: Allows only one run at a time with `max_active_runs` set to 1.
- **Tags**: Includes tags `["etl", "facts"]` for easy filtering and identification within the Airflow UI.

## Task Details

### 1. `extract_supplies_raw`
- **Type**: `SqlToS3OperatorImproved`
- **Description**: Extracts supply data from a SQL database and stores it in Parquet format on S3.
- **Outputs**: Parquet file stored in the S3 bucket defined by `BUCKET_NAME`.

### 2. `from_s3_to_duckdb`
- **Type**: Python task (@task decorator)
- **Description**: Retrieves data from S3 and loads it into a local DuckDB database for further processing.
- **Dependencies**: Follows `extract_supplies_raw`.

### 3. `transform_supplies`
- **Type**: Python task (@task decorator)
- **Description**: Transforms raw supply data into a structured format suitable for data warehousing.
- **Dependencies**: Executes after `from_s3_to_duckdb`.

### 4. `drop_partitions`
- **Type**: `ClickHouseOperator`
- **Description**: Manages data retention by dropping older partitions in the ClickHouse data warehouse.
- **Dependencies**: Runs after `transform_supplies`.

### 5. `load_supplies`
- **Type**: `ClickHouseOperator`
- **Description**: Loads the transformed supply data from S3 into ClickHouse.
- **Dependencies**: Follows `drop_partitions`.

### 6. `remove_temp_files`
- **Type**: Python task (@task decorator)
- **Description**: Cleans up temporary files created during the DAG execution to free up disk space and maintain order.
- **Dependencies**: Concludes the DAG after `load_supplies`.

## Execution Flow

The DAG starts by extracting data, loading it into DuckDB for processing, transforming it through several stages, and finally loading the processed data into ClickHouse and exporting to S3. The flow ensures that each step is prepared by the previous steps' outputs, maintaining data integrity and processing continuity.

"""

# S3 stuff
S3_CONN_ID = "minio_s3"
BUCKET_NAME = "etl-data-files"
S3_FOLDER = "supplies"

AR_TRADE_CONN_ID = "nsp_ar_trade"
QUERY = "supplies.sql"

DUCKDB_FILE = "/tmp/supplies.db"


FACTS_MONTH_RANGE = int(Variable.get("facts_month_range"))


@task
def from_s3_to_duckdb(ti: TaskInstance):
    """
    Retrieves  data from S3 and loads it into DuckDB for further processing. This task pulls multiple
    datasets including the current state of warehouses and additional attributes from different S3 keys set in prior tasks.
    """

    conn = duckdb.connect(DUCKDB_FILE)

    supplies_s3_key = ti.xcom_pull(task_ids="extract_supplies_raw", key="return_value")

    conn.sql(
        f"CREATE OR REPLACE TABLE supplies_raw AS SELECT * FROM read_parquet('s3://{BUCKET_NAME}/{supplies_s3_key}')"
    )
    conn.close()


@task
def transform_supplies(ti: TaskInstance, data_interval_end: pendulum.DateTime):
    """
    Transforms raw supplies data into a structured format suitable for data warehousing.
    """

    conn = duckdb.connect(DUCKDB_FILE)

    conn.sql(
        f"""CREATE OR REPLACE TABLE supplies AS
            SELECT
                _Date_Time  - INTERVAL 2000 YEAR as datetime,
                _IDRRef AS id,
                _Number as number,
                ПодразделениеКомпании_ID AS division_id,
                Номенклатура_ID AS product_id,
                ХозОперация_ID AS operation_id,
                ДоговорВзаиморасчетов_ID AS settlement_agreement_id,
                ТипЦен_ID AS price_type_id,
                Контрагент_ID AS contragent_id,
                СкладКомпании_ID AS warehouse_id,
                Автор_ID AS author_id,
                СтавкаНДС_ID AS vat_rate_id,
                COALESCE(ЗаказПоставщику_ID,'{EMPTY_NULL_PLACEHOLDER_FOR_REFERENCES}') AS order_id,
                SUM(СуммаБезНалогов) AS cost_price,
                SUM(СуммаНДС) AS cost_price_VAT,
                SUM(Количество) AS quantity
            FROM supplies_raw
            GROUP BY 
                datetime,
                id,
                number,
                division_id,
                warehouse_id,
                contragent_id,
                settlement_agreement_id,
                product_id,
                author_id,
                operation_id ,
                price_type_id,
                vat_rate_id,
                order_id
        """
    )
    conn.sql("LOAD httpfs;")

    filename = "supplies.parquet"
    s3_key = f"{BUCKET_NAME}/{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}/{S3_FOLDER}/{filename}"
    conn.sql(f"COPY supplies TO 's3://{s3_key}';")
    ti.xcom_push(key="s3_key", value=s3_key)
    conn.close()


@task
def remove_temp_files():
    os.remove(DUCKDB_FILE)


@dag(
    default_args={
        "owner": "ubaitur5",
        "on_failure_callback": send_error_message_telegram,
    },
    schedule_interval="@daily",
    template_searchpath=["/opt/airflow/dags/include/sql_files/"],
    start_date=pendulum.DateTime(2024, 3, 23),
    doc_md=doc_md,
    tags=["etl", "facts"],
    catchup=False,
    user_defined_macros={
        "build_delete_partition_query": build_delete_partition_query,
        "get_data_interval_start": get_data_interval_start,
    },
)
def supplies():

    extract_supplies_raw = SqlToS3OperatorImproved(
        task_id="extract_supplies_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query=QUERY,
        s3_bucket=BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="supplies_raw.parquet",
        params={"month_range": FACTS_MONTH_RANGE},
        replace=True,
        aws_conn_id=S3_CONN_ID,
        file_format="parquet",
        pd_kwargs={"index": False},  # pandas parameters to pass into .to_parquet()
    )

    drop_partitions = ClickHouseOperator(
        task_id="drop_partitions",
        database="dwh",
        sql=f"ALTER TABLE supplies {{{{build_delete_partition_query({FACTS_MONTH_RANGE},data_interval_end)}}}}",
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    load_supplies = ClickHouseOperator(
        task_id="load_supplies",
        database="dwh",
        sql=(
            """
            INSERT INTO supplies
            (
                date,
		time_id,
                id,
                number,
                division_id,
                warehouse_id,
                contragent_id,
                product_id,
                author_id,
                operation_id ,
                price_type_id,
                order_id,
                settlement_agreement_id,
                vat_rate_id,
                quantity,
                cost_price,
                cost_price_VAT 
            )
        
            SELECT 
                CAST(datetime AS date) AS date,
		t.id AS time_id,
                id,
                number,
                division_id,
                warehouse_id,
                contragent_id,
                product_id,
                author_id,
                operation_id ,
                price_type_id,
                order_id,
                settlement_agreement_id,
                vat_rate_id,
                round(toDecimal64(quantity,4),3) AS quantity,
                round(toDecimal64(cost_price,4),2) AS cost_price,
                round(toDecimal64(cost_price_VAT,4),2) AS cost_price_VAT
            FROM  s3(
                '{{conn.minio_s3.extra_dejson.endpoint_url }}/{{ti.xcom_pull(task_ids='transform_supplies',key='s3_key')}}',
                'parquet'
                ) s
		JOIN dwh.time t ON t.description = formatDateTime(s.datetime, '%T');
            """,
            # result of the last query is pushed to XCom
        ),
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    (
        extract_supplies_raw
        >> from_s3_to_duckdb()
        >> transform_supplies()
        >> drop_partitions
        >> load_supplies
        >> remove_temp_files()
    )


supplies()
