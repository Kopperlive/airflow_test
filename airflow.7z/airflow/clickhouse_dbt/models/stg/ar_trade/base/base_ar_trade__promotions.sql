WITH source AS (

    SELECT * FROM {{ source('raw_dbt','promotions_raw') }}

)

, renamed AS (

    SELECT
        CAST("НачалоДействия" AS Date) AS start_date
        , CAST("КонецДействия" AS Date) AS end_date

        , {{ transform_binary_to_uuid('_IDRRef') }} AS id
        , {{ transform_string('_Number') }} AS document_number
        , {{ transform_binary_to_uuid('"Автор_ID"') }} AS author_id
        , {{ transform_string('"Комментарий"') }} AS comment

        , CAST({{ transform_binary_to_uuid('"Подразделение_ID"') }} AS LowCardinality (UUID)) AS division_id
        , CAST({{ transform_binary_to_uuid('"Контрагент_ID"') }} AS LowCardinality (UUID)) AS contragent_id
        , {{ transform_binary_to_uuid('"Объект_ID"') }} AS product_id

        , CAST({{ transform_binary_to_uuid('"ХозОперация_ID"') }} AS LowCardinality (UUID)) AS operation_id
        , CAST({{ transform_binary_to_uuid('"ТипЦен_ID"') }} AS LowCardinality (UUID)) AS price_type_id

        , CAST({{ transform_string('"Аббревиатура"') }} AS LowCardinality (String)) AS abbreviation

        , {{ transform_decimal('"ТекущаяЦена"') }} AS price_actual_with_VAT
        , {{ transform_decimal('"ЗначениеСкидки"') }} AS price_promo_with_VAT
        , {{ transform_decimal('"ТекущаяЗакупочнаяЦена"') }} AS cost_price_actual_with_VAT
        , {{ transform_decimal('"АкционнаяЗакупочнаяЦена"') }} AS cost_price_promo_with_VAT
    FROM source

)

SELECT * FROM renamed
