from typing import (  # Used for type hinting in python 3.8, for versions 3.10+ we could use just | operator
    Union,
)

import pendulum as pend


def get_week_date_range(input_date: Union[pend.DateTime, pend.Date]) -> tuple:
    """
    Get current week date range

    Parameters:
    -----------
    input_date: pendulum.DateTime
        Input date

    Returns:
    --------
    tuple
        Start and end date of the week

    """

    start_date = input_date.start_of("week")
    end_date = input_date.end_of("week")

    return start_date, end_date


def get_mtd_date_range(input_date: Union[pend.DateTime, pend.Date]) -> tuple:
    """
    Get month to date date range

    Parameters:
    -----------
    input_date: pendulum.DateTime
        Input date

    Returns:
    --------
    tuple
        Start and end date of the month

    """

    start_date = input_date.start_of("month")
    end_date = input_date

    return start_date, end_date


def get_month_date_range(input_date: Union[pend.DateTime, pend.Date]) -> tuple:
    """
    Get month date range

    Parameters:
    -----------
    input_date: pendulum.DateTime
        Input date

    Returns:
    --------
    tuple
        Start and end date of the month

    """

    start_date = input_date.start_of("month")
    end_date = input_date.end_of("month")

    return start_date, end_date


def get_past_date_range(
    input_date: pend.DateTime,
    years: int = None,
    months: int = None,
    weeks: int = 1,
    days: int = None,
    range_type: str = "weeks",
) -> tuple:
    """
    Get past date range depending on the range type using substraction of years, months, weeks or days from the input date.

    Parameters:
    -----------
    input_date: pendulum.DateTime
        Input date
    years: int
        Number of years to subtract
    months: int
        Number of months to subtract
    weeks: int
        Number of weeks to subtract
    days: int
        Number of days to subtract
    range_type: str
        Type of range to get. Options: weeks, months, mtd

    Returns:
    --------
    tuple
        Start and end date of the range

    """
    # First lets adjust the given date
    if years is not None:
        input_date = input_date.subtract(years=years)
    elif months is not None:
        input_date = input_date.subtract(months=months)
    elif weeks is not None:
        input_date = input_date.subtract(weeks=weeks)
    elif days is not None:
        input_date = input_date.subtract(days=days)

    if range_type == "weeks":
        return get_week_date_range(input_date)
    elif range_type == "months":
        return get_month_date_range(input_date)
    elif range_type == "mtd":
        return get_mtd_date_range(input_date)
    else:
        raise ValueError(f"Invalid range type: {range_type}")
