WITH source AS (

    SELECT * FROM {{ source('raw_dbt','products_raw') }}

)

, renamed AS (

    SELECT
        {{ transform_binary_to_uuid('_IDRRef') }} AS id
        , {{ transform_binary_to_uuid('_ParentIDRRef') }} AS parent_id
        , {{ transform_string('_Code') }} AS code
        , {{ transform_string('_Description') }} AS description
        , {{ transform_string('"НаименованиеПолное"') }} AS description_full
        , {{ transform_string('"Наименование1"') }} AS description_kg
        , {{ transform_string('"Артикул"') }} AS articul
        , {{ transform_binary_to_boolean('_Folder') }} AS is_item
        , {{ transform_binary_to_boolean('_Marked') }} AS is_deleted
        , {{ transform_binary_to_boolean('"Халал"') }} AS is_halal
        , {{ transform_binary_to_boolean('"Импорт"') }} AS is_import
        , {{ transform_binary_to_boolean('"ЭтоСертификат"') }} AS is_certificate
        , CASE 
            WHEN "ЭтоВозвратныйТовар" = 1 THEN 0
            WHEN "ЭтоВозвратныйТовар" = 2 THEN 1
            ELSE 2
          END AS is_returnable
        , toUInt16("СрокВозврата") AS return_days_deadline
        , {{ transform_binary_to_uuid('"СтатусНоменклатуры_ID"') }} AS product_status_id
        , {{ transform_binary_to_uuid('"ТипНоменклатуры_ID"') }} AS product_type_id
        , {{ transform_binary_to_uuid('"СтранаПроисхождения_ID"') }} AS country_id
        , {{ transform_binary_to_uuid('"ТоварнаяМарка_ID"') }} AS trademark_id
        , {{ transform_binary_to_uuid('"ЦеновойСегмент_ID"') }} AS price_segment_id
        , {{ transform_decimal('"ВесНетто"') }} AS net_weight
        , {{ transform_decimal('"ВесБрутто"') }} AS gross_weight
        , {{ transform_decimal('"КоличествоВупаковке"') }} AS quantity_per_package
    FROM source

)

SELECT * FROM renamed
