SELECT 
        DATEADD(YEAR,-2000,_Period) AS _Period
        , ПодразделениеКомпании_ID
        , СкладКомпании_ID
        , Номенклатура_ID
        , Поставщик_ID
        , Покупатель_ID
        , ДоговорВзаиморасчетов_ID
        , СтатусПартии_ID
        , ХозОперация_ID
        , БезналичныйРасчет
        , СтавкаНДС_ID
        , Количество
        , Сумма
        , СуммаНДС
        , СуммаСкидки
        , Себестоимость
        , СуммаНДСВходящий
FROM vw_Продажи  WITH (NOLOCK)
WHERE _Active=0x01
    AND _Period >= DATEADD(YEAR,2000,'{{get_data_interval_start(data_interval_end) | ds_nodash}}')
    AND _Period < DATEADD(YEAR,2000,'{{data_interval_end | ds_nodash}}')
    -- AND Покупатель_ID NOT IN (0xAB3F3CA82AFF8E7411ED287787A6EA04,0xAB3F3CA82AFF8E7411ED287787A6EA03)

-- UNION ALL

-- SELECT 
--         DATEADD(YEAR,-2000,_Period) AS _Period
--         , ПодразделениеКомпании_ID
--         , СкладКомпании_ID
--         , Номенклатура_ID
--         , Поставщик_ID
--         , Покупатель_ID
--         , ДоговорВзаиморасчетов_ID
--         , СтатусПартии_ID
--         , ХозОперация_ID
--         , NULL
--         , СтавкаНДС_ID
--         , Количество
--         , Сумма
--         , СуммаНДС
--         , СуммаСкидки
--         , Себестоимость
--         , СуммаНДСВходящий
-- FROM [192.168.253.11].[GeneralTrade].[dbo].vw_Продажи  WITH (NOLOCK)
-- WHERE _Active=0x01
-- --     AND _Period >= DATEADD(YEAR,2000,'{{get_data_interval_start(data_interval_end) | ds_nodash}}')
-- --     AND _Period < DATEADD(YEAR,2000,'{{data_interval_end | ds_nodash}}')
--     AND _Period >= '40210101'
--     AND _Period < '40220101'
--     AND Покупатель_ID NOT IN (0xAB3F3CA82AFF8E7411ED287787A6EA04,0xAB3F3CA82AFF8E7411ED287787A6EA03)