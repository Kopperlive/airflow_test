import openpyxl
import pandas as pd
from openpyxl.styles import NamedStyle, PatternFill
from openpyxl.utils import get_column_letter


def write_worksheet(
    workbook, df, sheet_name="Sheet1", num_columns=None, prc_columns=None
):
    """
    Writes data from a pandas DataFrame to a new worksheet in an Excel workbook and applies specific
    formatting rules. This function sets up column formatting for numeric and percentage values, applies
    conditional formatting to highlight negative values, and sets up column widths and headers.

    Parameters
    ----------
    workbook : xlsxwriter.Workbook
        The workbook object to which the worksheet will be added. This object must be created
        with XlsxWriter.
    df : pd.DataFrame
        The DataFrame containing the data to be written to the worksheet.
    sheet_name : str, optional
        The name of the worksheet to be created and written to. Defaults to 'Sheet1'.
    num_columns : list of str, optional
        A list of column names from the DataFrame that should have number formatting applied. This
        affects how thousands are separated and how decimal points are handled.
    prc_columns : list of str, optional
        A list of column names from the DataFrame that should have percentage formatting applied. This
        includes setting the number of decimal places for percentages.

    Returns
    -------
    xlsxwriter.Workbook
        The workbook object with the new worksheet added, now containing the formatted data.

    """

    # create a sheet in excel file
    worksheet = workbook.add_worksheet(sheet_name)

    # Format for the headers with color background
    header_format = workbook.add_format(
        {
            "bold": True,
            "text_wrap": True,
            "valign": "top",
            "align": "center",
            "border": 1,
            "fg_color": "#79b7fc",
        }
    )

    # Create a custom number format with a space as a thousand delimiter
    thousands_format = workbook.add_format({"num_format": "### ### ### ###"})
    thousands_format_1 = workbook.add_format({"num_format": "### ### ### ###.0"})
    # Create a format for percentage cells
    percentage_format = workbook.add_format({"num_format": "0%"})
    percentage_format_1 = workbook.add_format({"num_format": "0.0%"})
    percentage_format_2 = workbook.add_format({"num_format": "0.00%"})
    # Create a format with red font color
    red_font_format = workbook.add_format({"color": "red"})

    # Freeze the first row and first two columns
    worksheet.freeze_panes(1, 1)

    # Apply the header format to the header row
    for col_num, value in enumerate(df.columns.values):
        worksheet.write(0, col_num, value, header_format)

    # Write all data
    for row_num, row_data in enumerate(df.values, start=1):
        for col_num, value in enumerate(row_data):
            if pd.notna(value):
                worksheet.write(row_num, col_num, value)
            else:
                worksheet.write(row_num, col_num, "")

    # Apply format to columns
    for column_index, column in enumerate(df.columns.values):
        max_len = max(len(str(cell)) for cell in df.iloc[:, column_index]) + 3
        if column in num_columns:
            # Добавлено по просьбе операционного директора сделать разные дробные округления
            if column == "AvgProductQtyInCheck":
                worksheet.set_column(
                    column_index, column_index, max_len, thousands_format_1
                )
            else:
                worksheet.set_column(
                    column_index, column_index, max_len, thousands_format
                )
        elif column in prc_columns:
            # Добавлено по просьбе операционного директора сделать разные дробные округления
            if column in ("PrcRevenueSP", "Top600NoStockPrc"):
                worksheet.set_column(
                    column_index, column_index, max_len, percentage_format_1
                )
            elif column == "PrcRevenueWriteOff":
                worksheet.set_column(
                    column_index, column_index, max_len, percentage_format_2
                )
            else:
                worksheet.set_column(
                    column_index, column_index, max_len, percentage_format
                )
        else:
            worksheet.set_column(column_index, column_index, max_len)

    # Apply conditional formatting to make negative values red
    worksheet.conditional_format(
        "B2:AC1000",
        {"type": "cell", "criteria": "<", "value": 0, "format": red_font_format},
    )
    # Enable autofilter on the first row (header row)
    worksheet.autofilter("A1:AC1")  # Assuming you have data in columns A to Z
    return workbook


def make_last_row_bold(
    workbook_bytes, sheet_name, font_color="000000", fill_color="a8d1ff"
):
    """
    Apply bold formatting to the last row of a specific sheet in an Excel workbook stored as a BytesIO object.
    The function also applies a background color to the cells in the last row. The workbook is modified in-place
    and returned as a BytesIO object.

    Parameters
    ----------
    workbook_bytes : BytesIO
        A BytesIO object containing an Excel workbook where modifications will be made.
    sheet_name : str
        The name of the worksheet within the workbook where the last row will be made bold.
    font_color : str, optional
        The color code (in hex format) to apply to the font of the last row. Default is '000000' (black).
    fill_color : str, optional
        The background color code (in hex format) to apply to the cells in the last row. Default is 'a8d1ff' (light blue).

    Returns
    -------
    BytesIO
        The modified workbook as a BytesIO object, allowing for further manipulations or saving.

    Example
    -------
    >>> from io import BytesIO
    >>> import openpyxl
    >>> # Create a new workbook and add some data
    >>> wb = openpyxl.Workbook()
    >>> ws = wb.active
    >>> ws.append([1, 2, 3])
    >>> ws.append([4, 5, 6])
    >>> ws.title = "SampleSheet"
    >>> # Save the workbook to a BytesIO object
    >>> file = BytesIO()
    >>> wb.save(file)
    >>> # Modify the last row
    >>> updated_file = make_last_row_bold(file, "SampleSheet")
    >>> # Load the modified workbook to check changes
    >>> updated_wb = openpyxl.load_workbook(updated_file)
    >>> updated_ws = updated_wb["SampleSheet"]
    """
    # Ensure the cursor is at the start of the BytesIO object
    workbook_bytes.seek(0)
    # Load the workbook from the BytesIO object
    workbook = openpyxl.load_workbook(workbook_bytes)
    # Select the sheet
    sheet = workbook[sheet_name]

    # Find the last row
    last_row = sheet.max_row

    # Define the fill pattern
    fill_pattern = PatternFill(
        start_color=fill_color, end_color=fill_color, fill_type="solid"
    )

    # Iterate through each cell in the last row and copy the format
    for col_num in range(1, sheet.max_column + 1):
        cell = sheet.cell(row=last_row, column=col_num)
        cell.font = openpyxl.styles.Font(bold=True, color=font_color)
        cell.fill = fill_pattern

    # Save changes back to the BytesIO object
    workbook_bytes.seek(0)
    workbook_bytes.truncate()  # This ensures that the existing content of the BytesIO object is removed before writing the modified workbook back
    workbook.save(workbook_bytes)
    workbook_bytes.seek(0)  # Reset the pointer to the start of the BytesIO object


def change_date_format(
    workbook_bytes, sheet_name, column_index=None, date_format="DD-MM-YYYY"
):
    """
    Modify the date format of cells in a specified column of a worksheet within an Excel workbook stored as a BytesIO object.
    The function applies a new date format style to each cell in the column, starting from the second row (assuming the first
    row contains headers).

    Parameters
    ----------
    workbook_bytes : BytesIO
        A BytesIO object containing an Excel workbook where modifications will be made.
    sheet_name : str
        The name of the worksheet within the workbook to be modified.
    column_index : int, optional
        The column index where the date format should be changed. If not provided, the function defaults to the last column.
    date_format : str, optional
        The Excel-compatible date format string to apply. Default is 'DD-MM-YYYY'.

    Returns
    -------
    BytesIO
        The modified workbook as a BytesIO object, allowing for further manipulations or saving.
    """
    # Ensure the cursor is at the start of the BytesIO object
    workbook_bytes.seek(0)
    # Load the workbook
    workbook = openpyxl.load_workbook(workbook_bytes)

    # Select the sheet
    sheet = workbook[sheet_name]

    if column_index == None:
        # last column
        column_index = sheet.max_column

    # Convert the numeric index to a column letter
    column_letter = get_column_letter(column_index)

    # Define a style with date format
    date_style = NamedStyle(name="date_style", number_format=date_format)

    # Apply the style to the cells below the header
    for row_index in range(2, sheet.max_row + 1):  # Starting from the second row
        cell = sheet[column_letter + str(row_index)]
        cell.style = date_style

    # Save changes back to the BytesIO object
    workbook_bytes.seek(0)
    workbook_bytes.truncate()  # This ensures that the existing content of the BytesIO object is removed before writing the modified workbook back
    workbook.save(workbook_bytes)
    workbook_bytes.seek(0)  # Reset the pointer to the start of the BytesIO object


def set_new_headers(workbook_bytes, sheet_name, new_headers: list):
    """
    Modifies the column headers of a specified Excel sheet loaded from a BytesIO object to new values provided in a list.
    This function is specifically tailored to change the column names to Russian, assuming the new headers are provided in Russian.

    Args:
        workbook_bytes (BytesIO): A BytesIO object containing the Excel workbook data. The object must be seekable and writable.
        sheet_name (str): The name of the sheet within the workbook where the column headers need to be updated.
        new_headers (list): A list of strings representing the new column headers. The number of elements in the list should match
                            the number of columns in the first row of the specified sheet.

    Returns:
        None: The function directly modifies the BytesIO object passed as `workbook_bytes` and does not return any value.

    Raises:
        ValueError: If the number of `new_headers` does not match the number of columns in the first row of the sheet.
        KeyError: If the `sheet_name` provided does not exist in the workbook.
    """
    # Ensure the cursor is at the start of the BytesIO object
    workbook_bytes.seek(0)
    # Load the workbook from the BytesIO object
    workbook = openpyxl.load_workbook(workbook_bytes)
    # Select the sheet
    sheet = workbook[sheet_name]

    # Change headers in the first row
    for col, new_header in zip(sheet[1], new_headers):
        col.value = new_header

    # Save changes back to the BytesIO object
    workbook_bytes.seek(0)
    workbook_bytes.truncate()  # This ensures that the existing content of the BytesIO object is removed before writing the modified workbook back
    workbook.save(workbook_bytes)
    workbook_bytes.seek(0)  # Reset the pointer to the start of the BytesIO object
