import pendulum
from airflow.decorators import dag, task_group
from airflow.operators.bash import BashOperator
from common_utils.etl_tasks import create_or_replace_table, dbt_build
from common_utils.telegram_utils import send_error_message_telegram
from custom_operators.s3tosql import SqlToS3OperatorImproved

doc_md = ""

# S3 stuff
S3_CONN_ID = "minio_s3"
BUCKET_NAME = "etl-data-files-test"
S3_FOLDER = "dimensions"

AR_TRADE_CONN_ID = "nsp_ar_trade"
DWH_CONN_ID = "clickhouse_dwh"


@task_group
def extract():
    extract_barcodes_raw = SqlToS3OperatorImproved(
        task_id="extract_barcodes_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query="""
        SELECT 
            ШтрихКод
            , Объект_ID
            , CASE WHEN ШтрихКод NOT LIKE '2%' then 0x00 ELSE ОсновнойШтрихкод END AS ОсновнойШтрихкод
            , ЕдиницаИзмерения_ID
        FROM vw_Штрихкоды 
        -- WHERE ШтрихКод NOT LIKE '1%'
        """,
        s3_bucket=BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="barcodes_raw.parquet",
        replace=True,
        aws_conn_id=S3_CONN_ID,
        file_format="parquet",
        pd_kwargs={"index": False},
    )

    extract_measurements_raw = SqlToS3OperatorImproved(
        task_id="extract_measurements_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query="""
        SELECT 
            _IDRRef
            , _Marked
            , _OwnerID_RRRef
            , _Code
            , _Description
        FROM vw_ЕдиницыИзмерения
        """,
        s3_bucket=BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="measurements_raw.parquet",
        replace=True,
        aws_conn_id=S3_CONN_ID,
        file_format="parquet",
        pd_kwargs={"index": False},
    )


@task_group
def load():
    create_or_replace_table(
        conn_id=DWH_CONN_ID,
        table_name="barcodes_raw",
        s3_bucket=BUCKET_NAME,
        s3_key='{{ti.xcom_pull(key="return_value",task_ids="extract.extract_barcodes_raw")}}',
    )

    create_or_replace_table(
        conn_id=DWH_CONN_ID,
        table_name="measurements_raw",
        s3_bucket=BUCKET_NAME,
        s3_key='{{ti.xcom_pull(key="return_value",task_ids="extract.extract_measurements_raw")}}',
    )


@dag(
    default_args={
        "owner": "ubaitur5",
        "on_failure_callback": send_error_message_telegram,
    },
    schedule_interval="0 1-11 * * *",
    template_searchpath=["/opt/airflow/dags/include/sql_files/"],
    start_date=pendulum.DateTime(2024, 7, 23),
    doc_md=doc_md,
    tags=["etl", "dimensions"],
    catchup=False,
)
def dim_barcodes():

    extract() >> load() >> dbt_build(indirect_selection="buildable")


dim_barcodes()
