SELECT 
    s.Подразделение_ID
    , s.Объект_ID
    , ns._IDRRef
    , ns._Number
    , ns.ТипЦен_ID
    , ns.ХозОперация_ID
    , ns.Контрагент_ID
    , ns.Автор_ID
    , DATEADD(YEAR,-2000,s.НачалоДействия) AS НачалоДействия
    , DATEADD(YEAR,-2000,s.КонецДействия) AS КонецДействия
    , pl._Description AS Аббревиатура
    , ns.Комментарий
    , nss.ТекущаяЦена
    , nss.ЗначениеСкидки
    , nss.ТекущаяЗакупочнаяЦена
    , nss.АкционнаяЗакупочнаяЦена
FROM vw_Скидки s WITH (NOLOCK)
    LEFT JOIN vw_ВидыПрайсЛистов pl WITH (NOLOCK)
        ON pl._IDRRef = s.ВидПрайсЛистаПодарка_ID
    JOIN vw_НазначениеСкидок ns WITH (NOLOCK)
        ON ns._IDRRef = s._RecorderRRef
    JOIN vw_НазначениеСкидок_Скидки nss WITH (NOLOCK)
        ON nss.Ссылка = ns._IDRRef
           AND nss.Номенклатура_ID = s.Объект_ID

WHERE s.НачалоДействия <= '{{data_interval_end.subtract(days=1).add(years=2000) | ds_nodash}}'
      AND s.КонецДействия >= '{{data_interval_end.subtract(days=params.date_range).add(years=2000) | ds_nodash}}'
      AND s._Active = 0x01
      AND s.Действует = 0x01
      AND ns._Marked = 0x00
      AND ns._Posted = 0x01
