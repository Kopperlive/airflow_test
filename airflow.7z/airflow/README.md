# Airflow


## To run docker container, follow these steps:

1. CREATE `.env` file and fill following variables:
```
# PostgreSQL credentials 
POSTGRES_USER=
POSTGRES_PASSWORD=

# Airflow webserver credentials
AIRFLOW_WWW_USER_USERNAME=
AIRFLOW_WWW_USER_PASSWORD=
AIRFLOW_UID=1000 # UID of your user,you can figure out yours by running command *"id -u"*

#S3
S3_ENDPOINT=192.168.240.58:9000
S3_ACCESS_KEY=
S3_SECRET_KEY=

#DBT
DBT_PROJECT_DIR=/opt/airflow/clickhouse_dbt
DBT_PROFILES_DIR=/opt/airflow/clickhouse_dbt
DBT_CLICKHOUSE_USER=
DBT_CLICKHOUSE_PASSWORD=
DBT_CLICKHOUSE_HOST=
```

2. Run following commands:
```bash
docker compose build

# initialize (postgres and airflow-init containers)
docker compose up airflow-init -d

docker compose up -d
```
3. In order to add credentials for duckdb in order to access s3 instance, we gotta run the following command:
```bash
docker exec -it airflow-airflow-scheduler-1 bash -c "python3 /opt/airflow/configure_s3_for_duckdb.py"
```

