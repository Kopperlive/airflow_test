WITH source AS (

    SELECT * FROM {{ source('raw_dbt','essential_products_raw') }}

)

, renamed AS (

    SELECT
        toUUID({{ dbt_utils.generate_surrogate_key([
				'division_id', 
				'product_id'
			])
		}}) AS id
        , {{ transform_binary_to_uuid('"Подразделение_ID"') }} AS division_id
        , {{ transform_binary_to_uuid('"Номенклатура_ID"') }} AS product_id
        , {{ transform_string('_Description') }} AS type
    FROM source

)

SELECT * FROM renamed
