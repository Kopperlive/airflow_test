WITH source AS (
    SELECT * FROM {{ source('raw_dbt','remains_movements_raw') }}
)

, renamed AS (

    SELECT
        --dates
        CAST("_Period" AS Date) AS date
        --ids
        , {{ transform_hex_to_uuid('"СкладКомпании_ID"') }} AS warehouse_id
        , {{ transform_hex_to_uuid('"ХозОперация_ID"') }} AS operation_id
        , {{ transform_hex_to_uuid('"_RecorderRRef"') }} AS recorder_id
        , {{ transform_string('"НомерДокумента"') }} AS recorder_document_number
        , {{ transform_hex_to_uuid('"Контрагент_ID"') }} AS contragent_id
        , {{ transform_hex_to_uuid('"Номенклатура_ID"') }} AS product_id

        -- 0=Addition of product(for instance supplies), 1 = Removal of product(for instance sales)
        , {{ transform_binary_to_boolean('"_RecordKind"') }} AS is_stock_out

        --values
        , {{ transform_decimal('"Количество"') }} AS quantity
        , {{ transform_decimal('"СуммаУпр"') }} AS cost_price
        , {{ transform_decimal('"СуммаНДС"') }} AS cost_price_VAT
    FROM source
)

SELECT * FROM renamed
