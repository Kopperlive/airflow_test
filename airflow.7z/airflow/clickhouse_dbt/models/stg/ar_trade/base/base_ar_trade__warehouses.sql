WITH source AS (

    SELECT * FROM {{ source('raw_dbt','warehouses_raw') }}

)

, renamed AS (

    SELECT
        -- ids
        {{ transform_binary_to_uuid('_IDRRef') }} AS id
        , {{ transform_binary_to_uuid('_ParentIDRRef') }} AS parent_id
        , {{ transform_binary_to_uuid('"Подразделение_ID"') }} AS division_id
        , {{ transform_binary_to_uuid('"Регион_ID"') }} AS region_id

        -- codes
        , {{ transform_string('_Code') }} AS code


        -- names
        , {{ transform_string('_Description') }} AS description

        -- booleans
        , {{ transform_binary_to_boolean('_Marked') }} AS is_deleted
        , {{ transform_binary_to_boolean('_Folder') }} AS is_item

    FROM source

)

SELECT * FROM renamed
