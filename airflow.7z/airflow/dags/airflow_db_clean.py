import pendulum
from airflow.decorators import dag, task
from common_utils.telegram_utils import send_error_message_telegram

doc_md = """
Deletes a metadata that's older than the start of current month
"""


@dag(
    default_args={
        "owner": "ubaitur5",
        "on_failure_callback": send_error_message_telegram,
    },
    schedule_interval="@monthly",
    start_date=pendulum.DateTime(2024, 9, 1),
    doc_md=doc_md,
    tags=["airflow-maintenance"],
    catchup=False,
)
def airflow_db_clean():
    @task.bash
    def run_db_clean(data_interval_start: pendulum.DateTime):
        return (
            f"airflow db clean -v -y --clean-before-timestamp '{data_interval_start}'"
        )

    run_db_clean()


airflow_db_clean()
