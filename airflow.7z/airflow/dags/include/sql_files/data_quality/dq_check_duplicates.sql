SELECT 
    *,
    count() AS cnt
FROM '{{ params.table_name }}'
WHERE (date >= '{{params.start_date}}') AND (date < 'params.end_date')
GROUP BY *
HAVING cnt > 1
ORDER BY date ASC
