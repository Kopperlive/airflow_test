WITH source AS (
    SELECT * FROM {{ ref('base_ar_trade__return_reasons') }}
)

, final AS (
    SELECT *
    FROM source
)

SELECT * FROM final
