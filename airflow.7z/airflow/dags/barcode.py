import os

import duckdb
import pendulum
from airflow.decorators import dag, task
from airflow.models.taskinstance import TaskInstance
from airflow_clickhouse_plugin.operators.clickhouse import ClickHouseOperator
from common_utils.telegram_utils import send_error_message_telegram
from custom_operators.s3tosql import SqlToS3OperatorImproved

doc_md = """
# Barcode Data ETL Process

This DAG manages the extraction, transformation, and loading (ETL) of barcode data from various sources into a data warehouse. The process is designed to run daily, ensuring that barcode data is updated and consistent across all reporting platforms.

## Process Overview

1. **Extract Raw Data**: Barcode data is pulled from a specific source, converted to parquet format, and stored in S3.
2. **Transform Data**: The raw data undergoes a transformation process to structure it for better usability in data warehousing. This includes converting binary fields to hexadecimal and normalizing descriptions.
3. **Load Data**: The transformed data is loaded into a ClickHouse data warehouse. Before loading, the existing barcode data in ClickHouse is updated or marked as historical to prevent duplication.
4. **Cleanup**: Temporary files created during the process are removed to free up space and maintain organization.

## Details

- **Schedule**: It runs daily, handling data in a batch mode, which corresponds to the previous day's data.

"""

# S3 stuff
S3_CONN_ID = "minio_s3"
BUCKET_NAME = "etl-data-files"
S3_FOLDER = "barcode"

DUCKDB_FILE = "/tmp/barcode.db"

AR_TRADE_CONN_ID = "nsp_ar_trade"


@task
def from_s3_to_duckdb(data_interval_end: pendulum.DateTime, ti: TaskInstance):
    """
    Retrieves barcode-related data from S3 and loads it into DuckDB for further processing. This task pulls multiple
    datasets including the current state of barcodes and additional attributes from different S3 keys set in prior tasks.
    """

    conn = duckdb.connect(DUCKDB_FILE)

    barcode_s3_key = ti.xcom_pull(task_ids="extract_barcode_raw", key="return_value")

    barcode_old_s3_key = f"{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}/{S3_FOLDER}/barcode_old.csv"

    conn.sql(
        f"CREATE OR REPLACE TABLE barcode_raw AS SELECT * FROM read_parquet('s3://{BUCKET_NAME}/{barcode_s3_key}')"
    )
    conn.sql(
        f"CREATE OR REPLACE TABLE barcode_old AS SELECT * FROM read_csv('s3://{BUCKET_NAME}/{barcode_old_s3_key}')"
    )


@task
def transform_barcode():
    """
    Transforms raw barcode data into a structured format suitable for data warehousing.
    """

    conn = duckdb.connect(DUCKDB_FILE)

    conn.sql(
        """CREATE OR REPLACE TABLE barcode AS
            SELECT
                Объект_ID AS product_id,
                ШтрихКод AS description,
                CASE ОсновнойШтрихкод WHEN 0 THEN 'Не основной' ELSE 'Основной' END as is_main,
                _Description AS measure_unit
            FROM barcode_raw
        """
    )


@task
def barcode_scd(
    data_interval_start: pendulum.DateTime,
    data_interval_end: pendulum.DateTime,
    ti: TaskInstance,
):
    """
    Implements Slowly Changing Dimension (SCD) logic for barcode data by managing how data updates between cycles are
    handled to maintain a historical record. New and updated records are identified, and their historical states are managed.
    """

    conn = duckdb.connect(DUCKDB_FILE)

    conn.sql(
        """
    CREATE OR REPLACE TABLE barcode_new_rows AS
    (
    SELECT product_id,description,measure_unit,is_main FROM barcode
    EXCEPT
    SELECT product_id,description,measure_unit,is_main FROM barcode_old
    )
    """
    )

    conn.sql(
        """
    CREATE OR REPLACE TABLE barcode_updated_rows AS
    (
    SELECT product_id,description,measure_unit,is_main FROM barcode_old
    EXCEPT 
    SELECT product_id,description,measure_unit,is_main FROM barcode
    )
    """
    )

    count_old = conn.sql("SELECT COUNT(*) FROM barcode_old").fetchone()[0]
    if count_old == 0:
        data_interval_start = pendulum.DateTime(1970, 1, 1)

    conn.sql(
        f"ALTER TABLE barcode_new_rows ADD COLUMN start_date Date DEFAULT '{data_interval_start.to_date_string()}'"
    )
    conn.sql(
        "ALTER TABLE barcode_new_rows ADD COLUMN end_date Date DEFAULT '2149-06-06'"
    )
    conn.sql(
        "ALTER TABLE barcode_new_rows ADD COLUMN is_current String DEFAULT 'Текущий'"
    )

    conn.sql("LOAD httpfs")
    filename = "barcode_new_rows.parquet"
    s3_key = f"{BUCKET_NAME}/{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}/{S3_FOLDER}/{filename}"
    conn.sql(f"COPY barcode_new_rows TO 's3://{s3_key}';")
    ti.xcom_push(key="s3_key", value=s3_key)

    updated_filename = "barcode_updated_rows.parquet"
    updated_s3_key = f"{BUCKET_NAME}/{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}/{S3_FOLDER}/{updated_filename}"
    conn.sql(f"COPY barcode_updated_rows TO 's3://{updated_s3_key}';")
    ti.xcom_push(key="updated_s3_key", value=updated_s3_key)


@task
def remove_temp_files():
    os.remove(DUCKDB_FILE)


@dag(
    default_args={
        "owner": "ubaitur5",
        "on_failure_callback": send_error_message_telegram,
    },
    schedule_interval="@daily",
    template_searchpath=["/opt/airflow/dags/include/sql_files/"],
    start_date=pendulum.DateTime(2024, 7, 23),
    doc_md=doc_md,
    tags=["etl", "dimensions"],
    catchup=False,
)
def barcode():

    extract_barcode_raw = SqlToS3OperatorImproved(
        task_id="extract_barcode_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query="""
        SELECT 
            ШтрихКод,
            CONVERT(NCHAR(34),Объект_ID,1) AS Объект_ID,
            CONVERT(int,ОсновнойШтрихкод) AS ОсновнойШтрихкод,
            iz._Description
        FROM vw_Штрихкоды sh
        LEFT JOIN vw_ЕдиницыИзмерения iz
            ON iz._IDRRef=sh.ЕдиницаИзмерения_ID 
        """,
        s3_bucket=BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="barcode_raw.parquet",
        replace=True,
        aws_conn_id=S3_CONN_ID,
        file_format="parquet",
        pd_kwargs={"index": False},  # pandas parameters to pass into .to_parquet()
    )

    extract_barcode_old = ClickHouseOperator(
        task_id="extract_barcode_old",
        database="dwh",
        settings={"format_csv_null_representation": ""},
        sql=(
            f"""
            INSERT INTO FUNCTION
            s3(
                '{{{{ conn.minio_s3.extra_dejson.endpoint_url_for_writing }}}}/{BUCKET_NAME}/{{{{data_interval_end.year}}}}/{{{{data_interval_end.month}}}}/{{{{data_interval_end.day}}}}/{S3_FOLDER}/barcode_old.csv',
                '{{{{ conn.minio_s3.extra_dejson.aws_access_key_id}}}}',
                '{{{{ conn.minio_s3.extra_dejson.aws_secret_access_key}}}}',
                'CSVWithNames'
                )
            SELECT 
                product_id,
                description,
                measure_unit,
                is_main,
                start_date,
                end_date,
                is_current
            FROM barcode
            WHERE is_current='Текущий'
            SETTINGS s3_create_new_file_on_insert = 1,s3_truncate_on_insert=1
            """,
            # result of the last query is pushed to XCom
        ),
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    load_barcode = ClickHouseOperator(
        task_id="load_barcode",
        database="dwh",
        sql=(
            """
            INSERT INTO barcode
            (
                product_id  ,
                description ,
                measure_unit,
                is_main     ,
                start_date  ,
                end_date    ,
                is_current
            )
            SELECT 
                product_id  ,
                description ,
                measure_unit,
                is_main     ,
                start_date  ,
                end_date    ,
                is_current
            FROM  s3(
                '{{conn.minio_s3.extra_dejson.endpoint_url }}/{{ti.xcom_pull(task_ids='barcode_scd',key='s3_key')}}',
                'parquet'
                );
            """,
            # result of the last query is pushed to XCom
        ),
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    update_barcode = ClickHouseOperator(
        task_id="update_barcode",
        database="dwh",
        sql=(
            """
            ALTER TABLE barcode
            UPDATE end_date='{{data_interval_start|ds}}',is_current='Исторический' WHERE (product_id,description,measure_unit) IN (SELECT  product_id,description,measure_unit FROM s3(
                            '{{conn.minio_s3.extra_dejson.endpoint_url }}/{{ti.xcom_pull(task_ids='barcode_scd',key='updated_s3_key')}}',
                            'parquet'
                            )) AND is_current = 'Текущий'
            """,
            # result of the last query is pushed to XCom
        ),
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    (
        [extract_barcode_old, extract_barcode_raw]
        >> from_s3_to_duckdb()
        >> transform_barcode()
        >> barcode_scd()
        >> update_barcode
        >> load_barcode
        >> remove_temp_files()
    )


barcode()
