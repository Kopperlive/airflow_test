
SELECT
	DATEADD(YEAR,-2000,remains._Period) AS _Period
	, remains.СкладКомпании_ID
	, COALESCE(postuplenie.Контрагент_ID,return_from_buyer.Контрагент_ID,inventarization.Контрагент_ID) AS Контрагент_ID
	, remains.Номенклатура_ID
	, remains.Количество
	, remains.СуммаУпр
    , remains.СуммаНДС


FROM vw_ПартииТоваровКомпанииОстатки remains WITH(NOLOCK)
LEFT OUTER JOIN vw_ПоступлениеТоваров postuplenie WITH(NOLOCK)
	ON remains.Партия_НОМЕР=0x00000205 AND remains.Партия_ID=postuplenie._IDRRef
LEFT OUTER JOIN vw_ОтчетПроизводстваЗаСмену otchet WITH(NOLOCK)
	ON remains.Партия_НОМЕР=0x000001F5 AND remains.Партия_ID=otchet._IDRRef
LEFT OUTER JOIN vw_ЗакрытиеСмены z WITH(NOLOCK)
	ON remains.Партия_НОМЕР=0x000001CA AND remains.Партия_ID=z._IDRRef
LEFT OUTER JOIN vw_Инвентаризация inventarization WITH(NOLOCK)
	ON remains.Партия_НОМЕР=0x000001D0 AND remains.Партия_ID=inventarization._IDRRef
LEFT OUTER JOIN vw_ПересортицаТоваров sort WITH(NOLOCK) 
	ON remains.Партия_НОМЕР=0x000001FC AND remains.Партия_ID=sort._IDRRef
LEFT OUTER JOIN vw_ПеремещениеТоваров movement WITH(NOLOCK)
	ON remains.Партия_НОМЕР=0x000001F8 AND remains.Партия_ID=movement._IDRRef
LEFT OUTER JOIN vw_Разделка razdelka WITH(NOLOCK)
	ON remains.Партия_НОМЕР=0x0000020B AND remains.Партия_ID=razdelka._IDRRef
LEFT OUTER JOIN vw_ВозвратОтПокупателя return_from_buyer WITH(NOLOCK)
	ON remains.Партия_НОМЕР=0x000001B2 AND remains.Партия_ID=return_from_buyer._IDRRef
LEFT OUTER JOIN vw_Комплектация complect WITH(NOLOCK)
	ON remains.Партия_НОМЕР=0x000001E0 AND remains.Партия_ID=complect._IDRRef

WHERE remains._Period = DATEADD(YEAR,2000,'{{get_next_month_start_date(data_interval_end) | ds_nodash}}')
 -- TODO: uncomment following lines to get correct remains with filtering out documents that have been deleted(_Marked=0x01)
	-- AND 
	-- COALESCE(
	-- 	postuplenie._Marked,
	-- 	otchet._Marked,
	-- 	z._Marked,
	-- 	inventarization._Marked,
	-- 	sort._Marked,
	-- 	movement._Marked,
	-- 	razdelka._Marked,
	-- 	return_from_buyer._Marked,
	-- 	complect._Marked,0x00)=0x00