WITH source AS (
    SELECT * FROM {{ source('raw_dbt','writeoff_supertypes_raw') }}
)

, renamed AS (
    SELECT
        {{ transform_binary_to_uuid('_IDRRef') }} AS id
        , CAST("_EnumOrder" AS UInt8) AS enum_number
        , CASE enum_number
            WHEN 0 THEN 'Маркетинг'
            WHEN 1 THEN 'Питание'
            WHEN 2 THEN 'Потери СП'
            WHEN 3 THEN 'Потери Торговли'
            WHEN 4 THEN 'Прочее'
            WHEN 5 THEN 'Расходные материалы'
            WHEN 6 THEN 'Хознужды'
        END AS description
    FROM source
)

SELECT * FROM renamed
