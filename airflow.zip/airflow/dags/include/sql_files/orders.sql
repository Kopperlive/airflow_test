SELECT CONVERT(NCHAR(34),z._IDRRef,1) AS _IDRRef,
       z._Date_Time,
       z.СрокПоставки,
       z._Number,
       CONVERT(NCHAR(34),z.Автор_id,1) AS Автор_id,
       CONVERT(NCHAR(34),z.ПодразделениеКомпании_ID,1) AS ПодразделениеКомпании_ID,
       CONVERT(NCHAR(34),z.Контрагент_Id,1) AS Контрагент_Id,
       CONVERT(NCHAR(34),z.ДоговорВзаиморасчетов_ID,1) AS ДоговорВзаиморасчетов_ID,
       CONVERT(NCHAR(34),z.ТипЦен_Id,1) AS ТипЦен_Id,
       CONVERT(NCHAR(34),z.ХозОперация_ID,1) AS ХозОперация_ID,
       CONVERT(NCHAR(34),z.СкладКомпании_ID,1) AS СкладКомпании_ID,
       z.ПитонСтатус,
       CONVERT(NCHAR(34), zt.Номенклатура_ID, 1) AS Номенклатура_ID,
	   CONVERT(NCHAR(34),zt.СтавкаНДС_ID,1) AS СтавкаНДС_ID,
       zt.Сумма,
       zt.СуммаНДС,
       zt.Количество
FROM [vw_ЗаказПоставщику] z WITH(NOLOCK)
    INNER JOIN [vw_ЗаказПоставщику_Товары] AS zt WITH(NOLOCK)
        ON z._Date_Time >= '{{get_data_interval_start(data_interval_end,params.month_range).add(years=2000) | ds_nodash}}' AND z._Date_Time<'{{data_interval_end.add(years=2000) | ds_nodash}}'
           AND z._IDRRef = zt.Ссылка
           AND z._Marked = 0x00
           AND z._Posted = 0x01
