SELECT			   
	   T1._Period,
       T2._Number,
	   CONVERT(NCHAR(34), T2.[ПодразделениеКомпании_ID], 1) AS [ПодразделениеКомпании_ID],
       CONVERT(NCHAR(34), T1.[Номенклатура_ID], 1) AS [Номенклатура_ID],
       CONVERT(NCHAR(34), D1.[Контрагент_ID], 1) AS [Контрагент_ID],
       CONVERT(NCHAR(34), T2.[СкладКомпании_ID], 1) AS [СкладКомпании_ID],
       CONVERT(NCHAR(34), T2.[ХозОперация_ID], 1) AS [ХозОперация_ID],
       CONVERT(NCHAR(34), T2.[СтатьяСписанияТМЦ_ID], 1) AS [СтатьяСписанияТМЦ_ID],
       CONVERT(NCHAR(34), T2.[Автор_ID], 1) AS [Автор_ID],
       CONVERT(NCHAR(34), T2.[ТипЦен_ID], 1) AS [ТипЦен_ID],
	--    CONVERT(NCHAR(34), T1.[СтавкаНДС_ID],1) AS [СтавкаНДС_ID],
       T1.[СуммаУпр], 
       T1.[СуммаНДС],
       T1.[Количество]
FROM [vw_ПартииТоваровКомпании] T1 WITH (NOLOCK)
INNER JOIN [vw_СписаниеТоваров] T2 WITH (NOLOCK)
    ON T2._IDRRef = T1._RecorderRRef
        AND T2._Marked = 0x00
        AND T2._Posted = 0x01
		AND T1._Period >= '{{get_data_interval_start(data_interval_end,params.month_range).add(years=2000) | ds_nodash}}' AND T1._Period < '{{data_interval_end.add(years=2000) | ds_nodash}}'
		AND T1._Active = 0x01
		AND T1._RecordKind = 1
		AND T1._RecorderTREf = 0x0000021A
LEFT JOIN [vw_ПоступлениеТоваров] D1 --Поступление Товаров
    ON D1._IDRRef = T1.Партия_ID
		
