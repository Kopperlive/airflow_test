{{ config(
    materialized='table',
) }}
WITH products AS (
    SELECT * FROM {{ ref('dim_products') }}
    WHERE is_current = 1
)

, final AS (
    SELECT
        p.id AS id
        , p.parent_id AS parent_id
        , p.code AS code
        , p.articul AS articul
        , p.status_abbreviation AS status_abbreviation
        , p.status_description AS status_description
        , p.description AS description
        , p.description_full AS description_full
        , p.description_kg AS description_kg
        , p_5.description AS fifth_category
        , p_4.description AS fourth_category
        , p_3.description AS third_category
        , p_2.description AS second_category
        , p_1.description AS first_category
        , p_1.code AS first_category_code
        , p_1.id AS first_category_id
        , p.type AS type
        , p.trademark AS trademark
        , p.price_segment AS price_segment
        , p.country AS country
        , p.is_deleted AS is_deleted
        , p.is_item AS is_item
        , p.is_halal AS is_halal
        , p.is_import AS is_import
        , p.is_certificate AS is_certificate
        , p.is_returnable AS is_returnable
        , p.net_weight AS net_weight
        , p.gross_weight AS gross_weight
        , p.quantity_per_package AS quantity_per_package

    FROM products p

    LEFT JOIN products p_5
        ON p.fifth_category_id = p_5.id

    LEFT JOIN products p_4
        ON p.fourth_category_id = p_4.id

    LEFT JOIN products p_3
        ON p.third_category_id = p_3.id

    LEFT JOIN products p_2
        ON p.second_category_id = p_2.id

    LEFT JOIN products p_1
        ON p.first_category_id = p_1.id
)

SELECT * FROM final
