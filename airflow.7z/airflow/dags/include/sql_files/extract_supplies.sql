SELECT 
	DATEADD(YEAR,-2000,p._Date_Time) AS _Date_Time
	, p._Number
	, _IDRRef
	, Автор_ID
	, Контрагент_ID
	, ДоговорВзаиморасчетов_ID
    , ЕдиницаИзмерения_ID
	, СкладКомпании_ID
	, Номенклатура_ID
	, ТипЦен_ID
	, Комментарий
	, ХозОперация_ID
	, ПодразделениеКомпании_ID
	, ЗаказПоставщику_ID
	, СтавкаНДС_ID
	, pt.Количество
	, pt.СуммаБезНалогов
	, pt.СуммаНДС
FROM vw_ПоступлениеТоваров AS p WITH (NOLOCK)
	INNER JOIN vw_ПоступлениеТоваров_Товары pt WITH(NOLOCK) 
        ON p._Date_Time >= '{{get_data_interval_start(data_interval_end).add(years=2000) | ds_nodash}}' AND p._Date_Time<'{{data_interval_end.add(years=2000) | ds_nodash}}'
						AND pt.Ссылка = p._IDRRef
						AND p._Marked = 0x00
						AND p._Posted = 0x01

	OUTER APPLY(
		SELECT -- getting corresponding order of the supply 
            TOP 1
            ЗаказПоставщику_ID 
		FROM vw_ПоступлениеТоваров_РаспределениеПоставки pr WITH (NOLOCK)
		WHERE pr.Ссылка=p._IDRRef
	) AS prp 