import os

import duckdb
import pendulum
from airflow.decorators import dag, task
from airflow.models.taskinstance import TaskInstance
from airflow_clickhouse_plugin.operators.clickhouse import ClickHouseOperator
from common_utils.telegram_utils import send_error_message_telegram
from custom_operators.s3tosql import SqlToS3OperatorImproved

doc_md = """
# Price Type Data ETL Process

This DAG manages the end-to-end process of extracting, transforming, and loading (ETL) data concerning price types from a source system into a data warehouse. The DAG is designed to run on a daily schedule, ensuring timely updates and synchronization of price type data across systems.

## Process Overview

- **Extract Raw Data**: The process begins by pulling raw price type data, converting it to parquet format, and storing it in an S3 bucket.
- **Transform Data**: This raw data is then transformed into a structured format that aligns with the data warehouse schema. Transformations include normalization of descriptions and conversion of binary fields to readable formats.
- **Load Data**: After transformation, the structured data is loaded into a ClickHouse data warehouse. The data warehouse table is first truncated to remove old data before new data is inserted.
- **Cleanup**: Post-processing, temporary files created during the operation are cleaned up to prevent storage clutter and potential data leaks.

## Workflow Steps

1. **Extract Data**: Extracts data using custom SQL queries and stores it in S3.
2. **Transform Data**: Transforms data using DuckDB, ensuring it matches the expected warehouse schema.
3. **Load Data**: Uses ClickHouse operators to load data efficiently into the warehouse from S3.
4. **Cleanup**: Removes any temporary files used during the data handling process.

"""

# S3 stuff
S3_CONN_ID = "minio_s3"
BUCKET_NAME = "etl-data-files"
S3_FOLDER = "price_type"

DUCKDB_FILE = "/tmp/price_type.db"

AR_TRADE_CONN_ID = "nsp_ar_trade"


@task
def from_s3_to_duckdb(ti: TaskInstance):
    """
    Retrieves  data from S3 and loads it into DuckDB for further processing. This task pulls multiple
    datasets including the current state of warehouses and additional attributes from different S3 keys set in prior tasks.
    """

    conn = duckdb.connect(DUCKDB_FILE)

    price_type_s3_key = ti.xcom_pull(
        task_ids="extract_price_type_raw", key="return_value"
    )

    conn.sql(
        f"CREATE OR REPLACE TABLE price_type_raw AS SELECT * FROM read_parquet('s3://{BUCKET_NAME}/{price_type_s3_key}')"
    )
    conn.close()


@task
def transform_price_type(ti: TaskInstance, data_interval_end: pendulum.DateTime):
    """
    Transforms raw price_type data into a structured format suitable for data warehousing. This function enhances the raw
    data by converting binary fields to hexadecimal, normalizing descriptions
    """

    conn = duckdb.connect(DUCKDB_FILE)

    conn.sql(
        """CREATE OR REPLACE TABLE price_type AS
            SELECT
                _IDRRef AS id,
                _ParentIDRRef AS parent_id,
                CASE _Marked WHEN 1 THEN 'Деактивированный' ELSE 'Активный' END activity_status,
                CASE _Folder WHEN 0 THEN 'Папка' ELSE 'Строка' END AS type,
                _Code AS code,
                _Description AS description
            FROM price_type_raw
        """
    )

    conn.sql("LOAD httpfs;")

    filename = "price_type.parquet"
    s3_key = f"{BUCKET_NAME}/{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}/{S3_FOLDER}/{filename}"
    conn.sql(f"COPY price_type TO 's3://{s3_key}';")
    ti.xcom_push(key="s3_key", value=s3_key)
    conn.close()


@task
def remove_temp_files():
    os.remove(DUCKDB_FILE)


@dag(
    default_args={
        "owner": "ubaitur5",
        "on_failure_callback": send_error_message_telegram,
    },
    schedule_interval="@daily",
    template_searchpath=["/opt/airflow/dags/include/sql_files/"],
    start_date=pendulum.DateTime(2024, 7, 23),
    doc_md=doc_md,
    tags=["etl", "dimensions"],
    catchup=False,
)
def price_type():

    extract_price_type_raw = SqlToS3OperatorImproved(
        task_id="extract_price_type_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query="""
        SELECT 
            CONVERT(NCHAR(34),_IDRRef,1) AS _IDRRef,
            CONVERT(int,_Marked) AS _Marked,
            CONVERT(NCHAR(34),_ParentIDRRef,1) AS _ParentIDRRef,
            CONVERT(int,_Folder) AS _Folder,
            _Code,
            _Description
        FROM vw_ТипыЦен 
        """,
        s3_bucket=BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="price_type_raw.parquet",
        replace=True,
        aws_conn_id=S3_CONN_ID,
        file_format="parquet",
        pd_kwargs={"index": False},  # pandas parameters to pass into .to_parquet()
    )

    truncate_price_type = ClickHouseOperator(
        task_id="truncate_price_type",
        database="dwh",
        sql="TRUNCATE TABLE price_type",
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    load_price_type = ClickHouseOperator(
        task_id="load_price_type",
        database="dwh",
        sql=(
            """
            INSERT INTO price_type
            (
                id              ,
                parent_id       ,
                activity_status ,
                type            ,
                code            ,
                description
            )
            SELECT 
                id              ,
                parent_id       ,
                activity_status ,
                type            ,
                code            ,
                description
            FROM  s3(
                '{{conn.minio_s3.extra_dejson.endpoint_url }}/{{ti.xcom_pull(task_ids='transform_price_type',key='s3_key')}}',
                'parquet'
                );
            """,
            # result of the last query is pushed to XCom
        ),
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    (
        extract_price_type_raw
        >> from_s3_to_duckdb()
        >> transform_price_type()
        >> truncate_price_type
        >> load_price_type
        >> remove_temp_files()
    )


price_type()
