WITH source AS (

    SELECT * FROM {{ source('raw_dbt','divisions_raw') }}

)

, renamed AS (

    SELECT
        {{ transform_binary_to_uuid('_IDRRef') }} AS id
        , {{ transform_binary_to_uuid('_ParentIDRRef') }} AS parent_id
        , {{ transform_binary_to_uuid('"ФорматМаркета_ID"') }} AS format_id
        , {{ transform_binary_to_uuid('"Куратор_ID"') }} AS curator_id
        , {{ transform_binary_to_uuid('"ТипЦенРеализации_ID"') }} AS price_type_selling_id
        , {{ transform_binary_to_uuid('"ТипЦенЗакупки_ID"') }} AS price_type_buying_id
        , {{ transform_binary_to_boolean('_Marked') }} AS is_deleted
        , {{ transform_binary_to_uuid('"Город_ID"') }} AS city_id
        , {{ transform_binary_to_uuid('"Регион_ID"') }} AS region_id
        , {{ transform_string('_Code') }} AS code
        , {{ transform_string('"КодДляОтчетов"') }} AS report_code
        , {{ transform_string('"Префикс"') }} AS prefix
        , CAST("SHOPINDEX" AS UInt16) AS shop_index
        , {{ transform_string('_Description') }} AS description
        , {{ transform_string('"Адрес"') }} AS address
        , CAST("ПлощадьОбщая" AS Decimal(19, 2)) AS area_total
        , CAST("ПлощадьТорговогоЗала" AS Decimal(19, 2)) AS area_trade_hall
        , CAST("ПлощадьСкладскихПомещений" AS Decimal(19, 2)) AS area_warehouses
        , CAST("ПлощадьПредКассовойЗоны" AS Decimal(19, 2)) AS area_pre_cachier_zone
        , CAST("ПлощадьХозЧасти" AS Decimal(19, 2)) AS area_administrative_part
    FROM source

)

SELECT * FROM renamed
