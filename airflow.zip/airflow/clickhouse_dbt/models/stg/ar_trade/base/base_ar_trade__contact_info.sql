WITH source AS (
    SELECT * FROM {{ source('raw_dbt', 'contact_info_raw') }}
),

renamed AS (
    SELECT
        {{ transform_binary_to_uuid('"Объект_ID"') }} AS object_id,
        {{ transform_string('"Представление"') }} AS contact_value,
        {{ transform_binary_to_uuid('"Тип_ID"') }} AS type_id,
        CAST(_EnumOrder AS UInt8) AS type_order,
        {{ transform_binary_to_uuid('"Вид_ID"') }} AS category_id,
        {{ transform_string('"Вид_Desc"') }} AS category_desc,
        {{ transform_string('"Тип_Desc"') }} AS type_desc
    FROM source
)

SELECT * FROM renamed
