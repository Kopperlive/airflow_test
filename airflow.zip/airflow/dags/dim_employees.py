import pandas as pd
import pendulum
from airflow.decorators import dag, task
from airflow.operators.bash import BashOperator
from airflow.providers.ftp.operators.ftp import FTPFileTransmitOperator, FTPOperation
from airflow_clickhouse_plugin.operators.clickhouse import ClickHouseOperator
from common_utils.etl_tasks import create_or_replace_table, dbt_build
from common_utils.report.s3_utils import save_df_to_s3
from common_utils.telegram_utils import send_error_message_telegram
from custom_operators.s3tosql import SqlToS3OperatorImproved

doc_md = ""

# S3 stuff
S3_CONN_ID = "minio_s3"
BUCKET_NAME = "etl-data-files-test"
S3_FOLDER = "dimensions"

AR_TRADE_CONN_ID = "nsp_ar_trade"
DWH_CONN_ID = "clickhouse_dwh"

TMP_ZUP_XLSX_FILEPATH = "/tmp/zup_employees.xlsx"
FTP_ZUP_FILEPATH = "zupobmen/Список_Сотрудников_Маркеты.xlsx"


@task
def upload_zup_to_s3(data_interval_end: pendulum.DateTime):
    df = pd.read_excel(TMP_ZUP_XLSX_FILEPATH)

    filename = "zup_employees.csv"
    file_s3_key = save_df_to_s3(
        df=df,
        aws_conn_id=S3_CONN_ID,
        bucket_name=BUCKET_NAME,
        report_name=S3_FOLDER,
        filename=filename,
        data_interval_end=data_interval_end,
    )

    return file_s3_key


@dag(
    default_args={
        "owner": "ubaitur5",
        "on_failure_callback": send_error_message_telegram,
    },
    schedule_interval="0 1-11 * * *",
    template_searchpath=["/opt/airflow/dags/include/sql_files/"],
    start_date=pendulum.DateTime(2024, 7, 23),
    doc_md=doc_md,
    tags=["etl", "dimensions"],
    catchup=False,
)
def dim_employees():

    extract_employees_raw = SqlToS3OperatorImproved(
        task_id="extract_employees_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query="""
        SELECT 
            _IDRRef
            , _ParentIDRRef
            , Подразделение_ID
            , _Marked
            , _Folder
            , _Code
            , _Description
            , ИНН
        FROM vw_Сотрудники
        """,
        s3_bucket=BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="employees_raw.parquet",
        replace=True,
        aws_conn_id=S3_CONN_ID,
        file_format="parquet",
        pd_kwargs={"index": False},
    )
    create_or_replace_table_employees_raw = create_or_replace_table(
        conn_id=DWH_CONN_ID,
        table_name="employees_raw",
        s3_bucket=BUCKET_NAME,
        s3_key=extract_employees_raw.output,
    )

    ftp_zup_to_local = FTPFileTransmitOperator(
        task_id="ftp_zup_to_local",
        ftp_conn_id="smb_ftp",
        local_filepath=TMP_ZUP_XLSX_FILEPATH,
        remote_filepath=FTP_ZUP_FILEPATH,
        operation=FTPOperation.GET,
        create_intermediate_dirs=True,
    )

    zup_to_s3 = upload_zup_to_s3()

    create_or_replace_table_zup_employees_raw = ClickHouseOperator(
        task_id=f"create_or_replace_table_zup_employees_raw",
        clickhouse_conn_id=DWH_CONN_ID,
        database="raw_dbt",
        sql=f"""
        CREATE OR REPLACE TABLE zup_employees_raw
            ORDER BY tuple() AS SELECT * FROM s3('{{{{conn.minio_s3.extra_dejson.endpoint_url }}}}/{BUCKET_NAME}/{zup_to_s3}') 
        """,
    )

    ftp_zup_to_local >> zup_to_s3 >> create_or_replace_table_zup_employees_raw

    extract_employees_raw >> create_or_replace_table_employees_raw

    [
        create_or_replace_table_employees_raw,
        create_or_replace_table_zup_employees_raw,
    ] >> dbt_build(indirect_selection="buildable")


dim_employees()
