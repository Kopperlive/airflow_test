WITH source AS (
    SELECT * FROM {{ref('base_zup__all_employees')}}
)
SELECT * FROM source