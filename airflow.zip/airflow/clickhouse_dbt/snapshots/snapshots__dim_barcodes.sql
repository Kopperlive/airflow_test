{% snapshot snapshots__dim_barcodes %}
    select * from {{ ref('base_ar_trade__barcodes') }}
{% endsnapshot %}