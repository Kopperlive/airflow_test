import pendulum
from airflow.decorators import dag, task, task_group
from airflow.operators.bash import BashOperator
from airflow_clickhouse_plugin.operators.clickhouse import ClickHouseOperator
from common_utils.etl_tasks import create_or_replace_table
from common_utils.telegram_utils import send_error_message_telegram
from custom_operators.s3tosql import SqlToS3OperatorImproved

doc_md = ""

# S3 stuff
S3_CONN_ID = "minio_s3"
BUCKET_NAME = "etl-data-files-test"
S3_FOLDER = "dimensions"

AR_TRADE_CONN_ID = "nsp_ar_trade"
SQL_FILE = "extract_promotions.sql"
DWH_CONN_ID = "clickhouse_dwh"

DATE_RANGE = 30


@task_group
def dbt_build(models: list[str] = None, indirect_selection: str = "eager"):
    def format_model_selection(models: list[str]) -> str:
        """Convert a list of models into a dbt-compatible selection string."""
        if not models:
            return "+{{ dag.dag_id }}"  # Fallback to DAG ID if no models are provided
        return " ".join(
            f"+{model}" for model in models
        )  # Format as +model1,+model2,...

    # @task.run_if(lambda context: context["dag_run"].external_trigger)
    @task.bash
    def dbt_run():
        selection = format_model_selection(models=models)
        return f"dbt build --select {selection} --exclude test_type:data"

    @task.bash
    def dbt_test():
        selection = format_model_selection(models=models)
        return (
            f"dbt test --select {selection} --indirect-selection {indirect_selection}"
        )

    dbt_run() >> dbt_test()


@dag(
    default_args={
        "owner": "ubaitur5",
        "on_failure_callback": send_error_message_telegram,
    },
    schedule_interval="@daily",
    template_searchpath=["/opt/airflow/dags/include/sql_files/"],
    start_date=pendulum.DateTime(2023, 7, 23),
    doc_md=doc_md,
    tags=["etl", "dimensions"],
    catchup=False,
)
def dim_promotions():

    extract_promotions_raw = SqlToS3OperatorImproved(
        task_id="extract_promotions_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query=SQL_FILE,
        s3_bucket=BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="promotions_raw.parquet",
        replace=True,
        aws_conn_id=S3_CONN_ID,
        file_format="parquet",
        pd_kwargs={"index": False},
        params={"date_range": DATE_RANGE},
    )

    delete_promotions = ClickHouseOperator(
        task_id="delete_promotions",
        database="dwh",
        sql=f"DELETE FROM dim_promotions WHERE start_date<='{{{{data_interval_end.subtract(days=1) | ds}}}}' AND end_date>='{{{{data_interval_end.subtract(days={DATE_RANGE}) | ds}}}}'",
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    (
        extract_promotions_raw
        >> create_or_replace_table(
            conn_id=DWH_CONN_ID,
            table_name="promotions_raw",
            s3_bucket=BUCKET_NAME,
            s3_key=extract_promotions_raw.output,
        )
        >> delete_promotions
        >> dbt_build(indirect_selection="buildable")
    )


dim_promotions()
