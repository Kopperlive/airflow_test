WITH source AS (
    SELECT * FROM {{ ref('base_ar_trade__supply_types') }}
)

, final AS (
    SELECT *,
           CAST(CASE
               WHEN enum_value = 0 THEN 'Товар (купленный)'
               WHEN enum_value = 1 THEN 'Товар (принятый на коммиссию)'
           END AS String) AS description
    FROM source
)

SELECT * FROM final