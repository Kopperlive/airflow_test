from functools import partial
from io import BytesIO

import fdb
import pandas as pd
import pendulum
from airflow.decorators import dag, task, task_group
from airflow.operators.python import get_current_context
from common_utils.report.s3_utils import (
    read_df_from_s3,
    save_binary_file_to_s3,
    save_df_to_s3,
)
from common_utils.telegram_utils import send_error_message_telegram

# S3 stuff
S3_CONN_ID = "minio_s3"
BUCKET_NAME = "test"
ETL_FOLDER = "etl_cassa"

RESULT_FOLDER = "Кассы"


def _execute_query_to_df_with_ip(query: str, ip: str, db: str) -> pd.DataFrame:
    con = fdb.connect(
        dsn=ip + ":" + db,
        user="SYSDBA",
        password="masterkey",
        charset="UTF8",
    )

    df = pd.read_sql(
        query,
        con,
    )
    con.close()
    return df


@task()
def extract_list_of_market_servers():
    df_markets = read_df_from_s3(
        aws_conn_id=S3_CONN_ID,
        bucket_name=BUCKET_NAME,
        file_s3_key="ip-адреса касс.txt",
        sep="\s+",
    )
    df_markets = df_markets.T.reset_index()
    df_markets.columns = ["server_ip"]

    # df_markets = df_markets.head(3)
    # converting our dataframe to dictionary so we can create dynamic mapped tasks over this dataframe,particulary for task.expand_kwagrs()
    return df_markets.to_dict("records")


@task_group(group_id="extract_load_from_markets")
def process_logs(server_ip: str):
    @task(
        map_index_template="{{ my_custom_map_index }}",
        retries=3,
        retry_delay=pendulum.duration(minutes=2),
        retry_exponential_backoff=True,  # enable  auto increasing retry_delay,it will be increased by two times each time it runs,for example, 1st retry: 1h,2nd retry: 2h, 3rd retry:4h
    )
    def extract_log(
        server_ip: str,
        data_interval_start: pendulum.DateTime,
        data_interval_end: pendulum.DateTime,
    ):
        # Setting up map_index to market code and ip(so we can observe from web UI which mapped task is running )
        context = get_current_context()
        custom_map_index = server_ip
        context["my_custom_map_index"] = custom_map_index

        # query = read_sql_file(sql_file)
        query = f"SELECT  ID,DATETIME,USERCODE,ACTION FROM LOG WHERE DATETIME BETWEEN '{data_interval_start.to_datetime_string()}' AND '{data_interval_end.to_datetime_string()}'"

        print(query)
        df_cheques = _execute_query_to_df_with_ip(
            query,
            server_ip,
            r"D:\frontol_db\LOG.GDB",
        )

        filename = f"{server_ip}.csv"
        file_s3_key = save_df_to_s3(
            df=df_cheques,
            aws_conn_id=S3_CONN_ID,
            bucket_name=BUCKET_NAME,
            report_name=ETL_FOLDER,
            filename=filename,
            data_interval_end=data_interval_end,
        )
        return file_s3_key

    @task(
        map_index_template="{{ my_custom_map_index }}",
    )
    def extract_users(server_ip: str, data_interval_end: pendulum.DateTime):
        context = get_current_context()
        custom_map_index = server_ip
        context["my_custom_map_index"] = custom_map_index

        # query = read_sql_file(sql_file)
        print(data_interval_end.subtract(days=2).to_date_string())
        df_cheques = _execute_query_to_df_with_ip(
            'SELECT CODE,NAME FROM "USER"',
            server_ip,
            r"D:\frontol_db\MAIN.GDB",
        )

        filename = f"{server_ip}_users.csv"
        file_s3_key = save_df_to_s3(
            df=df_cheques,
            aws_conn_id=S3_CONN_ID,
            bucket_name=BUCKET_NAME,
            report_name=ETL_FOLDER,
            filename=filename,
            data_interval_end=data_interval_end,
        )
        return file_s3_key

    @task(
        map_index_template="{{ my_custom_map_index }}",
    )
    def transform_data(
        server_ip: str,
        log_s3_key: str,
        users_s3_key: str,
        data_interval_end: pendulum.DateTime,
    ):
        context = get_current_context()
        custom_map_index = server_ip
        context["my_custom_map_index"] = custom_map_index

        df_logs = read_df_from_s3(
            aws_conn_id=S3_CONN_ID,
            bucket_name=BUCKET_NAME,
            file_s3_key=log_s3_key,
        )

        start_indices = df_logs[df_logs["ACTION"] == "Визуальный поиск вход"].index
        end_indices = df_logs[df_logs["ACTION"] == "Визуальный поиск выход"].index

        # This will store the rows between 'Start' and 'End'
        df_searches = pd.DataFrame()

        # Loop through all pairs of 'Start' and 'End'
        for start, end in zip(start_indices, end_indices):
            # Check if start index is less than end index to ensure correct order
            if start < end:
                # Add the rows between 'Start' and 'End' to the result DataFrame
                df_searches = pd.concat([df_searches, df_logs.loc[start:end]])
            else:
                raise Exception(f"Error:{start},{end}")

        # Resetting index for the result DataFrame
        df_searches.reset_index(drop=True, inplace=True)

        df_users = read_df_from_s3(
            aws_conn_id=S3_CONN_ID,
            bucket_name=BUCKET_NAME,
            file_s3_key=users_s3_key,
        )

        df = pd.DataFrame()

        if not df_searches.empty:
            df = df_searches.merge(
                df_users, left_on="USERCODE", right_on="CODE", how="left"
            )
            df.drop(columns=["ID", "USERCODE", "CODE"], inplace=True)

        server_ip_splitted = server_ip.split(".")[:-1]
        print(server_ip_splitted)
        market_ip = ".".join(server_ip_splitted)
        filename = f"{market_ip}/{server_ip}.xlsx"

        excel_buffer = BytesIO()

        # Use the Excel writer and save to BytesIO object
        with pd.ExcelWriter(excel_buffer, engine="xlsxwriter") as writer:
            df.to_excel(writer, index=False, sheet_name="Sheet1")

        file_s3_key = save_binary_file_to_s3(
            aws_conn_id=S3_CONN_ID,
            bucket_name=BUCKET_NAME,
            report_name=RESULT_FOLDER,
            file_bytes=excel_buffer,
            filename=filename,
            data_interval_end=data_interval_end,
        )

        return file_s3_key

    log_s3_key = extract_log(server_ip)
    users_s3_key = extract_users(server_ip)
    transform_data(server_ip, log_s3_key, users_s3_key)


@dag(
    default_args={
        "retries": 2,
        "retry_delay": pendulum.duration(minutes=1),
        "owner": "ubaitur5",
        "on_failure_callback": partial(
            send_error_message_telegram, telegram_conn_id="cassa_bi_bot"
        ),
    },
    # schedule_interval="0 0 * * *",
    schedule_interval="@weekly",
    start_date=pendulum.DateTime(2024, 5, 1),
    catchup=False,
    template_searchpath=[
        "/opt/airflow/dags/include/sql_files/"
    ],  # So we can just pass *.sql file name to MsSqlOperator instead of specifying full path
    tags=["cassa", "monitoring"],
)
def monitoring_cassa_fraud():
    extract_list_servers = extract_list_of_market_servers()

    # # creating dynamic mapping tasks(for every value from extract_list_servers it will run function extract_load)
    process_logs.expand_kwargs(extract_list_servers)


monitoring_cassa_fraud()
