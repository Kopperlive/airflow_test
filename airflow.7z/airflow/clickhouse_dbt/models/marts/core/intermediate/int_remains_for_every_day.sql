WITH movements_and_next_month_combined AS (
    SELECT 
    *
    FROM {{ref('int_remains_movements_and_next_month_combined')}}
),
dimensions_for_every_day AS (
    SELECT 
    *
    FROM {{ref('int_remains_dimensions_cross_joined_for_every_day')}}
),

warehouses AS (
    SELECT
    * 
    FROM {{ ref('base_ar_trade__warehouses') }}
),

final AS (
    SELECT 
        date_add(day,-1,d.date) AS date
        , CAST(warehouses.division_id AS LowCardinality(UUID)) AS division_id
        , CAST(d.warehouse_id AS LowCardinality(UUID)) AS warehouse_id
        , CAST(d.contragent_id AS LowCardinality(UUID)) AS contragent_id
        , d.product_id AS product_id
        , SUM({{transform_decimal('rm.quantity')}})  OVER(PARTITION BY d.contragent_id,d.warehouse_id,d.product_id ORDER BY d.date DESC ) AS quantity
        , SUM({{transform_decimal('rm.cost_price')}}) OVER(PARTITION BY d.contragent_id,d.warehouse_id,d.product_id ORDER BY d.date DESC ) AS cost_price
        , SUM({{transform_decimal('rm.cost_price_VAT')}}) OVER(PARTITION BY d.contragent_id,d.warehouse_id,d.product_id ORDER BY d.date DESC ) AS cost_price_VAT
    FROM movements_and_next_month_combined rm
        RIGHT JOIN dimensions_for_every_day d
            ON rm.date=d.date AND rm.warehouse_id=d.warehouse_id AND rm.contragent_id=d.contragent_id AND rm.product_id=d.product_id
        JOIN warehouses 
            ON d.warehouse_id = warehouses.id
        QUALIFY quantity!=0 OR cost_price!=0 OR cost_price_VAT !=0
        SETTINGS join_algorithm='hash'
)

SELECT * FROM final