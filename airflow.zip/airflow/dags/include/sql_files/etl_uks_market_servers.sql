

select  div._Fld2105 AS [market_code],
       _Fld13813 AS [shop_index],
       _Fld10413_S AS [ConnectionString]
from _InfoRg10410 ips JOIN _Reference296 div
        ON ips._Fld10413_S like 'Provider=%'
           and div._IDRRef = ips._Fld10411_RRRef
           and div._Marked = 0x00

ORDER BY div._Fld13813 -- ShopIndex