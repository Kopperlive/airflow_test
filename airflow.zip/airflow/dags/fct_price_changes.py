from functools import partial

import pendulum
from airflow.decorators import dag
from airflow.providers.ssh.operators.ssh import SSHOperator
from common_utils.etl_tasks import create_or_replace_table, dbt_build
from common_utils.etl_utils import build_bcp_command, get_data_interval_start
from common_utils.telegram_utils import send_error_message_telegram

doc_md = ""


DWH_CONN_ID = "clickhouse_dwh"

SQL_FILE = "extract_price_changes.sql"

S3_BUCKET_NAME = "etl-data-files-test"
S3_FOLDER_NAME = "price_changes"
FILE_NAME = "price_changes_raw.csv"
TMP_PATH = "/tmp/" + FILE_NAME


@dag(
    default_args={
        "owner": "h_abdullaev",
        "on_failure_callback": send_error_message_telegram,
    },
    schedule_interval="0 1-11 * * *",
    start_date=pendulum.DateTime(2025, 1, 16),
    doc_md=doc_md,
    tags=["facts"],
    catchup=False,
    max_active_runs=1,
    user_defined_macros={
        "get_data_interval_start": get_data_interval_start,
    },
)
def fct_price_changes():
    extract_price_changes = SSHOperator(
        task_id="extract_on_s3",
        ssh_conn_id="ssh__s3",
        command=partial(build_bcp_command, sql_file=SQL_FILE, destination=TMP_PATH),
        conn_timeout=20,
        cmd_timeout=1200,  # 20 minutes
    )

    s3_key = (
        "{{data_interval_end.year}}/{{data_interval_end.month}}/{{data_interval_end.day}}/"
        + f"{S3_FOLDER_NAME}/"
        + FILE_NAME
    )

    upload_to_s3 = SSHOperator(
        task_id="upload_to_s3",
        ssh_conn_id="ssh__s3",
        command=f"~/minio-binaries/mc mv {TMP_PATH} local/{S3_BUCKET_NAME}/{s3_key}",
        conn_timeout=20,
        cmd_timeout=180,  # 3 minutes
    )

    columns_info = """ (
        "_IDRRef" Nullable(String)
        , "_Date_Time" Nullable(Datetime64)
        , "ДатаНачалаДействия" Nullable(Datetime64)
        , "_Number" Nullable(String)
        , "Автор_ID" Nullable(String)
        , "ПодразделениеКомпании_ID" Nullable(String)
        , "Комментарий" Nullable(String)
        , "Контрагент_ID" Nullable(String)
        , "ТипЦен_ID" Nullable(String)
        , "ХозОперация_ID" Nullable(String)
        , "СкладКомпании_ID" Nullable(String)
        , "Номенклатура_ID" Nullable(String)
        , "ЕдиницаИзмерения_ID" Nullable(String)
        , "Цена" Nullable(Float64)
        , "ЦенаБазовая" Nullable(Float64)
    )
    """

    (
        extract_price_changes
        >> upload_to_s3
        >> create_or_replace_table(
            conn_id=DWH_CONN_ID,
            table_name="price_changes_raw",
            columns_info=columns_info,
            s3_bucket=S3_BUCKET_NAME,
            s3_key=s3_key,
        )
        >> dbt_build()
    )


fct_price_changes()
