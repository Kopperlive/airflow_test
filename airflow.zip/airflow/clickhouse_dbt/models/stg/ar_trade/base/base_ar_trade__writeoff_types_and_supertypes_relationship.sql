WITH source AS (
    SELECT * FROM {{ source('raw_dbt','writeoff_types_and_supertypes_relationship_raw') }}
)

, renamed AS (
    SELECT
        {{ transform_binary_to_uuid('"СтатьяРасходов_ID"') }} AS writeoff_type_id
        , {{ transform_binary_to_uuid('"ВидСписания_ID"') }} AS writeoff_supertype_id
    FROM source
)

SELECT * FROM renamed
