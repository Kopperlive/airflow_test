WITH plan AS (
    SELECT * FROM {{ref('base_ar_trade__plans')}}
),
division AS (
    SELECT * FROM {{ref('base_ar_trade__divisions')}}
),

final AS (
    SELECT 
        DISTINCT 
        division.id AS division_id
        , plan.month AS month
        , plan.amount*1000 AS amount 
        , plan.quantity AS quantity
        , plan.cheques_quantity AS cheques_quantity
    FROM plan 
        JOIN division 
            ON leftUTF8(plan.division_name,14)=leftUTF8(division.description,14)
        WHERE plan.amount!=0 OR plan.quantity!=0 OR plan.cheques_quantity!=0
)

SELECT * FROM final