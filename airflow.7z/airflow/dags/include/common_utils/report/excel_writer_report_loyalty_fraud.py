from io import BytesIO

import xlsxwriter
from pandas import DataFrame


def write_excel(
    rus_columns: list, start_date_period: str, end_date_period: str, df: DataFrame
) -> BytesIO:
    """
    Custom function to write the loyalty frauds report into excel file

    Parameters:
    rus_columns: list
        List of russian names of columns
    filename: str
        Name of the file to be saved
    start_date_period: str
        Start datetime of the period
    end_date_period: str
        End datetime of the period
    df: pd.DataFrame
        DataFrame with the data to be written

    Returns:
    --------
    BytesIO
        BytesIO object with the excel file
    """
    buffer = BytesIO()

    with xlsxwriter.Workbook(buffer, {"in_memory": True}) as workbook:
        # Creating the file (workbook)
        # Adding worksheet into workbook to work with
        sheet = workbook.add_worksheet()

        # Types of format, in order of occurence
        # For smallest, standart cell
        std_frmt = workbook.add_format({"font_name": "Arial", "font_size": 8})

        # Main header format
        head_frmt = workbook.add_format(
            {
                "bold": "True",
                "font_name": "Arial",
                "font_size": 10,
                "font_color": "white",
                "border": 2,
                "border_color": "#BDC7EB",
                "fg_color": "#4574A0",
                "align": "left",
                "valign": "top",
            }
        )

        # Subheader for market
        market_frmt = workbook.add_format(
            {
                "bold": "True",
                "font_name": "Arial",
                "font_size": 8,
                "font_color": "#003366",
                "border": 2,
                "border_color": "#BDC7EB",
                "fg_color": "#C6E2FF",
                "align": "left",
                "valign": "top",
            }
        )

        # Sub-subheader for cardholders
        card_frmt = workbook.add_format(
            {
                "bold": "True",
                "font_name": "Arial",
                "font_size": 8,
                "font_color": "#003366",
                "border": 2,
                "border_color": "#BDC7EB",
                "fg_color": "#EEEEEE",
                "num_format": "0",
            }
        )

        # Main piece of uchanging header
        sheet.write(1, 0, "Параметры", std_frmt)
        text = str("Период: " + start_date_period[:10] + " - " + end_date_period[:10])
        sheet.merge_range(1, 1, 1, 2, text, cell_format=std_frmt)

        # Set the width of columns
        sheet.set_column(0, 0, 20)
        sheet.set_column(1, 7, 14)

        sheet.merge_range(3, 0, 3, 4, "Маркет", cell_format=head_frmt)
        sheet.write_row(4, 0, rus_columns[1:6], cell_format=head_frmt)

        sheet.merge_range(5, 2, 5, 4, "", cell_format=head_frmt)
        sheet.write_row(5, 0, rus_columns[6:9], cell_format=head_frmt)
        sheet.merge_range(3, 5, 5, 5, "Кол-во Чеков", cell_format=head_frmt)
        sheet.merge_range(3, 6, 5, 6, "Сумма", cell_format=head_frmt)
        sheet.merge_range(3, 7, 5, 7, "Сумма бонусов", cell_format=head_frmt)

        pntr = 6  # the pointer of current row we write into (start with 6th because previous ones are the unchanged, big header)

        # Iterate over each market
        for markets, temp_df in df.groupby(level=0):
            current_market_df = temp_df.loc[
                markets
            ]  # primary level of hierarchy: Markets

            sheet.set_row(
                pntr, None, None, {"level": 0}
            )  # just set level for collpasing
            sheet.merge_range(
                pntr, 0, pntr, 4, "", market_frmt
            )  # merge for better look

            sheet.write(pntr, 0, markets, market_frmt)  # write market name
            sheet.write_row(
                pntr, 5, ["", "", ""], market_frmt
            )  # fill the rest to make it look good
            pntr += 1  # Increment to get to the next row

            # Iterate over card holders in the market
            for cards, info_df in current_market_df.groupby(
                level=[x for x in range(5)]
            ):
                current_transcations_df = info_df.loc[
                    cards
                ]  # next is the frauder's card

                sheet.set_row(
                    pntr, None, None, {"level": 1}
                )  # just set level for collpasing
                sheet.write_row(
                    pntr, 0, cards, card_frmt
                )  # insert frauder's personal info
                sumdata = current_transcations_df.iloc[
                    0, [-1, -2, -3]
                ]  # cummulative data (it is inside of the dataframe, last columns, but order is broken)
                sheet.write_row(pntr, 5, sumdata, card_frmt)  # insert it
                pntr += 1

                # Iterate over all transaction of a cardholder
                clear_df = current_transcations_df.reset_index()
                for ind in range(len(clear_df)):

                    sheet.set_row(
                        pntr, None, None, {"level": 2}
                    )  # just set level for collpasing
                    sheet.merge_range(pntr, 2, pntr, 4, "", cell_format=std_frmt)

                    input_data = clear_df.loc[ind, ["День", "Касса", "Номер Чека"]]
                    sheet.write_row(pntr, 0, input_data, std_frmt)

                    sum_data = [
                        1,
                        (clear_df.loc[ind, "Сумма Чека"]),
                        (clear_df.loc[ind, "Сумма Бонусов"]),
                    ]
                    sheet.write_row(pntr, 5, sum_data, std_frmt)
                    pntr += 1

    buffer.seek(0)

    return buffer
