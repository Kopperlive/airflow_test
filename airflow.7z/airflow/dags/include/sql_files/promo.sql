SELECT CONVERT(NCHAR(34), s.Подразделение_ID, 1) AS Подразделение_ID,
       CONVERT(NCHAR(34), s.Объект_ID, 1) AS Номенклатура_ID,
	   CONVERT(NCHAR(34), ns.ТипЦен_ID, 1) AS ТипЦен_ID,
	   CONVERT(NCHAR(34), ns.ХозОперация_ID, 1) AS ХозОперация_ID,
       CONVERT(NCHAR(34), ns.Контрагент_ID, 1) AS Контрагент_ID,
	   CONVERT(NCHAR(34), ns.Автор_ID, 1) AS Автор_ID,
       s.НачалоДействия,
       s.КонецДействия,
       pl._Description AS Аббревиатура,
       ts._Description AS ТипСкидки,
       ns.Комментарий,
       nss.ТекущаяЦена,
       nss.ЗначениеСкидки,
       nss.ТекущаяЗакупочнаяЦена,
       nss.АкционнаяЗакупочнаяЦена
FROM vw_Скидки s WITH (NOLOCK)
    LEFT JOIN vw_ВидыПрайсЛистов pl WITH (NOLOCK)
        ON pl._IDRRef = s.ВидПрайсЛистаПодарка_ID
    JOIN vw_НазначениеСкидок ns WITH (NOLOCK)
        ON ns._IDRRef = s._RecorderRRef
    JOIN vw_НазначениеСкидок_Скидки nss WITH (NOLOCK)
        ON nss.Ссылка = ns._IDRRef
           AND nss.Номенклатура_ID = s.Объект_ID
    LEFT JOIN vw_ТипыСкидок ts  WITH (NOLOCK)
        ON ts._IDRRef = ns.ТипСкидки_ID

WHERE s.НачалоДействия <= '{{data_interval_end.subtract(days=1).add(years=2000) | ds_nodash}}'
      AND s.КонецДействия >= '{{data_interval_end.subtract(days=params.date_range).add(years=2000) | ds_nodash}}'
      AND s._Active = 0x01
      AND s.Действует = 0x01
      AND ns._Marked = 0x00
      AND ns._Posted = 0x01