import os

import duckdb
import pendulum
from airflow.decorators import dag, task
from airflow.models import Variable
from airflow.models.taskinstance import TaskInstance
from airflow.operators.bash import BashOperator
from airflow_clickhouse_plugin.operators.clickhouse import ClickHouseOperator
from common_utils.etl_utils import build_delete_partition_query, get_data_interval_start
from common_utils.sql_utils import read_sql_file
from common_utils.telegram_utils import send_error_message_telegram

doc_md = """
# ETL Facts Sales DAG Documentation

## Overview

The `sales` DAG is designed to orchestrate the extraction, transformation, and loading (ETL) of sales data from a source database, process it using DuckDB, and finally store the transformed data into a ClickHouse data warehouse. Additionally, this data is also backed up to an S3 bucket in Parquet format.

This DAG is intended to run daily. It includes tasks that handle data extraction, loading, transformation, partition management, and clean-up.

## Tasks Description

### 1. `extract_sales`

- **Type**: BashOperator
- **Purpose**: Extracts sales data from a Microsoft SQL Server using the `bcp` utility. The data is extracted based on a SQL query defined in an external file and is saved into a CSV file.
- **Output**: A CSV file stored at `/tmp/salesraw.csv`.

### 2. `load_to_duckdb`

- **Type**: Python task (Airflow @task decorator)
- **Purpose**: Loads the raw CSV data into a DuckDB database, creating a new table named `sales_raw`. This is the staging area for further data transformation.
- **Dependencies**: Runs after `extract_sales`.

### 3. `transform_sales`

- **Type**: Python task (Airflow @task decorator)
- **Purpose**: Transforms the data in DuckDB by performing aggregations and data type adjustments. The transformed data is then exported to an S3 bucket in Parquet format.
- **Dependencies**: Runs after `load_to_duckdb`.
- **Key Operations**:
  - Casts fields to appropriate data types.
  - Aggregates sales data.
  - Configures S3 connection settings directly in the task.
  - Exports data to S3 using the HTTP File System (httpfs) extension in DuckDB.
- **Output**: A Parquet file in an S3 bucket, path dynamically determined by the execution date.

### 4. `drop_partitions`

- **Type**: ClickHouseOperator
- **Purpose**: Deletes older partitions from the ClickHouse `sales` table based on a range specified by the `FACTS_MONTH_RANGE` variable.
- **Dependencies**: Runs after `transform_sales`.

### 5. `load_sales`

- **Type**: ClickHouseOperator
- **Purpose**: Loads the transformed data from the S3 bucket into the ClickHouse data warehouse.
- **Dependencies**: Runs after `delete_sales`.

### 6. `remove_temp_files`

- **Type**: Python task (Airflow @task decorator)
- **Purpose**: Cleans up temporary files (both the CSV and DuckDB database files) used during the DAG's execution.
- **Dependencies**: Runs after all other tasks.

## Execution Flow

The DAG execution begins with the `extract_sales` task and follows through `load_to_duckdb`, `transform_sales`, `delete_sales`, `load_sales`, and concludes with `remove_temp_files`. This sequence ensures that data is pulled, processed, and loaded systematically before cleaning up resources to prevent interference with subsequent runs.

"""

# S3 stuff
BUCKET_NAME = "etl-data-files"
S3_FOLDER = "sales"  # name of the folder to store our files in

DUCKDB_TEMP_FILE = "/tmp/sales.db"

# tempory place to store results from bcp utility
SALES_RAW_TEMP_FILE = "/tmp/salesraw.csv"

## how many months to delete backwards
FACTS_MONTH_RANGE = int(Variable.get("facts_month_range"))

SALES_QUERY = read_sql_file("sales.sql").format(month_range=FACTS_MONTH_RANGE)


@task
def load_to_duckdb():
    """
    Loads sales data from a CSV file into a DuckDB table for further processing. This function is responsible
    for reading the raw CSV file stored at 'SALES_RAW_TEMP_FILE' and importing the data into a new or existing
    DuckDB table named 'sales_raw'.

    The data is read with explicit column names specified, ensuring that each column is correctly identified
    in the resulting DuckDB table. This task forms the first step in the transformation process, where raw data
    is staged before transformation.

    No parameters are required for this function as it operates based on predefined global variables.

    Returns:
        None: This function does not return any value but performs a database operation which involves creating
        or replacing the 'sales_raw' table in the DuckDB instance located at 'DUCKDB_TEMP_FILE'.

    Example:
        >>> load_to_duckdb()
        # This will read the data from '/tmp/salesraw.csv' and load it into the DuckDB database at '/tmp/sales.db'

    Raises:
        IOError: If the CSV file specified in 'SALES_RAW_TEMP_FILE' does not exist or cannot be read.
        DatabaseError: If there are issues connecting to the DuckDB database or executing the SQL commands.

    Note:
        - Ensure that the DuckDB database file and the CSV file paths are correctly set in the global variables.
        - This function assumes that the DuckDB connection can be established without errors and that the CSV file is
          formatted correctly with data matching the expected schema for 'sales_raw'.
    """
    conn = duckdb.connect(DUCKDB_TEMP_FILE)

    # names parameter specifies column names since bcp doesn't export data with column names
    conn.sql(
        f"""CREATE OR REPLACE TABLE sales_raw AS SELECT * FROM read_csv('{SALES_RAW_TEMP_FILE}',names= [ 
            '_Period',
            'ПодразделениеКомпании_ID',
            'СкладКомпании_ID',
            'Номенклатура_ID',
            'Поставщик_ID',
            'Покупатель_ID',
            'ДоговорВзаиморасчетов_ID',
            'СтатусПартии_ID',
            'ХозОперация_ID',
            'БезналичныйРасчет',
            'СтавкаНДС_ID',
            'Количество',
            'Сумма',
            'СуммаНДС',
            'СуммаСкидки',
            'Себестоимость',
            'СуммаНДСВходящий'
         ])"""
    )


@task
def transform_sales(data_interval_end: pendulum.DateTime, ti: TaskInstance):
    """
    Transforms and aggregates sales data stored in a DuckDB table, then exports the transformed data to an S3 bucket in Parquet format.
    The function adjusts data types, performs aggregation, and exports the resultant dataset, facilitating downstream analytics and storage efficiency.

    This process includes casting certain fields to appropriate data types, aggregating data at various levels, and finally, exporting the data to S3.
    The function also configures and uses DuckDB's httpfs extension to interact with S3, demonstrating integration between DuckDB and external storage services.

    Parameters:
        data_interval_end (pendulum.DateTime): The end date of the data interval which determines the partition under which the data will be stored in S3.
        ti (TaskInstance): The TaskInstance object passed by Airflow, which is used here to push the S3 key to XCom for use in subsequent tasks.

    Returns:
        None: This function performs database and file operations but does not return any value.

    Example:
        >>> from airflow.models.taskinstance import TaskInstance
        >>> transform_sales(pendulum.datetime(2024, 12, 31), TaskInstance(task=task, execution_date=pendulum.datetime(2024, 12, 31)))
        # This will process and export sales data up to the end of December 2024.

    Raises:
        DatabaseError: If any SQL execution fails or if the connection to the database cannot be established.
        IOError: If there is an issue with the file operations, particularly with exporting data to S3.

    Note:
        - It is crucial that the DuckDB connection is correctly established and that the necessary extensions (like httpfs) are installed and loaded.
        - The function expects the 'sales_raw' table to be pre-loaded with relevant data in the correct format.
        - S3 access configurations such as endpoint, access key, and secret access key are hardcoded, which is generally not recommended for production environments.
    """
    conn = duckdb.connect(DUCKDB_TEMP_FILE)

    conn.sql(
        """CREATE OR REPLACE TABLE sales AS
            
            SELECT
                CAST(_Period AS DATE) - INTERVAL 2000 YEAR AS date,
                ПодразделениеКомпании_ID AS division_id,
                СкладКомпании_ID AS warehouse_id,
                Поставщик_ID AS contragent_id,
                Покупатель_ID buyer_id,
                ДоговорВзаиморасчетов_ID AS contragent_settlement_id,
                Номенклатура_ID AS product_id,
                СтатусПартии_ID as supply_type_id,
                ХозОперация_ID AS operation_id,
                CAST(БезналичныйРасчет AS INT) AS payment_method_id,
                СтавкаНДС_ID vat_rate_id,
                SUM(Количество) AS quantity,
                SUM(Сумма-СуммаНДС) AS amount,
                SUM(СуммаНДС) AS amount_VAT,
                SUM(СуммаСкидки) AS amount_discount,
                SUM(Себестоимость) AS cost_price,
                SUM(СуммаНДСВходящий) AS cost_price_VAT
            FROM sales_raw
            GROUP BY 
                date,
                operation_id,
                division_id,
                warehouse_id,
                contragent_id,
                buyer_id,
                contragent_settlement_id,
                product_id,
                supply_type_id,
                payment_method_id,
                vat_rate_id
        """
    )

    conn.sql("LOAD httpfs;")

    sales_filename = "sales.parquet"
    sales_s3_key = f"{BUCKET_NAME}/{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}/{S3_FOLDER}/{sales_filename}"
    conn.sql(f"COPY sales TO 's3://{sales_s3_key}';")
    conn.close()
    ti.xcom_push(key="s3_key", value=sales_s3_key)


@task
def remove_temp_files():
    """
    Removes temporary files used during the ETL process. This function deletes the DuckDB database file and the CSV file
    containing raw sales data. Its primary purpose is to ensure that no residual data remains that could potentially
    interfere with future ETL runs or consume unnecessary disk space.

    The deletion targets are specified by the global variables 'DUCKDB_TEMP_FILE' and 'SALES_RAW_TEMP_FILE'. The function
    assumes that these files exist and are no longer needed at the point of execution. This is typically called as a
    cleanup step at the end of an ETL workflow.

    Parameters:
        None

    Returns:
        None: This function does not return any value but confirms the deletion of specified files through successful execution.

    Example:
        >>> remove_temp_files()
        # This would attempt to delete the files at '/tmp/sales.db' and '/tmp/salesraw.csv'

    Raises:
        OSError: If the file deletion fails, an OSError may be raised indicating issues such as the file not existing or
                 the process lacking the necessary permissions to delete the file.

    Note:
        - It is important to ensure that these files are not in use by any other process at the time of deletion to
          prevent errors.
        - Consider implementing error handling within the calling process to manage potential exceptions from this function.
    """
    os.remove(DUCKDB_TEMP_FILE)
    os.remove(SALES_RAW_TEMP_FILE)


@dag(
    default_args={
        "owner": "ubaitur5",
        "on_failure_callback": send_error_message_telegram,
    },
    schedule_interval="0 0,4,8 * * *",
    # schedule_interval='@daily',
    template_searchpath=["/opt/airflow/dags/include/sql_files/"],
    start_date=pendulum.DateTime(2024, 1, 1),
    doc_md=doc_md,
    tags=["etl", "facts"],
    max_active_runs=1,
    catchup=False,
    user_defined_macros={
        "build_delete_partition_query": build_delete_partition_query,
        "get_data_interval_start": get_data_interval_start,
    },
)
def sales():

    extract_sales = BashOperator(
        task_id="extract_sales",
        bash_command=f"""/opt/mssql-tools18/bin/bcp "
         {SALES_QUERY}
        " queryout {SALES_RAW_TEMP_FILE} -c -t, -D -S WIN-STANDBY -d AR_TRADE -U SR -P SR20@#""",
    )

    load_sales = ClickHouseOperator(
        task_id="load_sales",
        database="dwh",
        sql="sales_load.sql",
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    drop_partitions = ClickHouseOperator(
        task_id="drop_partitions",
        database="dwh",
        sql=f"ALTER TABLE sales {{{{build_delete_partition_query({FACTS_MONTH_RANGE},data_interval_end)}}}}",
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    (
        extract_sales
        >> load_to_duckdb()
        >> transform_sales()
        >> drop_partitions
        >> load_sales
        >> remove_temp_files()
    )


sales()
