import json

import pandas as pd
import pendulum
import pyodbc
from airflow.decorators import dag, task, task_group
from airflow.exceptions import AirflowSkipException
from airflow.hooks.base import BaseHook
from airflow.models import Variable
from airflow.models.taskinstance import TaskInstance
from airflow.operators.python import get_current_context
from airflow.providers.amazon.aws.transfers.s3_to_ftp import S3ToFTPOperator
from airflow.providers.common.sql.operators.sql import SQLColumnCheckOperator
from airflow.providers.ftp.hooks.ftp import FTPHook
from airflow.providers.microsoft.mssql.hooks.mssql import MsSqlHook
from airflow_clickhouse_plugin.operators.clickhouse import ClickHouseHook
from common_utils.report.s3_utils import save_df_to_s3
from common_utils.sql_utils import read_sql_file
from common_utils.telegram_utils import send_error_message_telegram

doc_md = """
# ETL Process for Market Cheques

This DAG, `etl_cheques`, is designed to manage the Extract, Transform, Load (ETL) process of cheque data from multiple market servers into a data warehouse, followed by various data management and transfer operations.
## Important
If you need to clear failed markets in *extract_data_from_markets* task(or in any dynamic mapped task),click on **Clear Task** button and select **Only Failed** option in **Include** section.
You can see affected downstream tasks in **Affected tasks** dropdown button.

If you just do **Clear Task** without **Only Failed** option, it will rerun all downstream tasks for all markets whether they were failed or not,you can see it in **Affected tasks** dropdown


## Overview

The DAG performs several key operations:
1. **Database Setup**: Ensures that the necessary schema and tables are present in the data warehouse.
2. **Data Cleanup**: Removes outdated records from the data warehouse based on the data interval end date.
3. **Data Extraction**: Retrieves lists of market servers(Replaces migrated UKS servers with new centralized server for UKS) and their respective cheque data.
4. **Data Loading**: Loads the extracted data into the central data warehouse.
5. **Data Transfer**: Transfers data files to an SMB server via FTP for backup and further processing.
6. **Data Quality Checks**: Performs column-level data quality checks on the loaded data.

## Task Groups and Tasks

### 1. Database Preparation
- **Create Schema**: Checks if the specified schema exists in the data warehouse, creates it if not.
- **Create Table**: Ensures the `FactCheques` table exists within the schema, following the defined structure from `ddl_DWH_FactCheques.sql`.

### 2. Data Management
- **Delete Old Data**: Purges records from the `FactCheques` table that are older than the specified date range to maintain data freshness and accuracy.

### 3. Data Extraction and Loading
- **Extract List of Market Servers**: Retrieves a list of market servers from which to pull data, saves it to S3, and makes this list available to subsequent tasks via XCom.
- **Extract and Load Market Data**: For each market server, extracts cheque data, saves it to an S3 bucket, and transfers these data files to an FTP server located on an SMB server. Finally, performs a bulk insert of the data into the data warehouse.

### 4. Data Quality Assurance
- **Data Quality Checks**: Uses `SQLColumnCheckOperator` to ensure that the data meets specified quality standards, such as checking if the total amounts are below a certain threshold.

## Parameters
- **`PROD_DWH_CONN_ID`**: Connection ID for the production data warehouse.
- **`AR_TRADE_CONN_ID`**: Connection ID for querying market servers.
- **`S3_CONN_ID`**: Connection ID for AWS S3 where intermediate files are stored.
- **`FTP_CONN_ID`**: Connection ID for the FTP server on the SMB server.
- **`DATE_RANGE`**: Number of days to look back for deleting old data and extracting new data.
- **`SCHEMA_NAME`**, **`TABLE_NAME`**: Names for the schema and table where the data will be managed.

## Usage
This DAG is scheduled to run daily, ensuring that cheque data from market servers is regularly updated in the data warehouse. It handles dependencies and ensures data integrity throughout the process, facilitating smooth operations in environments where data-driven decisions are critical.

## Configuration
Ensure that the Airflow environment has the necessary Python packages, connection configurations, and access rights to execute tasks involving interactions with SQL Server, S3, and FTP servers.

## Tagging
Tagged under `uks` and `etl`, making it easy to filter and manage in the Airflow UI.
"""


# Queries used in report (all of them stored in include/sql_files)
QUERY_MARKET_SERVERS = "etl_uks_market_servers.sql"
QUERY_CHEQUES = "etl_cheques.sql"
QUERY_DDL_DWH_FactCheques = "ddl_DWH_FactCheques.sql"

# because we don't want to read it every time we query a market
QUERY_CHEQUES_STRING = read_sql_file(QUERY_CHEQUES)

AR_TRADE_CONN_ID = "nsp_ar_trade"

# S3 stuff
S3_CONN_ID = "minio_s3"
BUCKET_NAME = "etl-data-files"
S3_FOLDER = "etl_cheques"

# DB stuff
PROD_DWH_CONN_ID = "prod_dwh"


UID = Variable.get("Reader")
PWD = Variable.get("Reader_password")


# Get data from last N days
DATE_RANGE = int(Variable.get("cheques_date_range"))

# SMB stuff
FTP_CONN_ID = "smb_ftp"

FTP_FOLDER = "BI/ETL/Cheques"
FTP_DNS = "NSP-AsiaSMB.frunze.local"


# Destination
SCHEMA_NAME = "uks"
TABLE_NAME = "FactCheques"


def _execute_query_to_df_with_hook(query: str, MSSQL_CONN_ID: str) -> pd.DataFrame:
    """Helper function: execute query, return result as a Pandas Dataframe"""
    hook = MsSqlHook(mssql_conn_id=MSSQL_CONN_ID)
    conn = hook.get_conn()
    df = pd.read_sql(query, conn)
    return df


def _execute_query_to_df_with_pyodbc(
    query: str, ip: str, db: str, params: tuple = None
) -> pd.DataFrame:
    MS_CONN_STR = f"DRIVER=ODBC Driver 17 for SQL Server;SERVER={ip};PORT=1433;UID={UID};PWD={PWD};Database={db}"

    conn = pyodbc.connect(MS_CONN_STR, timeout=10)

    print("Params:", params)

    df = pd.read_sql(
        query,
        conn,
        params=params,
    )

    conn.close()

    return df


@task()
def extract_list_of_market_servers(
    data_interval_end: pendulum.DateTime, ti: TaskInstance
):
    """
    Extracts a list of market servers from a SQL database, modifies it by removing servers that have migrated to a unified DNS (UKS_DNS),
    and appends this unified DNS to the list. This task then saves the modified list to an S3 bucket and pushes the file's S3 key to XCom
    for subsequent use in other tasks.

    The function performs several steps:
    1. Extracts the initial list of market servers using a predefined SQL query from a file.
    2. Appends a DataFrame with the unified DNS for migrated markets.
    3. Queries for shop indexes that have been migrated to the unified DNS in the last 5 days.
    4. Removes any market servers from the original list that are now part of the migrated DNS.
    5. Concatenates the DNS for migrated markets with the remaining market server list.
    6. Saves the final DataFrame as a CSV file to an S3 bucket.
    7. Pushes the S3 key of the saved file to XCom.

    Parameters:
        data_interval_end (pendulum.DateTime): The end date for the data interval, used to timestamp the saved file.
        ti (TaskInstance): Airflow's TaskInstance object, used to perform XCom operations within the task.

    Returns:
        dict: A dictionary representation of the DataFrame containing the final list of market servers,
              where each key represents a column, and the corresponding value is a list of data points for that column.
              This is used to facilitate the creation of dynamically mapped tasks.

    Side Effects:
        - Saves a CSV file to an S3 bucket.
        - Pushes the S3 key of the saved file to Airflow's XCom, which can be used by subsequent tasks.
        - The DataFrame to dictionary conversion helps in setting up dynamic tasks based on the list of market servers.

    Example of use:
        - This task is typically part of an Airflow DAG that handles ETL processes for retail market data,
          where dynamic task mapping is required based on the list of active and recently migrated market servers.
    """
    query = read_sql_file(QUERY_MARKET_SERVERS)
    df_market_servers = _execute_query_to_df_with_hook(query, AR_TRADE_CONN_ID)

    print(df_market_servers["ConnectionString"])

    # Getting IP of markets from Connection string
    df_market_servers["market_ip"] = (
        df_market_servers["ConnectionString"].str.split(pat="=").str[-1]
    )

    df_market_servers["uks_db"] = (
        df_market_servers["ConnectionString"]
        .str.split(pat="=")
        .str[-2]
        .str.split(";")
        .str[0]
    )
    df_market_servers.drop(["ConnectionString"], axis=1, inplace=True)

    filename = "market_servers.csv"
    file_s3_key = save_df_to_s3(
        df=df_market_servers,
        aws_conn_id=S3_CONN_ID,
        bucket_name=BUCKET_NAME,
        report_name=S3_FOLDER,
        filename=filename,
        data_interval_end=data_interval_end,
    )

    # Push the file's S3 key to XCom for further use
    ti.xcom_push(key="file_s3_key", value=file_s3_key)

    # converting our dataframe to dictionary so we can create dynamic mapped tasks over this dataframe,particulary for task.expand_kwagrs()
    return df_market_servers.to_dict("records")


@task_group(group_id="extract_load_from_markets")
def extract_load(market_ip: str, market_code: str, shop_index: str, uks_db: str):
    """
        IMPORTANT: why am i returning values from tasks,instead of doing xcom_push?
            It is because all tasks in this task group are  dynamic mapped tasks,it means that when I need to do xcom_pull, I will need to do it like this:
                file_s3_key = ti.xcom_pull(key='file_s3_key',task_ids='extract_data_from_markets') -- it will return not one value but list of all values generated by this mapped task,e.g.
                                                                                ['2024/6/1/Ф01.csv','2024/6/1/Ф02.csv','2024/6/1/Ф03.csv'....]
    ,


        The reason I placed 4 tasks in one group instead of separating into two groups (extract,load) is because in this case second group(load) will only start
        after all mapped tasks in extract group finished.

        A task group that orchestrates the extraction and loading of market data from different market servers to a central data warehouse and then transfers this data to an SMB location.

        This group consists of a sequence of tasks that perform the following operations:
        1. Extract data from an external market server's database using a specified SQL file.
        2. Save the extracted data to an S3 bucket.
        3. Transfer the saved data from the S3 bucket to an SMB server using FTP.
        4. Perform a bulk insert of the data from the SMB server into a SQL Server database table.
        5. Clean up by deleting the transferred file from the SMB server.

        Parameters:
            market_ip (str): IP address of the market server from which data is to be extracted.
            market_code (str): A unique code identifying the market, which is used for naming the output files and as an identifier in logs and other tracking.
            divisionIDRef (str): A division identifier that is likely used in the SQL query to filter data specific to a division.

        The task group facilitates tracking and management of data flow from individual markets by using dynamic mapping for each market server. This setup allows for scalable and manageable ETL processes for multiple market servers simultaneously, improving efficiency and error handling in data transfer operations.

        Usage:
            The `extract_load` task group is used within an Airflow DAG to manage the data extraction and loading process from multiple market servers. It is dynamically expanded based on the list of market servers extracted by another task in the DAG, ensuring each market's data is handled individually.

        Returns:
            None: This task group orchestrates other tasks but does not return any values directly. It handles data flow and management internally within the defined tasks.
    """

    @task(
        map_index_template="{{ my_custom_map_index }}",
        retries=2,  # TODO: SET TO 3
        retry_delay=pendulum.duration(minutes=5),
        retry_exponential_backoff=True,  # enable  auto increasing retry_delay,it will be increased by two times each time it runs,for example, 1st retry: 1h,2nd retry: 2h, 3rd retry:4h
    )
    def extract_data_from_markets(
        market_ip: str,
        market_code: str,
        db: str,
        shop_index: str,
        data_interval_end: pendulum.DateTime,
    ):
        """
        Extracts data from an external market database, saves it to an S3 bucket, and returns the S3 key for further operations.

        The function reads a SQL query from a file, executes it against a specified market's database server, fetches the results, and stores them as a CSV file in an S3 bucket.

        Parameters:
            sql_file (str): The path to the SQL file containing the query to execute.
            market_ip (str): The IP address of the market server from which data will be extracted.
            market_code (str): A unique code identifying the market, used in file naming.
            divisionIDRef (str)
            data_interval_end (pendulum.DateTime): The end of the data interval for which the data is fetched, used for timestamping the stored file.

        Returns:
            str: The S3 key under which the extracted data file is saved. This key is used for subsequent data transfer tasks.

        """
        # Setting up map_index to market code and ip(so we can observe from web UI which mapped task is running )
        context = get_current_context()
        custom_map_index = f"{market_code}:{market_ip}"
        context["my_custom_map_index"] = custom_map_index

        # query = read_sql_file(sql_file)
        df_cheques = _execute_query_to_df_with_pyodbc(
            QUERY_CHEQUES_STRING,
            market_ip,
            db,
            params=(
                data_interval_end.subtract(days=1).format("YYYYMMDD"),
                DATE_RANGE,
                shop_index,
            ),
        )

        if df_cheques.empty:
            raise AirflowSkipException("Cheques data is empty!")

        filename = f"Market{shop_index}_cheques.csv"
        file_s3_key = save_df_to_s3(
            df=df_cheques,
            aws_conn_id=S3_CONN_ID,
            bucket_name=BUCKET_NAME,
            report_name=S3_FOLDER,
            filename=filename,
            data_interval_end=data_interval_end,
        )

        return file_s3_key

    @task(
        map_index_template="{{ my_custom_map_index }}",
    )
    def from_s3_to_ftp(s3_key: str, market_code: str, shop_index: str):
        """Transfering files from S3 to SMB using FTP Protocol"""

        # Setting up map_index to market code (so we can observe from web UI which mapped task is running )
        context = get_current_context()
        context["my_custom_map_index"] = market_code

        ftp_path = f"{FTP_FOLDER}/Market{shop_index}_cheques.csv"  # why not use the same filename as in S3(like Ф02.csv),well because S3ToFTPOperator doesn't support latin filenames

        """
        The reason I am executing S3ToFTPOperator  inside of a custom task is because of this bug: 
            https://airflow.apache.org/docs/apache-airflow/stable/authoring-and-scheduling/dynamic-task-mapping.html#value-references-in-a-task-group-function
        It is just that i cannot format values from task_group parameters like f'Market_{market_ip}'  without putting operator inside of a custom task and passing task group
        parameter to our task parameter
        """
        s3_to_ftp_task = S3ToFTPOperator(
            task_id="s3_to_ftp_task",
            ftp_path=ftp_path,
            s3_bucket=BUCKET_NAME,
            s3_key=s3_key,
            ftp_conn_id=FTP_CONN_ID,
            aws_conn_id=S3_CONN_ID,
        )

        s3_to_ftp_task.execute(context=context)

        return ftp_path

    @task(map_index_template="{{ my_custom_map_index }}", max_active_tis_per_dag=1)
    def bulk_upsert(
        ftp_path: str,
        market_code: str,
        shop_index: int,
        data_interval_end: pendulum.DateTime,
    ):
        """BULK Inserting from SMB to DataWarehouse"""

        print("ShopINDEX:")
        print(shop_index)

        # Setting up map_index to market code (so we can observe from web UI which mapped task is running )
        context = get_current_context()
        context["my_custom_map_index"] = market_code

        ## Replacing path separators from /(Linux) to \(Windows)
        ftp_path = ftp_path.replace("/", "\\")

        hook = MsSqlHook(mssql_conn_id=PROD_DWH_CONN_ID)

        data_interval_end = data_interval_end.subtract(days=1)
        query = f"""
            DELETE FROM {SCHEMA_NAME}.{TABLE_NAME} WHERE [Date]
                BETWEEN  DATEADD(DAY,-{DATE_RANGE},'{data_interval_end.to_date_string() }') AND '{data_interval_end.to_date_string()}' 
                    AND ShopIndex in ({shop_index});
         
            BULK INSERT {SCHEMA_NAME}.{TABLE_NAME}
                FROM '\\\\{FTP_DNS}\\{ftp_path}'
            WITH (
                FIRSTROW = 2,
                FIELDTERMINATOR = ',',
                ROWTERMINATOR = '0x0a',
                CODEPAGE = '65001'
            );
        """
        print("Executing query: \n", query)

        hook.run(query)

    @task(
        map_index_template="{{ my_custom_map_index }}",
    )
    def remove_smb_file(ftp_path: str, market_code: str):

        # Setting up map_index to market code (so we can observe from web UI which mapped task is running )
        context = get_current_context()
        context["my_custom_map_index"] = market_code

        ftp_hook = FTPHook(ftp_conn_id="smb_ftp")
        ftp_hook.delete_file(ftp_path)

    extract_s3_key = extract_data_from_markets(
        market_ip, market_code, uks_db, shop_index
    )

    extract_ftp_path = from_s3_to_ftp(extract_s3_key, market_code, shop_index)

    @task(map_index_template="{{ my_custom_map_index }}")
    def upsert_to_clickhouse(
        s3_key: str,
        market_code: str,
        shop_index: str,
        data_interval_end: pendulum.DateTime,
    ):

        context = get_current_context()
        context["my_custom_map_index"] = market_code

        hook = ClickHouseHook(clickhouse_conn_id="clickhouse_dwh")

        data_interval_end = data_interval_end.subtract(days=1)
        delete_query = f"""DELETE FROM uks.cheques where shop_index = {shop_index} 
                AND date between CAST(DATEADD(DAY,-{DATE_RANGE},'{data_interval_end.to_date_string() }') AS Date) AND CAST('{data_interval_end.to_date_string()}' AS Date) """

        s3_hook = BaseHook.get_connection(conn_id=S3_CONN_ID)
        s3_hook_extra = s3_hook.extra
        s3_endpoint = json.loads(s3_hook_extra)["endpoint_url"]

        insert_query = f"""
                INSERT INTO uks.cheques
                (   
                    id,
                    date,
                    z_report_date,
                    shop_index,
                    cash_number,
                    z_report_number,
                    check_number,
                    product_code,
                    cashier_id,
                    time_id,
                    frontol_id,
                    price_with_VAT,
                    quantity,
                    amount_with_VAT,
                    record_date_time
                )
                SELECT 
                    Id,
                    date,
                    z_report_date,
                    shopindex,
                    cashnumber,
                    zreportnumber,
                    checknumber,
                    articul,
                    cashercode,
                    t.id AS time_id,
                    frontolid,
                    round(toDecimal64(price,4),2) AS price,
                    round(toDecimal64(quantity,4),3) AS quantity,
                    round(toDecimal64(total,4),2) AS amount,
                    recorddatetime
                FROM
                    s3(
                    '{s3_endpoint}/{BUCKET_NAME}/{s3_key}',
                    'csv','Id Nullable(String),date	Nullable(Date),z_report_date Nullable(Date), shopindex	Nullable(Int64), cashnumber	Nullable(Int64), zreportnumber	Nullable(Int64), checknumber	Nullable(Int64), articul	Nullable(String), cashercode	Nullable(Int64), time	Nullable(String), frontolid	Nullable(Int64), price	Nullable(Float64), quantity	Nullable(Float64), total	Nullable(Float64), recorddatetime	Nullable(DateTime64(9))'
                    ) c
                    JOIN dwh.time t
                        ON c.time = t.description;
                """

        print("Executing the following queryies:")
        print(delete_query)
        print(insert_query)
        hook.execute([delete_query, insert_query])

    upsert_to_clickhouse(extract_s3_key, market_code, shop_index)

    (
        extract_s3_key
        >> extract_ftp_path
        >> bulk_upsert(extract_ftp_path, market_code, shop_index)
        >> remove_smb_file(extract_ftp_path, market_code)
    )


@dag(
    default_args={
        "retries": 0,
        "retry_delay": pendulum.duration(minutes=1),
        "owner": "ubaitur5",
        "on_failure_callback": send_error_message_telegram,
    },
    doc_md=doc_md,
    schedule_interval="0 2,4,6,8,10 * * *",
    start_date=pendulum.DateTime(2024, 1, 1),
    catchup=False,
    max_active_runs=1,
    template_searchpath=[
        "/opt/airflow/dags/include/sql_files/"
    ],  # So we can just pass *.sql file name to MsSqlOperator instead of specifying full path
    tags=["uks", "etl"],
)
def fct_cheques():

    extract_list_servers = extract_list_of_market_servers()

    # creating dynamic mapping tasks(for every value from extract_list_servers it will run function extract_load)
    market_cheques = extract_load.expand_kwargs(extract_list_servers)

    dq_column_checks = SQLColumnCheckOperator(
        task_id="dq_column_checks",
        trigger_rule="all_done",
        conn_id=PROD_DWH_CONN_ID,
        table=f"{SCHEMA_NAME}.{TABLE_NAME}",
        partition_clause=f"[Date] BETWEEN DATEADD(DAY,-{DATE_RANGE},'{{{{data_interval_end.subtract(days=1) | ds}}}}') AND '{{{{data_interval_end.subtract(days=1) | ds }}}}'",  # filtering our table to run our checks on
        column_mapping={
            "Total": {  # column name
                "max": {  # check type
                    "less_than": 1500000,
                }
            },
        },
    )

    market_cheques >> dq_column_checks


fct_cheques()
