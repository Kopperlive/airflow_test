WITH source AS (
    SELECT * FROM {{ source('raw_dbt','remains_next_month_raw') }}
)

, renamed AS (

    SELECT
        --dates
        CAST(if(toDate("_Period") >= toDate('2100-01-01'), now(), "_Period") AS Date) AS date

        --ids
        , {{ transform_hex_to_uuid('"СкладКомпании_ID"') }} AS warehouse_id
        , {{ transform_hex_to_uuid('"Контрагент_ID"') }} AS contragent_id
        , {{ transform_hex_to_uuid('"Номенклатура_ID"') }} AS product_id

        --values
        , {{ transform_decimal('"Количество"') }} AS quantity
        , {{ transform_decimal('"СуммаУпр"') }} AS cost_price
        , {{ transform_decimal('"СуммаНДС"') }} AS cost_price_VAT
    FROM source
)

SELECT * FROM renamed
