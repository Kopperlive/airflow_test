WITH source AS (

    SELECT * FROM {{ source('raw_dbt','barcodes_raw') }}

)

, renamed AS (

    SELECT
        toUUID({{ dbt_utils.generate_surrogate_key([
				'measurement_id', 
				'product_id',
                'description'
			])
		}}) AS id
        , {{ transform_binary_to_uuid('"ЕдиницаИзмерения_ID"') }} AS measurement_id
        , {{ transform_binary_to_uuid('"Объект_ID"') }} AS product_id
        , {{ transform_string('"ШтрихКод"') }} AS description
        , {{ transform_binary_to_boolean('"ОсновнойШтрихкод"') }} AS is_main
    FROM source

)


SELECT * FROM renamed
