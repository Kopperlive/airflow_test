SELECT 
    A._IDRRef
    , DATEADD(YEAR, -2000, A.[_Date_Time]) AS _Date_Time
    , DATEADD(YEAR, -2000, A.[ДатаНачалаДействия]) AS ДатаНачалаДействия
    , A._Number
    , A.Автор_ID
    , A.ПодразделениеКомпании_ID
    , A.Комментарий
    , A.Контрагент_ID
    , A.ТипЦен_ID
    , A.ХозОперация_ID
    , A.СкладКомпании_ID
    , B.Номенклатура_ID
    , B.ЕдиницаИзмерения_ID
    , B.Цена
    , B.ЦенаБазовая
FROM [vw_ИзменениеЦен] A WITH (NOLOCK)
    INNER JOIN [vw_ИзменениеЦен_Товары] B WITH (NOLOCK)
        ON A._IDRRef = B.Ссылка
WHERE A._Posted = 0x01 -- Только проведенные документы
    AND A._Marked = 0x00 -- Только не удалённые документы
    -- Ежедневное обновление данных за предыдущий и текущий месяц
    AND A._Date_Time >= '{{get_data_interval_start(data_interval_end).add(years=2000) | ds_nodash}}' AND A._Date_Time < '{{data_interval_end.add(years=2000) | ds_nodash}}'