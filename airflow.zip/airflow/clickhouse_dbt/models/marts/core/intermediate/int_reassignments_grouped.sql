WITH source AS (
    SELECT * FROM {{ref("base_ar_trade__reassignments")}}
),

grouped AS (

    SELECT
        date,
        id,
        author_id,
        division_id,
        warehouse_id,
        price_type_id,
        operation_id,
        reassignment_reason_id,
        incoming_product_id,
        outgoing_product_id,
        incoming_measurement_id,
        outgoing_measurement_id,
        is_downgrading,
        document_number,
        comment,

        SUM(incoming_quantity) AS incoming_quantity,
        SUM(outgoing_quantity) AS outgoing_quantity,
        SUM(incoming_price_with_VAT) AS incoming_price_with_VAT,
        SUM(outgoing_price_with_VAT) AS outgoing_price_with_VAT,
        SUM(incoming_amount_with_VAT) AS incoming_amount_with_VAT,
        SUM(outgoing_amount_with_VAT) AS outgoing_amount_with_VAT,
        SUM(reevaluation_amount_with_VAT) AS reevaluation_amount_with_VAT
    FROM source
    GROUP BY ALL
)

SELECT * FROM grouped