WITH source AS (
    SELECT * FROM {{ref('base_zup__division_measures')}}
)
SELECT * FROM source