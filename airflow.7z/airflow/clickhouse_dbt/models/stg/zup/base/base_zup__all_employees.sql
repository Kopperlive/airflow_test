WITH source AS (

    SELECT * FROM {{ source('raw_dbt','zup_list_all_employees') }}

)

, renamed AS (
    SELECT
        {{transform_string('"Должность"')}} AS job_title
        , {{transform_string('"Сотрудник"')}} AS description
        , {{transform_string('CAST("ИНН" AS String)') }} AS TIN
        , {{transform_string('"Подразделение"') }} AS division
        , CAST("Дата приема" AS Date) AS date_from
        , if(isNull("Дата увольнения"),CAST('2106-02-07' AS Date),CAST("Дата увольнения" AS Date)) AS date_to
        , if(isNull("Дата увольнения"), 1, 0) AS is_working
    FROM source
    WHERE `Сотрудник` IS NOT NULL
)
SELECT * FROM renamed