SELECT 
    DATEADD(YEAR, -2000, [_Period]) AS _Period,
    _RecorderRRef,
    ПодразделениеКомпании_ID,
    Номенклатура_ID,
    Состояние,
    Цена,
    СтавкаНДС_ID,
    БазовыйАссортимент
FROM [vw_ОграничениеАссортиментаПодразделения] WITH (NOLOCK)
WHERE _Active = 0x01 -- Only active records
    -- Daily update for previous and current month
    AND _Period >= '{{get_data_interval_start(data_interval_end).add(years=2000) | ds_nodash}}' 
    AND _Period < '{{data_interval_end.add(years=2000) | ds_nodash}}'