import pendulum
from airflow.decorators import dag
from airflow.operators.bash import BashOperator
from common_utils.etl_tasks import create_or_replace_table, dbt_build
from common_utils.telegram_utils import send_error_message_telegram
from custom_operators.s3tosql import SqlToS3OperatorImproved

doc_md = ""

# S3 stuff
S3_CONN_ID = "minio_s3"
BUCKET_NAME = "etl-data-files-test"
S3_FOLDER = "dimensions"

AR_TRADE_CONN_ID = "nsp_ar_trade"
DWH_CONN_ID = "clickhouse_dwh"


@dag(
    default_args={
        "owner": "ubaitur5",
        "on_failure_callback": send_error_message_telegram,
    },
    schedule_interval="0 1-11 * * *",
    template_searchpath=["/opt/airflow/dags/include/sql_files/"],
    start_date=pendulum.DateTime(2024, 7, 23),
    doc_md=doc_md,
    tags=["etl", "dimensions"],
    catchup=False,
)
def dim_vat_rates():

    extract_vat_rates_raw = SqlToS3OperatorImproved(
        task_id="extract_vat_rates_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query="""
        SELECT 
            _IDRRef
            , _Marked
            , _Description
            , Ставка 
        FROM vw_СтавкиНДС
        """,
        s3_bucket=BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="vat_rates_raw.parquet",
        replace=True,
        aws_conn_id=S3_CONN_ID,
        file_format="parquet",
        pd_kwargs={"index": False},
    )

    (
        extract_vat_rates_raw
        >> create_or_replace_table(
            conn_id=DWH_CONN_ID,
            table_name="vat_rates_raw",
            s3_bucket=BUCKET_NAME,
            s3_key=extract_vat_rates_raw.output,
        )
        >> dbt_build(indirect_selection="buildable")
    )


dim_vat_rates()
