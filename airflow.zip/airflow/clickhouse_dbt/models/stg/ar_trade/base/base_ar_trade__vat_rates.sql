WITH source AS (

    SELECT * FROM {{ source('raw_dbt','vat_rates_raw') }}

)

, renamed AS (

    SELECT
        {{ transform_binary_to_uuid('_IDRRef') }} AS id

        , {{ transform_string('_Description') }} AS description
        , {{ transform_decimal('"Ставка"') }} AS vat_rate

        , {{ transform_binary_to_boolean('_Marked') }} AS is_deleted

    FROM source

)

SELECT * FROM renamed
