SELECT
    DATEADD(YEAR,-2000,_Date_Time) AS _Date_Time
    , _IDRRef
    , Автор_ID
    , _Number
    , Комментарий
    , ПодразделениеКомпании_ID
    , Контрагент_ID
    , ДоговорВзаиморасчетов_ID
    , СкладКомпании_ID
    , ТипЦен_ID
    , ХозОперация_ID
    , Номенклатура_ID
    , ЕдиницаИзмерения_ID
    , СтавкаНДС_ID
    , ПричинаВозврата_ID
    , Партия_ID
    , Количество
    , Сумма
    , СуммаНДС
from vw_ВозвратПоставщику r WITH(NOLOCK)
    INNER JOIN vw_ВозвратПоставщику_Товары rt WITH(NOLOCK)
        ON rt.Ссылка = r._IDRRef
           AND r._Date_Time >= '{{get_data_interval_start(data_interval_end).add(years=2000) | ds_nodash}}' AND r._Date_Time<'{{data_interval_end.add(years=2000) | ds_nodash}}'
           AND r._Marked = 0x00
           AND r._Posted = 0x01
UNION ALL
SELECT 
    DATEADD(YEAR,-2000,_Date_Time) AS _Date_Time
    , _IDRRef
    , Автор_ID
    , _Number
    , Комментарий
    , ПодразделениеКомпании_ID
    , Контрагент_ID
    , ДоговорВзаиморасчетов_ID
    , СкладКомпании_ID
    , ТипЦен_ID
    , ХозОперация_ID
    , Номенклатура_ID
    , ЕдиницаИзмерения_ID
    , СтавкаНДС_ID
    , NULL
    , NULL
    , rzt.Количество
    , rzt.СуммаВсего
    , rzt.СуммаНДС
FROM vw_РеализацияТоваров rz WITH(NOLOCK)
    JOIN vw_РеализацияТоваров_Товары rzt WITH(NOLOCK)
        ON rz._Marked = 0x00
           AND rz._Date_Time >= '{{get_data_interval_start(data_interval_end).add(years=2000) | ds_nodash}}' AND rz._Date_Time<'{{data_interval_end.add(years=2000) | ds_nodash}}'
           and rz._Posted = 0x01
           AND rz.ХозОперация_ID = 0xA2B59E27A5FF571144D071F1993F5173 -- Возврат поставщику (отгрузкой)
           AND rzt.Ссылка = rz._IDRRef