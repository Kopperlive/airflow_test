import pandas as pd
import pendulum
from airflow.decorators import task, task_group
from airflow.providers.ftp.operators.ftp import FTPFileTransmitOperator, FTPOperation
from airflow_clickhouse_plugin.operators.clickhouse import ClickHouseOperator
from common_utils.report.s3_utils import save_df_to_s3


def create_or_replace_table(
    conn_id: str, table_name: str, s3_bucket: str, s3_key: str, columns_info=""
):
    return ClickHouseOperator(
        task_id=f"create_or_replace_table_{table_name}",
        clickhouse_conn_id=conn_id,
        database="raw_dbt",
        sql=f"""
        CREATE OR REPLACE TABLE {table_name}{columns_info}
            ORDER BY tuple() AS SELECT * FROM s3('{{{{conn.minio_s3.extra_dejson.endpoint_url }}}}/{s3_bucket}/{s3_key}') 
            SETTINGS format_csv_delimiter = '|', format_csv_allow_double_quotes = 0, max_insert_threads=8;
        """,
    )


@task_group
def dbt_build(
    models: list[str] = None, indirect_selection: str = "eager", run_condition=None
):
    """
    task group with two tasks: dbt_run and dbt_test
    Args:
        models (list[str], optional):  Defaults to None.
        indirect_selection (str, optional): Defaults to "eager".
        run_condition (callable, optional): Custom lambda function for task.run_if.
                                          Default checks if externally triggered.
    """

    def format_model_selection(models: list[str]) -> str:
        """Convert a list of models into a dbt-compatible selection string."""
        if not models:
            return "+{{ dag.dag_id }}"  # Fallback to DAG ID if no models are provided
        return " ".join(
            f"+{model}" for model in models
        )  # Format as +model1,+model2,...

    # Use provided run_condition or default to external trigger check
    if run_condition is None:
        run_condition = lambda context: context["dag_run"].external_trigger

    @task.run_if(run_condition)
    @task.bash
    def dbt_run():
        selection = format_model_selection(models=models)
        return f"dbt build --select {selection} --exclude test_type:data"

    @task.bash
    def dbt_test():
        selection = format_model_selection(models=models)
        return (
            f"dbt test --select {selection} --indirect-selection {indirect_selection}"
        )

    dbt_run() >> dbt_test()


@task_group
def ftp_transfer_excel_to_clickhouse(
    ftp_conn_id: str,
    ftp_path: str,
    s3_filename: str,
    aws_conn_id: str,
    s3_bucket_name: str,
    s3_folder: str,
    table_name: str,
    date_columns: list[str] = [],
):
    """
    Reads excel from ftp ,converts to csv, uploads to s3, then to clickhouse
    """

    TMP_FILEPATH = f"/tmp/{s3_filename}"

    ftp_zup_to_local = FTPFileTransmitOperator(
        task_id="ftp_zup_to_local",
        ftp_conn_id=ftp_conn_id,
        local_filepath=TMP_FILEPATH,
        remote_filepath=ftp_path,
        operation=FTPOperation.GET,
        create_intermediate_dirs=True,
    )

    @task
    def upload_zup_to_s3(data_interval_end: pendulum.DateTime):
        df = pd.read_excel(TMP_FILEPATH)

        for i in date_columns:
            df[i] = pd.to_datetime(df[i])

        file_s3_key = save_df_to_s3(
            df=df,
            aws_conn_id=aws_conn_id,
            bucket_name=s3_bucket_name,
            report_name=s3_folder,
            filename=s3_filename,
            data_interval_end=data_interval_end,
        )

        return file_s3_key

    zup_to_s3 = upload_zup_to_s3()
    create_or_replace_table_ftp = ClickHouseOperator(
        task_id=f"create_or_replace_table_ftp",
        clickhouse_conn_id="clickhouse_dwh",
        database="raw_dbt",
        sql=f"""
        CREATE OR REPLACE TABLE {table_name}
            ORDER BY tuple() AS SELECT * FROM s3('{{{{conn.minio_s3.extra_dejson.endpoint_url }}}}/{s3_bucket_name}/{zup_to_s3}') 
        """,
    )

    ftp_zup_to_local >> zup_to_s3 >> create_or_replace_table_ftp
