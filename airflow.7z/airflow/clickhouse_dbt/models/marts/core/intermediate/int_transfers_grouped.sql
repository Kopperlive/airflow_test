WITH source AS (

    SELECT * FROM {{ ref("base_ar_trade__transfers") }}

)

, grouped AS (

    SELECT
        date

        , id
        , document_number
        , author_id
        , comment

        , division_id

        , sender_type
        , sender_id
        , receiver_type
        , receiver_id
        , shipment_id

        , product_id
        , measurement_id

        , operation_id
        , price_type_id
        , vat_rate_id

        , is_closed_customer_order
        , is_sent_to_buh

        , SUM(quantity) AS quantity
        , SUM(cost_price_with_VAT) AS cost_price_with_VAT
        , SUM(amount_with_VAT) AS amount_with_VAT
        , SUM(amount_VAT) AS amount_VAT
    FROM source
    GROUP BY ALL
)

SELECT * FROM grouped
