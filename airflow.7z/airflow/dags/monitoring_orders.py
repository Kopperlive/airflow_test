import numpy as np
import pandas as pd
import pendulum
import pyodbc
from airflow.decorators import dag, task, task_group
from airflow.models import Variable
from airflow.models.taskinstance import TaskInstance
from airflow.operators.python import get_current_context
from airflow.providers.microsoft.mssql.hooks.mssql import MsSqlHook
from common_utils.report.s3_utils import read_df_from_s3, save_df_to_s3
from common_utils.sql_utils import read_sql_file
from common_utils.telegram_utils import send_error_message_telegram
from custom_operators.s3tosql import SqlToS3OperatorImproved

doc_md = """
"""


UID = Variable.get("Reader")
PWD = Variable.get("Reader_password")

# S3 stuff
S3_CONN_ID = "minio_s3"
BUCKET_NAME = "monitoring"
S3_FOLDER = "monitoring_orders"

AR_TRADE_CONN_ID = "nsp_ar_trade"
DWH_CONN_ID = "prod_dwh"

CB_MARKETS_CONN_ID = "nsp_markets_db"
CB_DNS = "NSP-MARKETS-DB"


QUERY_FILE_MARKETS = "monitoring_orders_market.sql"
QUERY_MARKETS = read_sql_file(QUERY_FILE_MARKETS)

DATE_RANGE = 30


def connect(server: str, db: str):
    MS_CONN_STR = f"DRIVER=ODBC Driver 17 for SQL Server;SERVER={server};PORT=1433;UID={UID};PWD={PWD};Database={db}"
    conn = pyodbc.connect(MS_CONN_STR)
    return conn


@task
def get_list_of_markets():

    hook = MsSqlHook(mssql_conn_id=CB_MARKETS_CONN_ID)
    conn = hook.get_conn()

    # Selecting databases where id>4(databases that have id less than 4 are system databases(master,temp,etc.))
    query = """
    SELECT 
        NAME AS db
        FROM   sys.databases
    WHERE  database_id > 4 AND state_desc = 'ONLINE'  AND NAME LIKE 'AR%'
    """

    df = pd.read_sql(query, conn)
    dict = df.to_dict("records")
    return dict


@task_group
def etl(db: str):

    @task(
        map_index_template="{{ my_custom_map_index }}",
    )
    def extract(db: str, data_interval_end: pendulum.DateTime, ti: TaskInstance):

        context = get_current_context()
        context["my_custom_map_index"] = db

        conn = connect(CB_DNS, db)

        query = QUERY_MARKETS.format(
            database=db,
            data_interval_start=data_interval_end.subtract(days=DATE_RANGE)
            .add(years=2000)
            .format("YYYYMMDD"),
            data_interval_end=data_interval_end.add(days=1, years=2000).format(
                "YYYYMMDD"
            ),
        )

        df = pd.read_sql(query, conn)
        print(df)

        filename = f"{db}.csv"

        file_s3_key = save_df_to_s3(
            df=df,
            aws_conn_id=S3_CONN_ID,
            bucket_name=BUCKET_NAME,
            report_name=S3_FOLDER,
            filename=filename,
            time_granularity="hourly",
            data_interval_end=data_interval_end,
        )

        return file_s3_key

    @task(
        map_index_template="{{ my_custom_map_index }}",
    )
    def transform(
        db: str, s3_key: str, ti: TaskInstance, data_interval_end: pendulum.DateTime
    ):

        context = get_current_context()
        context["my_custom_map_index"] = db

        df_market = read_df_from_s3(
            aws_conn_id=S3_CONN_ID,
            bucket_name=BUCKET_NAME,
            file_s3_key=s3_key,
        )

        ar_trade_s3_key = ti.xcom_pull(
            task_ids="extract_ar_trade_orders_raw",
            key="return_value",
        )

        df_ar_trade = read_df_from_s3(
            aws_conn_id=S3_CONN_ID,
            bucket_name=BUCKET_NAME,
            file_s3_key=ar_trade_s3_key,
        )

        unique_warehouses = df_market["Warehouse_ID"].unique().tolist()
        df_ar_trade = df_ar_trade[df_ar_trade["Warehouse_ID"].isin(unique_warehouses)]
        print(df_ar_trade)

        df_market_warehouse_count = (
            df_market.groupby("Warehouse_ID")
            .size()
            .reset_index(name="market_warehouse_count")
        )
        df_ar_trade_warehouse_count = (
            df_ar_trade.groupby("Warehouse_ID")
            .size()
            .reset_index(name="ar_trade_warehouse_count")
        )

        merged_warehouse_counts = pd.merge(
            df_market_warehouse_count, df_ar_trade_warehouse_count, on="Warehouse_ID"
        )

        ## Removing orders that were sent to wrong local market, for instance, order for market 3 could be wronly sent to market 5
        merged_warehouse_counts["ratio"] = (
            merged_warehouse_counts["ar_trade_warehouse_count"]
            / merged_warehouse_counts["market_warehouse_count"]
        )
        warehouse_ids_to_remove = (
            merged_warehouse_counts[merged_warehouse_counts["ratio"] > 100][
                "Warehouse_ID"
            ]
            .unique()
            .tolist()
        )

        df_ar_trade = df_ar_trade[
            ~df_ar_trade["Warehouse_ID"].isin(warehouse_ids_to_remove)
        ]

        df_market = df_market[~df_market["Warehouse_ID"].isin(warehouse_ids_to_remove)]

        df_merged = df_ar_trade.merge(
            df_market,
            how="outer",
            on=[
                "Warehouse_ID",
                "_Number",
                "_Date_Time",
                "Author",
                "Amount",
                # "Supplier_ID",
            ],
            suffixes=("_ar_trade", "_market"),
        )

        df_merged["status"] = np.where(
            df_merged["Supplier_ID_ar_trade"].isnull(),
            "Не дошёл до ЦБ",
            np.where(
                df_merged["Supplier_ID_market"].isnull(),  # Second condition
                "Не дошёл до маркета",
                "Дошёл",
            ),
        )

        df_merged["Supplier_ID"] = df_merged.Supplier_ID_ar_trade.combine_first(
            df_merged.Supplier_ID_market
        )

        df_merged.drop(
            columns=[
                "Supplier_ID_ar_trade",
                "Supplier_ID_market",
            ],
            inplace=True,
        )

        filename = f"{db}_transformed.csv"

        file_s3_key = save_df_to_s3(
            df=df_merged,
            aws_conn_id=S3_CONN_ID,
            bucket_name=BUCKET_NAME,
            report_name=S3_FOLDER,
            filename=filename,
            time_granularity="hourly",
            data_interval_end=data_interval_end,
        )

        return file_s3_key

    @task(map_index_template="{{ my_custom_map_index }}", max_active_tis_per_dag=1)
    def get_delivered_datetime(
        db: str, s3_key: str, data_interval_end: pendulum.DateTime, ti: TaskInstance
    ):
        context = get_current_context()
        context["my_custom_map_index"] = db

        df_market = read_df_from_s3(
            aws_conn_id=S3_CONN_ID,
            bucket_name=BUCKET_NAME,
            file_s3_key=s3_key,
        )

        dwh_orders_s3_key = ti.xcom_pull(
            task_ids="extract_dwh_orders_raw", key="return_value"
        )

        df_dwh = read_df_from_s3(
            aws_conn_id=S3_CONN_ID,
            bucket_name=BUCKET_NAME,
            file_s3_key=dwh_orders_s3_key,
        )

        df_dwh.datetime = df_dwh.datetime.astype(str)
        df_market["_Date_Time"] = df_market["_Date_Time"].astype(str)

        df_merged = df_market.merge(
            df_dwh,
            how="left",
            left_on=[
                "Warehouse_ID",
                "_Number",
                "_Date_Time",
                "Author",
                "Amount",
                "Supplier_ID",
            ],
            right_on=[
                "warehouseIdRef",
                "order_number",
                "datetime",
                "author",
                "amount",
                "supplierIdRef",
            ],
            suffixes=("_market", "_dwh"),
        )

        # if (status before was 'not delivered' and now 'delivered') or (new row and it was delivered to to destination) set status_delivered_datetime to current time
        df_merged["status_delivered_datetime_new_rows"] = np.where(
            (
                (
                    df_merged["status_dwh"].isin(
                        ["Не дошёл до ЦБ", "Не дошёл до маркета"]
                    )
                )
                & (df_merged["status_market"] == "Дошёл")
            )
            | (
                (df_merged["status_delivered_datetime"].isnull())
                & (df_merged["status_market"] == "Дошёл")
            ),
            pendulum.now(tz="Asia/Bishkek").to_datetime_string(),
            df_merged["status_delivered_datetime"],
        )

        print(df_merged["status_delivered_datetime_new_rows"].unique().tolist())

        df_merged = df_merged[
            [
                "_Date_Time",
                "_Number",
                "Warehouse_ID",
                "status_market",
                "Amount",
                "Author",
                "Supplier_ID",
                "status_delivered_datetime_new_rows",
            ]
        ]

        filename = f"{db}_transformed_with_delivered_date.csv"

        file_s3_key = save_df_to_s3(
            df=df_merged,
            aws_conn_id=S3_CONN_ID,
            bucket_name=BUCKET_NAME,
            report_name=S3_FOLDER,
            filename=filename,
            time_granularity="hourly",
            data_interval_end=data_interval_end,
        )

        return file_s3_key

    @task(map_index_template="{{ my_custom_map_index }}", max_active_tis_per_dag=1)
    def upsert(db: str, s3_key: str, data_interval_end: pendulum.DateTime):

        context = get_current_context()
        context["my_custom_map_index"] = db
        conn = connect("SRV-TEST-DWH", "DWH")

        df = read_df_from_s3(
            aws_conn_id=S3_CONN_ID,
            bucket_name=BUCKET_NAME,
            file_s3_key=s3_key,
        )

        cursor = conn.cursor()

        warehouses = df["Warehouse_ID"].unique().tolist()
        print(warehouses)

        delete_query = f"""
        DELETE FROM FactMonitoringOrders 
            WHERE Date BETWEEN '{data_interval_end.subtract(days=DATE_RANGE).to_date_string()}' AND '{data_interval_end.add(days=1).to_date_string()}'
                AND warehouseIDRef in ({str(warehouses)[1:-1]})
        """
        print("Executing query:\n", delete_query)
        cursor.execute(delete_query)

        df = df.replace(np.nan, None)
        named_tuples_list = list(df.itertuples(index=False))

        print("Starting INSERT statements")

        cursor.fast_executemany = True

        print(named_tuples_list)
        cursor.executemany(
            """
        INSERT INTO FactMonitoringOrders(
            datetime,
            order_number,
            warehouseIdRef,
            status,
            amount,
            author,
            supplierIDRef,
            status_delivered_datetime
            ) 
        VALUES (?,?,?,?,?,?,?,?)""",
            named_tuples_list,
        )

        cursor.commit()

    s3_key = extract(db)
    transformed_s3_key = transform(db, s3_key)
    transformed_with_delivered_date_s3_key = get_delivered_datetime(
        db, transformed_s3_key
    )

    upsert(db, transformed_with_delivered_date_s3_key)


@dag(
    schedule_interval="@hourly",
    template_searchpath=["/opt/airflow/dags/include/sql_files/"],
    default_args={
        "owner": "ubaitur5",
        "priority_weight": -5,
        # "on_failure_callback": send_error_message_telegram,
    },
    start_date=pendulum.DateTime(2024, 7, 23),
    doc_md=doc_md,
    tags=["monitoring"],
    catchup=False,
)
def monitoring_orders():

    extract_dwh_orders_raw = SqlToS3OperatorImproved(
        task_id="extract_dwh_orders_raw",
        sql_conn_id=DWH_CONN_ID,
        query=f"""
        SELECT 
            datetime,
            order_number,
            warehouseIdRef,
            author,
            amount,
            supplierIdRef,
            status,
            status_delivered_datetime
        FROM FactMonitoringOrders where Date between '{{{{data_interval_end.subtract(days={DATE_RANGE}) | ds_nodash}}}}' AND '{{{{data_interval_end.add(days=1) | ds_nodash}}}}'
            --AND status!='Дошёл'
        """,
        s3_bucket=BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="dwh_orders_raw.csv",
        replace=True,
        aws_conn_id=S3_CONN_ID,
        time_granularity="hourly",
        file_format="csv",
        pd_kwargs={"index": False},  # pandas parameters to pass into .to_parquet()
    )

    extract_ar_trade_orders_raw = SqlToS3OperatorImproved(
        task_id="extract_ar_trade_orders_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query=QUERY_MARKETS.format(
            database="AR_TRADE",
            data_interval_start=f"{{{{data_interval_end.subtract(days={DATE_RANGE}).add(years=2000) | ds_nodash}}}}",
            data_interval_end="{{data_interval_end.add(years=2000,days=1)|ds_nodash}}",
        ),
        s3_bucket=BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="ar_trade_orders_raw.csv",
        replace=True,
        aws_conn_id=S3_CONN_ID,
        time_granularity="hourly",
        file_format="csv",
        pd_kwargs={"index": False},  # pandas parameters to pass into .to_parquet()
    )

    list_of_markets = get_list_of_markets()

    [extract_ar_trade_orders_raw, extract_dwh_orders_raw] >> etl.expand_kwargs(
        list_of_markets
    )


monitoring_orders()
