WITH source AS (

    SELECT * FROM {{ ref("base_ar_trade__sales") }}

)

, grouped AS (

    SELECT
        date
        , division_id
        , warehouse_id
        , contragent_id
        , product_id

        , operation_id
        , contragent_settlement_id
        , buyer_id
        , supply_type_id
        , vat_rate_id

        , is_cashless_payment

        , SUM(quantity) AS quantity
        , SUM(amount) AS amount
        , SUM(amount_VAT) AS amount_VAT
        , SUM(amount_discount) AS amount_discount
        , SUM(cost_price) AS cost_price
        , SUM(cost_price_VAT) AS cost_price_VAT
    FROM source
    GROUP BY ALL
)

SELECT * FROM grouped
