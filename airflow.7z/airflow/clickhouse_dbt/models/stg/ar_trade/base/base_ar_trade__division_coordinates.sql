WITH source AS (
    SELECT * FROM {{ ref('division_coordinates_raw') }}
)

, renamed AS (

    SELECT

        {{ transform_string('code') }} AS code
        , CAST("X" AS Decimal(11, 9)) AS x
        , CAST("Y" AS Decimal(11, 9)) AS y
    FROM source

)


SELECT * FROM renamed
