WITH movements_and_next_month_combined AS (
    SELECT *
    FROM {{ ref('int_remains_movements_and_next_month_combined') }}
)
, calendar AS (
    SELECT *
    FROM {{ source('raw_dbt','remains_calendar') }}
)

, distinct_dimensions AS (
    SELECT DISTINCT
        warehouse_id
        , contragent_id
        , product_id
    FROM movements_and_next_month_combined
    WHERE date >= (SELECT MIN(date) FROM calendar)
)


, final AS (
    SELECT *
    FROM distinct_dimensions
    CROSS JOIN calendar
)

SELECT * FROM final
