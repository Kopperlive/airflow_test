WITH source AS (
    SELECT * FROM {{ ref('plan_2025') }}
)

, renamed AS (

    SELECT
        {{transform_string('division_name')}} AS division_name
        , {{transform_string('month')}} AS month
        , {{transform_decimal('amount')}} AS amount
        , {{transform_decimal('quantity')}} AS quantity
        , {{transform_decimal('cheques_quantity')}} AS cheques_quantity
    FROM source

)


SELECT * FROM renamed
