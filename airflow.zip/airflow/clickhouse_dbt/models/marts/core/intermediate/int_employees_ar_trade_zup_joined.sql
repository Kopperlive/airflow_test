WITH ar_trade AS (
    SELECT * FROM {{ref('base_ar_trade__employees')}}
)
, zup AS (
    SELECT * FROM {{ref('base_zup__employees')}}
)
, final AS (
    SELECT 
        ar_trade.id AS id
        , ar_trade.parent_id AS parent_id

        , ar_trade.division_id AS division_id
        , ar_trade.code AS code
        , ar_trade.description AS description
        , {{transform_string('zup.description')}} AS description_zup
        , {{transform_string('zup.division')}} AS division_zup
        , ar_trade.TIN AS TIN
        , {{transform_string('zup.job_title')}} AS job_title
        , {{transform_decimal('zup.salary_amount')}} AS salary_amount
        , {{transform_string('zup.work_schedule')}} AS work_schedule
        , {{transform_string('zup.phone_number')}} AS phone_number

        , ar_trade.is_deleted AS is_deleted
        , ar_trade.is_item AS is_item
    FROM ar_trade
        LEFT JOIN zup ON zup.TIN=ar_trade.TIN
            AND zup.TIN!='Не заполнено'
)

SELECT * FROM final