{% macro transform_binary_to_boolean(column_name) -%}
    CAST(COALESCE(hex({{ column_name }}),'2') AS UInt8)
{%- endmacro %}