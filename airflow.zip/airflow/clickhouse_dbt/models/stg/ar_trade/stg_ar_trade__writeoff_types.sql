WITH writeoff_types AS (
    SELECT * FROM {{ ref('base_ar_trade__writeoff_types') }}
)

, writeoff_supertypes AS (
    SELECT * FROM {{ ref('base_ar_trade__writeoff_supertypes') }}
)

, relationships AS (
    SELECT * FROM {{ ref('base_ar_trade__writeoff_types_and_supertypes_relationship') }}
)

, final AS (
    SELECT
        writeoff_types.id AS id
        , writeoff_types.parent_id AS parent_id
        , writeoff_types.code AS code
        , writeoff_types.description AS description
        , {{ transform_string('writeoff_supertypes.description') }} AS type
        , writeoff_types.is_deleted AS is_deleted
        , writeoff_types.is_item AS is_item
    FROM writeoff_types
    LEFT JOIN relationships
        ON writeoff_types.id = relationships.writeoff_type_id
    LEFT JOIN writeoff_supertypes
        ON relationships.writeoff_supertype_id = writeoff_supertypes.id

)

SELECT * FROM final
