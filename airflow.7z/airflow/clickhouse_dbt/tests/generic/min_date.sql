{% test min_date(model) %}

with validation as (

    select
        min(date) as min_date

    from {{ model }}

),

validation_errors as (

    select
        min_date

    from validation
    -- if this is true, then the min date is after '2023-08-01'
    where min_date > '2023-08-01'

)

select *
from validation_errors

{% endtest %}