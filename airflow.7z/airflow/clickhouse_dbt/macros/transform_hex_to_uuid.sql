{% macro transform_hex_to_uuid(column_name) -%}
    CAST(COALESCE({{ column_name }},'00000000-0000-0000-0000-000000000000') AS UUID)
{%- endmacro %}