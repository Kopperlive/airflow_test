INSERT INTO remains
    (date,
    division_id,
    warehouse_id,
    contragent_id,
    product_id,
    quantity,
    cost_price,
    cost_price_VAT
    )
SELECT 
    date,
    w.division_id,
    warehouse_id,
    contragent_id,
    product_id,
    round(toDecimal64(quantity,4),3) AS quantity,
    round(toDecimal64(cost_price,4),2) AS cost_price,
    round(toDecimal64(cost_price_VAT,4),2) AS cost_price_VAT
FROM  s3(
    '{{conn.minio_s3.extra_dejson.endpoint_url }}/{{ti.xcom_pull(task_ids='transform_remains_for_every_day',key='s3_key')}}',
    'parquet'
    )remains
JOIN warehouse w ON w.is_current='Текущий' AND w.id=remains.warehouse_id
