WITH source AS (

    SELECT * FROM {{ source('raw_dbt','transfers_raw') }}

)

, renamed AS (

    SELECT
        CAST("_Date_Time" AS Date) AS date

        , {{ transform_hex_to_uuid('"_IDRRef"') }} AS id
        , {{ transform_string('"_Number"') }} AS document_number
        , {{ transform_string('"Комментарий"') }} AS comment
        , CAST({{ transform_hex_to_uuid('"Автор_ID"') }} AS LowCardinality (UUID)) AS author_id

        , CAST({{ transform_hex_to_uuid('"ПодразделениеКомпании_ID"') }} AS LowCardinality (UUID)) AS division_id

        , multiIf("СкладКомпании_НОМЕР" = 128, 1, "СкладКомпании_НОМЕР" = 136, 2, 0) AS sender_type
        , CAST({{ transform_hex_to_uuid('"СкладКомпании_ID"') }} AS LowCardinality (UUID)) AS sender_id
        , multiIf("СкладПолучатель_НОМЕР" = 128, 1, "СкладПолучатель_НОМЕР" = 136, 2, 0) AS receiver_type
        , CAST({{ transform_hex_to_uuid('"СкладПолучатель_ID"') }} AS LowCardinality (UUID)) AS receiver_id
        , CAST(COALESCE(toUUIDOrNull("ИДДокументаОтгрузки"), CAST('00000000-0000-0000-0000-000000000000' AS UUID)) AS UUID) AS shipment_id

        , {{ transform_hex_to_uuid('"Номенклатура_ID"') }} AS product_id
        , {{ transform_hex_to_uuid('"ЕдиницаИзмерения_ID"') }} AS measurement_id

        , CAST({{ transform_hex_to_uuid('"ХозОперация_ID"') }} AS LowCardinality (UUID)) AS operation_id
        , CAST({{ transform_hex_to_uuid('"ТипЦен_ID"') }} AS LowCardinality (UUID)) AS price_type_id
        , CAST({{ transform_hex_to_uuid('"СтавкаНДС_ID"') }} AS LowCardinality (UUID)) AS vat_rate_id

        , {{ transform_binary_to_boolean('"ЗакрытиеЗаказовПокупателей"') }} AS is_closed_customer_order
        , {{ transform_binary_to_boolean('"РегламентированныйУчет"') }} AS is_sent_to_buh

        , {{ transform_decimal('"Количество"') }} AS quantity
        , {{ transform_decimal('"СуммаРозничная"') }} AS amount_with_VAT
        , {{ transform_decimal('"Сумма"') }} AS cost_price_with_VAT
        , {{ transform_decimal('"СуммаНДС"') }} AS amount_VAT
    FROM source

)

SELECT * FROM renamed
