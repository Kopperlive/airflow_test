{% snapshot snapshots__dim_employees %}
    select * from {{ ref('int_employees_ar_trade_zup_joined') }}
{% endsnapshot %}