WITH divisions AS (
    SELECT * FROM {{ ref('base_ar_trade__divisions') }}
),

division_formats AS (
    SELECT * FROM {{ ref('base_ar_trade__division_formats') }}
),

division_curators AS (
    SELECT * FROM {{ ref('base_ar_trade__division_curators') }}
),

division_coordinates AS (
    SELECT * FROM {{ ref('base_ar_trade__division_coordinates') }}
),

cities AS (
    SELECT * FROM {{ ref('base_ar_trade__cities') }}
),

regions AS (
    SELECT * FROM {{ ref('base_ar_trade__regions') }}
),

sp_m2 AS (
    SELECT * FROM {{ ref('base_ar_trade__division_sp_m2') }}
),

contact_info AS (
    SELECT * FROM {{ ref('base_ar_trade__contact_info') }}
),

final AS (
    SELECT 
        --  ids
          divisions.id AS id
        , divisions.parent_id AS parent_id
        , divisions.price_type_selling_id AS price_type_selling_id
        , divisions.price_type_buying_id AS price_type_buying_id

        -- codes
        , divisions.code AS code
        , divisions.report_code AS report_code
        , divisions.prefix AS prefix
        , divisions.shop_index AS shop_index

        -- names
        , divisions.description AS description
        
        --other values
        , {{transform_string('cities.description')}} AS city
        , {{transform_string('regions.description')}} AS region
        , divisions.address AS address
        , {{transform_string('division_formats.description')}} AS format
        , {{transform_string('division_curators.description')}} AS curator
        , {{transform_string('division_curators.phone_number')}} AS curator_phone_number
        , {{transform_string('division_curators.email')}} AS curator_email
        , CAST(COALESCE(division_coordinates.x,0) AS Decimal(11,9)) AS geocoord_x
        , CAST(COALESCE(division_coordinates.y,0) AS Decimal(11,9)) AS geocoord_y
        , divisions.area_total AS area_total
        , divisions.area_trade_hall AS area_trade_hall
        , divisions.area_warehouses AS area_warehouses
        , divisions.area_pre_cachier_zone AS area_pre_cachier_zone
        , divisions.area_administrative_part AS area_administrative_part
        , CAST(COALESCE(sp_m2.m2 ,0) AS Decimal(19,2)) AS area_sp
        , {{transform_string('contact_info.contact_value')}} AS email_address
        --booleans
        , divisions.is_deleted AS is_deleted

    FROM divisions 
        LEFT JOIN division_formats ON 
            divisions.format_id=division_formats.id
        LEFT JOIN division_curators ON 
            divisions.curator_id = division_curators.id
        LEFT JOIN division_coordinates ON 
            divisions.code=division_coordinates.code
        LEFT JOIN sp_m2 ON
            divisions.code = sp_m2.code
        LEFT JOIN cities ON
            divisions.city_id=cities.id
        LEFT JOIN regions ON 
            divisions.region_id=regions.id
        LEFT JOIN contact_info ON
            divisions.id = contact_info.object_id AND contact_info.contact_value LIKE '%_@__%.__%' and contact_info.category_desc = 'Адрес электронной почты (рабочий)'
)

SELECT * FROM final
