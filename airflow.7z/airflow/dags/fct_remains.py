from functools import partial

import pendulum
from airflow.decorators import dag, task_group
from airflow.models import Variable
from airflow.operators.bash import BashOperator
from airflow.providers.ssh.operators.ssh import SSHOperator
from airflow_clickhouse_plugin.operators.clickhouse import ClickHouseOperator
from common_utils.etl_tasks import create_or_replace_table, dbt_build
from common_utils.etl_utils import build_bcp_command, get_data_interval_start
from common_utils.telegram_utils import send_error_message_telegram

doc_md = "ETL for **fct_remains** and **fct_movements**"


DWH_CONN_ID = "clickhouse_dwh"

MOVEMENTS_SQL_FILE = "extract_remains_movements.sql"
MOVEMENTS_FILE_NAME = "remains_movements_raw.csv"
MOVEMENTS_TMP_PATH = "/tmp/" + MOVEMENTS_FILE_NAME

REMAINS_NEXT_MONTH_SQL_FILE = "extract_remains_next_month.sql"
REMAINS_NEXT_MONTH_FILE_NAME = "remains_next_month_raw.csv"
REMAINS_NEXT_MONTH_TMP_PATH = "/tmp/" + REMAINS_NEXT_MONTH_SQL_FILE

S3_BUCKET_NAME = "etl-data-files-test"
S3_FOLDER_NAME = "remains"


def get_next_month_start_date(data_interval_end: pendulum.DateTime):
    """
    Return 5999-11-1 if it is current month otherwise start of next month
    """

    current_month = pendulum.today().format("YYYYMM")
    if current_month == data_interval_end.format("YYYYMM"):
        return pendulum.DateTime(
            3999, 11, 1
        )  # in 1C the current month is 5999-11-1 but in sql file we are adding 2000 years

    return (
        data_interval_end.subtract(days=1).add(months=1).start_of("month")
    )  # get start of the next month if it is not current month


@task_group
def extract():

    extract_remains_movements = SSHOperator(
        task_id="extract_remains_movements_on_s3",
        ssh_conn_id="ssh__s3",
        command=partial(
            build_bcp_command,
            sql_file=MOVEMENTS_SQL_FILE,
            destination=MOVEMENTS_TMP_PATH,
        ),
        conn_timeout=20,
        cmd_timeout=1200,  # 20 minutes
    )

    extract_remains_next_month = SSHOperator(
        task_id="extract_remains_next_month_on_s3",
        ssh_conn_id="ssh__s3",
        command=partial(
            build_bcp_command,
            sql_file=REMAINS_NEXT_MONTH_SQL_FILE,
            destination=REMAINS_NEXT_MONTH_TMP_PATH,
        ),
        conn_timeout=20,
        cmd_timeout=1200,  # 20 minutes
    )


@task_group
def load():
    movements_s3_key = (
        "{{data_interval_end.year}}/{{data_interval_end.month}}/{{data_interval_end.day}}/"
        + f"{S3_FOLDER_NAME}/"
        + MOVEMENTS_FILE_NAME
    )

    upload_movements_to_s3 = SSHOperator(
        task_id="upload_movements_to_s3",
        ssh_conn_id="ssh__s3",
        command=f"~/minio-binaries/mc mv {MOVEMENTS_TMP_PATH} local/{S3_BUCKET_NAME}/{movements_s3_key}",
        conn_timeout=20,
        cmd_timeout=180,  # 3 minutes
    )

    movements_columns_info = """ 	
    (
        _Period Nullable(Datetime64)
        , "НомерДокумента" Nullable(String)
        , _RecorderTRef Nullable(String)
        , _RecorderRRef Nullable(String)
        , "СкладКомпании_ID" Nullable(String)
        , "ХозОперация_ID" Nullable(String)
        , "Контрагент_ID" Nullable(String)
        , "Номенклатура_ID" Nullable(String)
        , _RecordKind Nullable(UInt8)
        , "Количество" Nullable(Float64)
        , "СуммаУпр" Nullable(Float64)
        , "СуммаНДС" Nullable(Float64)
    )
    """

    upload_movements_to_s3 >> create_or_replace_table(
        conn_id=DWH_CONN_ID,
        table_name="remains_movements_raw",
        columns_info=movements_columns_info,
        s3_bucket=S3_BUCKET_NAME,
        s3_key=movements_s3_key,
    )

    remains_next_month_s3_key = (
        "{{data_interval_end.year}}/{{data_interval_end.month}}/{{data_interval_end.day}}/"
        + f"{S3_FOLDER_NAME}/"
        + REMAINS_NEXT_MONTH_FILE_NAME
    )

    upload_remains_next_month_to_s3 = SSHOperator(
        task_id="upload_remains_next_month_to_s3",
        ssh_conn_id="ssh__s3",
        command=f"~/minio-binaries/mc mv {REMAINS_NEXT_MONTH_TMP_PATH} local/{S3_BUCKET_NAME}/{remains_next_month_s3_key}",
        conn_timeout=20,
        cmd_timeout=180,  # 3 minutes
    )

    remains_next_month_columns_info = """ 	
    (
        _Period Nullable(Datetime64)
        , "СкладКомпании_ID" Nullable(String)
        , "Контрагент_ID" Nullable(String)
        , "Номенклатура_ID" Nullable(String)
        , "Количество" Nullable(Float64)
        , "СуммаУпр" Nullable(Float64)
        , "СуммаНДС" Nullable(Float64)
    )
    """

    upload_remains_next_month_to_s3 >> create_or_replace_table(
        conn_id=DWH_CONN_ID,
        table_name="remains_next_month_raw",
        columns_info=remains_next_month_columns_info,
        s3_bucket=S3_BUCKET_NAME,
        s3_key=remains_next_month_s3_key,
    )

    construct_date_range_table = (
        ClickHouseOperator(
            task_id=f"construct_date_range_table",
            clickhouse_conn_id=DWH_CONN_ID,
            database="raw_dbt",
            sql="""
        CREATE OR REPLACE TABLE raw_dbt.remains_calendar
        ORDER BY tuple()
        AS
            WITH 
            toStartOfDay(toDate('{{get_data_interval_start(data_interval_end).add(days=1) | ds}}')) AS start, 
            toStartOfDay(
                date_add(day,1,
                    if(
                        toDate('{{get_next_month_start_date(data_interval_end) | ds_nodash}}')= toDate('21490606'), 
                        toDate('{{data_interval_end | ds_nodash}}'), 
                        toDate('{{get_next_month_start_date(data_interval_end) | ds_nodash}}')
                    )
                )
            ) AS end
            SELECT arrayJoin(arrayMap(x -> toDate(x), range(toUInt32(start), toUInt32(end), 24 * 3600))) AS date;
        """,
        ),
    )


@dag(
    default_args={
        "owner": "ubaitur5",
        "on_failure_callback": send_error_message_telegram,
    },
    schedule_interval="0 1-11 * * *",
    start_date=pendulum.DateTime(2023, 7, 23),
    doc_md=doc_md,
    max_active_runs=1,
    tags=["facts"],
    catchup=False,
    user_defined_macros={
        "get_data_interval_start": get_data_interval_start,
        "get_next_month_start_date": get_next_month_start_date,
    },
)
def fct_remains():

    extract() >> load() >> dbt_build(models=["fct_remains", "fct_movements"])


fct_remains()
