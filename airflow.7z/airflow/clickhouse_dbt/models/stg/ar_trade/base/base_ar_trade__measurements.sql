WITH source AS (

    SELECT * FROM {{ source('raw_dbt','measurements_raw') }}

)

, renamed AS (

    SELECT
        {{ transform_binary_to_uuid('_IDRRef') }} AS id
        , {{ transform_binary_to_uuid('_OwnerID_RRRef') }} AS product_id

        , {{ transform_string('_Code') }} AS code
        , {{ transform_string('_Description') }} AS description

        , {{ transform_binary_to_boolean('_Marked') }} AS is_deleted
    FROM source

)

SELECT * FROM renamed
