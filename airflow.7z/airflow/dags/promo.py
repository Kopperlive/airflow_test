"""
REMINDERS:
1. 1C Report when summing up quantity,amount of sales it first filters out promo based on particular contragent then joins sales table on just division and product columns,
so if in that period another supplier also sold it it will count it as sales of first supplier which is wrong, which way is correct?
Answer is: filter out sales based on particular contragent and when joining them join by date_id,division_id,product_id

2. When counting price_old,price_promo_with_VAT get average after grouping by product
"""

import os

import duckdb
import pendulum
from airflow.decorators import dag, task
from airflow.models.taskinstance import TaskInstance
from airflow_clickhouse_plugin.operators.clickhouse import ClickHouseOperator
from common_utils.telegram_utils import send_error_message_telegram
from custom_operators.s3tosql import SqlToS3OperatorImproved

doc_md = """
# Promo Data ETL Process

This DAG manages the extraction, transformation, and loading (ETL) of promotional data from various sources into a data warehouse. The process is designed to run daily, ensuring that promotional data is updated and consistent across all reporting platforms.

## Process Overview

1. **Extract Raw Data**: Promo data is pulled from a specific source, converted to parquet format, and stored in S3.
2. **Transform Data**: The raw data undergoes a transformation process to structure it for better usability in data warehousing. This includes normalizing descriptions, converting binary fields to hexadecimal, and adjusting date formats.
3. **Load Data**: The transformed data is loaded into a ClickHouse data warehouse. Before loading, old promotional entries that overlap with the new data range are deleted to ensure data accuracy and prevent duplication.
4. **Cleanup**: Temporary files created during the process are removed to free up space and maintain organization.

## Details

- **Schedule**: It runs daily, handling data in a batch mode, which corresponds to the previous day's data.
"""

# S3 stuff
S3_CONN_ID = "minio_s3"
BUCKET_NAME = "etl-data-files"
S3_FOLDER = "promo"

AR_TRADE_CONN_ID = "nsp_ar_trade"
QUERY = "promo.sql"

DUCKDB_FILE = "/tmp/promo.db"

DATE_RANGE = 30


@task
def from_s3_to_duckdb(ti: TaskInstance):
    """
    Retrieves  data from S3 and loads it into DuckDB for further processing. This task pulls multiple
    datasets including the current state of warehouses and additional attributes from different S3 keys set in prior tasks.
    """

    conn = duckdb.connect(DUCKDB_FILE)

    promo_s3_key = ti.xcom_pull(task_ids="extract_promo_raw", key="return_value")

    conn.sql(
        f"CREATE OR REPLACE TABLE promo_raw AS SELECT * FROM read_parquet('s3://{BUCKET_NAME}/{promo_s3_key}')"
    )
    conn.close()


@task
def transform_promo(ti: TaskInstance, data_interval_end: pendulum.DateTime):
    """
    Transforms raw promo data into a structured format suitable for data warehousing. This function enhances the raw
    data by converting binary fields to hexadecimal, normalizing descriptions
    """

    conn = duckdb.connect(DUCKDB_FILE)

    conn.sql(
        """CREATE OR REPLACE TABLE promo AS
            SELECT
                Подразделение_ID AS division_id,
                Номенклатура_ID AS product_id,
                Контрагент_ID AS contragent_id,
                ТипЦен_ID AS price_type_id,
                ХозОперация_ID AS operation_id,
                ТипСкидки AS type,
                Автор_ID AS author_id,
                CAST(НачалоДействия AS DATE) - INTERVAL 2000 YEAR as start_date,
                CAST(КонецДействия AS DATE) - INTERVAL 2000 YEAR AS end_date,
                Аббревиатура AS abbreviation,
                TRIM(Комментарий) AS comment,
                ТекущаяЦена AS price_actual_with_VAT,
                ЗначениеСкидки  AS price_promo_with_VAT,
                ТекущаяЗакупочнаяЦена AS cost_price_with_VAT,
                АкционнаяЗакупочнаяЦена AS cost_price_with_VAT_promo
            FROM promo_raw
        """
    )
    conn.sql("LOAD httpfs;")

    filename = "promo.parquet"
    s3_key = f"{BUCKET_NAME}/{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}/{S3_FOLDER}/{filename}"
    conn.sql(f"COPY promo TO 's3://{s3_key}';")
    ti.xcom_push(key="s3_key", value=s3_key)
    conn.close()


@task
def remove_temp_files():
    os.remove(DUCKDB_FILE)


@dag(
    default_args={
        "owner": "ubaitur5",
        "on_failure_callback": send_error_message_telegram,
    },
    schedule_interval="@daily",
    template_searchpath=["/opt/airflow/dags/include/sql_files/"],
    start_date=pendulum.DateTime(2023, 8, 1),
    doc_md=doc_md,
    tags=["etl", "dimensions"],
    catchup=False,
)
def promo():

    extract_promo_raw = SqlToS3OperatorImproved(
        task_id="extract_promo_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query=QUERY,
        s3_bucket=BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="promo_raw.parquet",
        params={"date_range": DATE_RANGE},
        replace=True,
        aws_conn_id=S3_CONN_ID,
        file_format="parquet",
        pd_kwargs={"index": False},  # pandas parameters to pass into .to_parquet()
    )

    delete_promo = ClickHouseOperator(
        task_id="delete_promo",
        database="dwh",
        sql=f"DELETE FROM promo WHERE start_date<='{{{{data_interval_end.subtract(days=1) | ds}}}}' AND end_date>='{{{{data_interval_end.subtract(days={DATE_RANGE}) | ds}}}}'",
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    load_promo = ClickHouseOperator(
        task_id="load_promo",
        database="dwh",
        sql=(
            """
            INSERT INTO promo
            (
                division_id,
                contragent_id,
                product_id,
                price_type_id,
                author_id,
                operation_id,
                type,
                comment,
                abbreviation,
                price_actual_with_VAT,
                price_promo_with_VAT,
                cost_price_with_VAT,
                cost_price_with_VAT_promo,
                start_date,
                end_date
            )
        
            SELECT 
                division_id,
                contragent_id,
                product_id,
                price_type_id,
                author_id,
                operation_id,
                type,
                comment,
                abbreviation,
                round(toDecimal64(price_actual_with_VAT,4),2) AS price_actual_with_VAT,
                round(toDecimal64(price_promo_with_VAT,4),2) AS price_promo_with_VAT,
                round(toDecimal64(cost_price_with_VAT,4),2) AS cost_price_with_VAT,
                round(toDecimal64(cost_price_with_VAT_promo,4),2) cost_price_with_VAT_promo,
                start_date,
                end_date
            FROM  s3(
                '{{conn.minio_s3.extra_dejson.endpoint_url }}/{{ti.xcom_pull(task_ids='transform_promo',key='s3_key')}}',
                'parquet'
                );
            """,
            # result of the last query is pushed to XCom
        ),
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    (
        extract_promo_raw
        >> from_s3_to_duckdb()
        >> transform_promo()
        >> delete_promo
        >> load_promo
        >> remove_temp_files()
    )


promo()
