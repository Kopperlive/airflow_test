WITH source AS (

    SELECT * FROM {{ ref("int_orders_grouped") }}

)

, final AS (
    SELECT * FROM source
)


SELECT * FROM final
