import numpy as np
import pandas as pd
import pendulum
import pyodbc
from airflow.decorators import dag, task
from airflow.models import Variable
from airflow.models.taskinstance import TaskInstance
from common_utils.report.s3_utils import read_df_from_s3, save_df_to_s3
from common_utils.telegram_utils import send_error_message_telegram
from custom_operators.s3tosql import SqlToS3OperatorImproved

doc_md = """
# ETL Supplier Settlements Test DAG Documentation

## Overview
This Directed Acyclic Graph (DAG) orchestrates the ETL process for supplier settlements, handling both main and remains data flows. It extracts data from SQL, processes it, and uploads the results to a data warehouse.

## Schedule and Execution
- **Frequency:** daily
- **Catch-up:** False

## Task Descriptions

### Extraction Tasks
- **extract_settlements_raw**
  - **Description:** Extracts raw settlement data from the SQL database.
  - **Source Database:** Configured via `AR_TRADE_CONN_ID`.
  - **Output:** Uploads data to S3 in CSV format.
  
- **extract_settlements_remains_raw**
  - **Description:** Extracts raw remains settlement data similarly configured as the main settlements.
  - **Output:** Data is also uploaded to S3 in CSV format.

### Transformation Tasks
- **transform_data_dynamically**
  - **Description:** Transforms extracted data based on document numbers linked to settlements.
  - **Special Handling:** Uses view names dynamically retrieved from the database based on document references.

- **transform_remains_data_dynamically**
  - **Description:** Similar to `transform_data_dynamically` but specifically handles the remains settlements.
  - **Note:** Overrides task ID to maintain uniqueness in task naming.

### Merging and Loading Tasks
- **merge_remains_and_main_tables**
  - **Description:** Merges transformed main and remains data frames.
  - **Output:** A consolidated DataFrame that is ready for the final load.

- **from_s3_to_dwh**
  - **Description:** Loads the final merged DataFrame from S3 to the Data Warehouse.
  - **Database:** Uses a Data Warehouse connection configured separately.


"""

# S3 stuff
S3_CONN_ID = "minio_s3"
BUCKET_NAME = "etl-data-files"
AR_TRADE_CONN_ID = "nsp_ar_trade"
S3_FOLDER = "etl_supplier_settlements"

UID = Variable.get("Reader")
PWD = Variable.get("Reader_password")


DATE_RANGE = 70


def get_view_name_from_database(
    document_name: str, cnxn: pyodbc.Connection
) -> pd.DataFrame:
    """
    Find view using table name
    TODO: if there is no such view -> create view
    """
    df_views = pd.read_sql(
        f"select name from sys.views where name like '%{document_name}'", cnxn
    )
    return df_views


def connect(server: str, db: str):
    MS_CONN_STR = f"DRIVER=ODBC Driver 17 for SQL Server;SERVER={server};DATABASE={db};PORT=1433;UID={UID};PWD={PWD}"

    conn = pyodbc.connect(MS_CONN_STR, timeout=10)
    return conn


@task
def transform_data_dynamically(
    ti: TaskInstance, data_interval_end: pendulum.DateTime, is_remains: bool = False
) -> pd.DataFrame:
    """
    Transforms settlement data dynamically based on document numbers associated with each settlement entry. This transformation
    process is tailored to handle either main or remains settlement data, depending on the 'is_remains' flag.

    The function retrieves data from an S3 bucket using the S3 key obtained from a previous task's XCom, then dynamically generates
    SQL queries to fetch related document data from a SQL database. This additional data is then merged with the initial dataset.

    Parameters:
        ti (TaskInstance): The task instance object used for accessing XCom.
        data_interval_end (pendulum.DateTime): The end date of the data interval being processed.
        is_remains (bool): Flag to indicate if the data being processed is for remains settlements. Defaults to False.

    Returns:
        pd.DataFrame: The transformed DataFrame containing both original settlement data and additional data fetched based on document numbers.

    """

    cnxn = connect(server="10.240.40.12", db="AR_TRADE")
    cursor = cnxn.cursor()
    cursor.fast_executemany = True
    """
    Находит все таблицы (вьюшки) по Номеру Документа и делает запрос необходимых данных по номеру документов
    """

    s3_key = ti.xcom_pull(
        task_ids=f"extract_settlements{'_remains' if is_remains else ''}_raw",
        key="return_value",
    )
    print("S3 key:", s3_key)
    df = read_df_from_s3(
        aws_conn_id=S3_CONN_ID,
        bucket_name=BUCKET_NAME,
        file_s3_key=s3_key,
    )

    document_query = """
    SELECT
        CONVERT(NCHAR(34), _IDRRef, 1) AS _IDRRef,
        CAST(DATEADD(year, -2000, _Date_Time) AS DATE) AS Deal_Date,
        _Number AS DealNumber,
        CONVERT(NCHAR(34), ПодразделениеКомпании_ID, 1) AS DivisionIDRef
    FROM {view_name} WITH (NOLOCK)
    WHERE CONVERT(nchar(34),_IDRRef,1) IN (SELECT _IDRRef FROM #Temp);

    DROP TABLE #Temp;
    """

    df_final = pd.DataFrame()
    if not df.empty:
        info_from_documents = pd.DataFrame()
        for document_number, df_settlements_part in df.groupby(by="НомерДокумента")[
            [
                "НомерДокумента",
                "Сделка_ID",
                "ХозОперация_ID",
                "Контрагент_ID",
                "Приход",
                "Расход",
            ]
        ]:
            if document_number == 0:  # Когда Сделка_ТИП=0 и не ссылается на документ
                continue

            cursor.execute(
                """
            CREATE TABLE #Temp(_IDRRef nvarchar(34))
            """
            )

            document_name = f"_Document{document_number}"
            view_name = get_view_name_from_database(document_name, cnxn)

            # No view found with given name
            if len(view_name) == 0:
                print(f"No view found: {view_name},{document_name}")
                raise Exception

            # Deal ids to find related documents
            deal_ids = list(df_settlements_part["Сделка_ID"].unique())
            deal_ids = [[i] for i in deal_ids]

            ##inserting results into temporary table
            cursor.executemany("INSERT INTO #Temp(_IDRRef) VALUES(?)", deal_ids)

            # Prepare query text to select documents info
            query = document_query.format(view_name=view_name.iloc[0, 0])

            print("Executing the following query:\n", query)
            cursor.execute(query)

            data = cursor.fetchall()

            df_document = pd.DataFrame.from_records(
                data, columns=[col[0] for col in cursor.description]
            )
            info_from_documents = pd.concat(
                [info_from_documents, df_document], ignore_index=True
            )

        df_final = df.merge(
            info_from_documents, how="left", left_on="Сделка_ID", right_on="_IDRRef"
        )

    filename = f"{'remains'if is_remains else 'main'}.csv"
    file_s3_key = save_df_to_s3(
        df=df_final,
        aws_conn_id=S3_CONN_ID,
        bucket_name=BUCKET_NAME,
        report_name=S3_FOLDER,
        filename=filename,
        data_interval_end=data_interval_end,
    )

    # Push the file's S3 key to XCom for further use
    ti.xcom_push(key="file_s3_key", value=file_s3_key)


@task
def merge_remains_and_main_tables(
    data_interval_end: pendulum.DateTime, ti: TaskInstance
):
    """
    Merges the transformed main and remains settlement tables into a single DataFrame. This merged DataFrame is then
    prepared for uploading to a data warehouse.

    The function pulls the S3 keys for the main and remains data from Airflow's XCom, reads the corresponding DataFrames
    from S3, and concatenates them into one DataFrame. It also handles the removal of specific columns that are not needed
    in the final output.

    Parameters:
        data_interval_end (pendulum.DateTime): The end date of the data interval for which data is being merged. This parameter
                                               is used to specify the file name in the final S3 upload.
        ti (TaskInstance): The task instance object used for accessing XCom to retrieve the S3 keys for the data files.

    """

    main_s3_key = ti.xcom_pull(
        task_ids="transform_data_dynamically",
        key="file_s3_key",
    )

    df_main = read_df_from_s3(
        aws_conn_id=S3_CONN_ID,
        bucket_name=BUCKET_NAME,
        file_s3_key=main_s3_key,
    )

    remains_s3_key = ti.xcom_pull(
        task_ids="transform_remains_data_dynamically",
        key="file_s3_key",
    )

    df_remains = read_df_from_s3(
        aws_conn_id=S3_CONN_ID,
        bucket_name=BUCKET_NAME,
        file_s3_key=remains_s3_key,
    )

    df_final = pd.concat([df_main, df_remains], ignore_index=True)
    df_final.drop(
        columns=[
            "Сделка_ТИП",
            "Сделка_ID",
            "НомерДокумента",
            "ДоговорВзаиморасчетов_ID",
            "_IDRRef",
        ],
        axis=1,
        inplace=True,
    )

    filename = "supplier_settlements_final.csv"
    file_s3_key = save_df_to_s3(
        df=df_final,
        aws_conn_id=S3_CONN_ID,
        bucket_name=BUCKET_NAME,
        report_name=S3_FOLDER,
        filename=filename,
        data_interval_end=data_interval_end,
    )

    # Push the file's S3 key to XCom for further use
    ti.xcom_push(key="file_s3_key", value=file_s3_key)


@task
def from_s3_to_dwh(
    data_interval_end: pendulum.DateTime,
    ti: TaskInstance,
):
    """
    Transfer data from s3 to dwh
    """

    s3_key = ti.xcom_pull(
        task_ids="merge_remains_and_main_tables",
        key="file_s3_key",
    )

    df = read_df_from_s3(
        aws_conn_id=S3_CONN_ID,
        bucket_name=BUCKET_NAME,
        file_s3_key=s3_key,
    )

    conn = connect(server="SRV-PROD-DWH", db="DWH")
    cursor = conn.cursor()
    cursor.fast_executemany = True
    df = df.replace(np.nan, None)
    named_tuples_list = list(df.itertuples(index=False))

    delete_query = f"DELETE FROM FactSupplierSettlements_test WHERE Date BETWEEN '{data_interval_end.subtract(days=DATE_RANGE).to_date_string()}' AND '{data_interval_end.subtract(days=1).to_date_string()}'"
    print("Executing query:\n", delete_query)
    cursor.execute(delete_query)

    print("Starting INSERT statements")
    cursor.executemany(
        """
    INSERT INTO FactSupplierSettlements_test(
        [Date]
        ,[OperationIDRef]
        ,[SupplierIDRef]
        ,[OpeningBalance]
        ,[Income]
        ,[Outgo]
        ,[Date_Deal]
        ,[DealNumber]
        ,[DivisionIDRef]
        ) 
    VALUES (?,?,?,?,?,?,?,?,?)""",
        named_tuples_list,
    )

    cursor.commit()


@dag(
    schedule_interval="@daily",
    default_args={
        "owner": "ubaitur5",
        "on_failure_callback": send_error_message_telegram,
    },
    start_date=pendulum.DateTime(2024, 1, 1),
    doc_md=doc_md,
    template_searchpath=["/opt/airflow/dags/include/sql_files/"],
    catchup=False,
)
def etl_supplier_settlements():

    extract_settlements_raw = SqlToS3OperatorImproved(
        task_id="extract_settlements_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query="etl_supplier_settlements.sql",
        s3_bucket=BUCKET_NAME,
        report_name=S3_FOLDER,
        params={"date_range": DATE_RANGE},
        filename="settlements_raw.csv",
        replace=True,
        aws_conn_id=S3_CONN_ID,
        pd_kwargs={"index": False},  # pandas parameters to pass into .to_parquet()
    )

    extract_settlements_remains_raw = SqlToS3OperatorImproved(
        task_id="extract_settlements_remains_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query="etl_supplier_settlements_remains.sql",
        s3_bucket=BUCKET_NAME,
        params={"date_range": DATE_RANGE},
        report_name=S3_FOLDER,
        filename="settlements_remains_raw.csv",
        replace=True,
        aws_conn_id=S3_CONN_ID,
        pd_kwargs={"index": False},  # pandas parameters to pass into .to_parquet()
    )

    transform_main = transform_data_dynamically()

    transform_remains = transform_data_dynamically.override(
        task_id="transform_remains_data_dynamically"
    )(is_remains=True)

    extract_settlements_raw >> transform_main
    extract_settlements_remains_raw >> transform_remains

    (
        [transform_main, transform_remains]
        >> merge_remains_and_main_tables()
        >> from_s3_to_dwh()
    )


etl_supplier_settlements()
