SELECT
    DATEADD(YEAR,-2000,p._Date_Time) AS start_datetime
    , p._Number As document_number
    , CONVERT(NCHAR(34),p.ПодразделениеКомпании_ID,1) AS division_id
    , CONVERT(NCHAR(34),p.ТипЦен_ID,1) AS price_type_id
    , CONVERT(NCHAR(34),pt.Номенклатура_ID,1) AS product_id
    , pt.Цена AS new_price
    , pt.ЦенаСтарая AS old_price
FROM {db}.dbo.vw_Переоценка p WITH(NOLOCK)
    JOIN {db}.dbo.vw_Переоценка_Товары pt WITH (NOLOCK)
        ON p._IDRRef=pt.Ссылка
    JOIN {db}.dbo.[vw_ПодразделенияКомпании] divisions WITH (NOLOCK)
		ON divisions.SHOPINDEX={db_number} AND divisions._IDRRef=p.ПодразделениеКомпании_ID
    WHERE p._Date_Time BETWEEN '{data_interval_start}' and '{data_interval_end}'
            AND p._Posted=0x01
            AND p._Marked=0x00