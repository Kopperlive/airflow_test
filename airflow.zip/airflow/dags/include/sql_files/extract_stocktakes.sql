SELECT 
	  A._IDRRef
	, DATEADD(YEAR, -2000, A.[_Date_Time])
	, A._Number
	, A.Автор_ID
	, A.ПодразделениеКомпании_ID
	, A.Комментарий
	, A.СкладКомпании_ID
	, A.ТипЦен_ID
	, A.ХозОперация_ID
	, B.Номенклатура_ID
	, B.КоличествоКнижн
	, B.КоличествоФакт
	, B.ЕдиницаИзмерения_ID
	, B.Цена				
	, B.ЦенаОтпускная		
	, B.СуммаКнижн			
	, B.СуммаФакт			
	, B.ШтрихКод
FROM [vw_Инвентаризация] A WITH (NOLOCK)
	INNER JOIN [vw_Инвентаризация_Товары] B WITH (NOLOCK)
		ON A._IDRRef = B.Ссылка
	WHERE A._Posted = 0x01 -- Только проведенные документы
		AND A._Marked = 0x00 -- Только не удалённые документы
		-- Ежедневное обновление данных за предыдущий и текущий месяц
		AND A._Date_Time >= '{{get_data_interval_start(data_interval_end).add(years=2000) | ds_nodash}}' AND A._Date_Time < '{{data_interval_end.add(years=2000) | ds_nodash}}'

-- Первичная выгрузка всех данных с августа 2023
-- AND DATEADD(YEAR, -2000, CONVERT(DATE, _Date_Time)) >= '2023-08-01'