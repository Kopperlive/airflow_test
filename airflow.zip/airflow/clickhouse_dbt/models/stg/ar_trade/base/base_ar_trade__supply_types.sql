WITH source AS (

    SELECT * FROM {{ source('raw_dbt','supply_types_raw') }}

)

, renamed AS (

    SELECT
        {{ transform_binary_to_uuid('_IDRRef') }} AS id
        , CAST(_EnumOrder AS UInt8) AS enum_value
    FROM source

)

SELECT * FROM renamed