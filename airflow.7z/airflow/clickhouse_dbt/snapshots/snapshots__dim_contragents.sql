{% snapshot snapshots__dim_contragents %}
    select * from {{ ref('base_ar_trade__contragents') }}
{% endsnapshot %}