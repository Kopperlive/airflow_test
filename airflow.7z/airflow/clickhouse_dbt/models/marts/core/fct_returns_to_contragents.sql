WITH source AS (

    SELECT * FROM {{ ref("int_returns_to_contragents_grouped") }}

)

, final AS (
    SELECT * FROM source
)


SELECT * FROM final
