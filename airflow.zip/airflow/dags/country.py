import os

import duckdb
import pendulum
from airflow.decorators import dag, task
from airflow.models.taskinstance import TaskInstance
from airflow_clickhouse_plugin.operators.clickhouse import ClickHouseOperator
from common_utils.telegram_utils import send_error_message_telegram
from custom_operators.s3tosql import SqlToS3OperatorImproved

doc_md = """
# Country Data ETL Process

This DAG manages the extraction, transformation, and loading (ETL) of country data from various sources into a data warehouse. The process is designed to run daily, ensuring that country data is updated and consistent across all reporting platforms.

## Process Overview

1. **Extract Raw Data**: Country data is pulled from a specific source, converted to parquet format, and stored in S3.
2. **Transform Data**: The raw data undergoes a transformation process to structure it for better usability in data warehousing. This includes converting binary fields to hexadecimal and normalizing descriptions.
3. **Load Data**: The transformed data is loaded into a ClickHouse data warehouse. Before loading, the existing country data in ClickHouse is truncated to prevent duplication.
4. **Cleanup**: Temporary files created during the process are removed to free up space and maintain organization.

## Details

- **Schedule**: It runs daily, handling data in a batch mode, which corresponds to the previous day's data.

"""

# S3 stuff
S3_CONN_ID = "minio_s3"
BUCKET_NAME = "etl-data-files"
S3_FOLDER = "country"

DUCKDB_FILE = "/tmp/country.db"

AR_TRADE_CONN_ID = "nsp_ar_trade"


@task
def from_s3_to_duckdb(ti: TaskInstance):
    """
    Retrieves  data from S3 and loads it into DuckDB for further processing. This task pulls multiple
    datasets including the current state of warehouses and additional attributes from different S3 keys set in prior tasks.
    """

    conn = duckdb.connect(DUCKDB_FILE)

    country_s3_key = ti.xcom_pull(task_ids="extract_country_raw", key="return_value")

    conn.sql(
        f"CREATE OR REPLACE TABLE country_raw AS SELECT * FROM read_parquet('s3://{BUCKET_NAME}/{country_s3_key}')"
    )
    conn.close()


@task
def transform_country(ti: TaskInstance, data_interval_end: pendulum.DateTime):
    """
    Transforms raw country data into a structured format suitable for data warehousing. This function enhances the raw
    data by converting binary fields to hexadecimal, normalizing descriptions
    """

    conn = duckdb.connect(DUCKDB_FILE)

    conn.sql(
        """CREATE OR REPLACE TABLE country AS
                SELECT
                _IDRRef AS id,
                CASE _Marked WHEN 0 THEN 'Активный' ELSE 'Деактивированный' END AS activity_status,
                _Code AS code,
                _Description as description
            FROM country_raw
        """
    )
    conn.sql("LOAD httpfs;")

    filename = "country.parquet"
    s3_key = f"{BUCKET_NAME}/{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}/{S3_FOLDER}/{filename}"
    conn.sql(f"COPY country TO 's3://{s3_key}';")
    ti.xcom_push(key="s3_key", value=s3_key)
    conn.close()


@task
def remove_temp_files():
    os.remove(DUCKDB_FILE)


@dag(
    default_args={
        "owner": "ubaitur5",
        "on_failure_callback": send_error_message_telegram,
    },
    schedule_interval="@daily",
    template_searchpath=["/opt/airflow/dags/include/sql_files/"],
    start_date=pendulum.DateTime(2024, 7, 23),
    doc_md=doc_md,
    tags=["etl", "dimensions", "geo"],
    catchup=False,
)
def country():

    extract_country_raw = SqlToS3OperatorImproved(
        task_id="extract_country_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query="""
        SELECT 
            CONVERT(NCHAR(34),_IDRRef,1) AS _IDRRef,
            CONVERT(INT,_Marked) AS _Marked,
            _Code,
            _Description
        FROM vw_КлассификаторСтранМира
        """,
        s3_bucket=BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="country_raw.parquet",
        replace=True,
        aws_conn_id=S3_CONN_ID,
        file_format="parquet",
        pd_kwargs={"index": False},  # pandas parameters to pass into .to_parquet()
    )

    truncate_country = ClickHouseOperator(
        task_id="truncate_country",
        database="dwh",
        sql="TRUNCATE TABLE country",
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    load_country = ClickHouseOperator(
        task_id="load_country",
        database="dwh",
        sql=(
            """
            INSERT INTO country
            (
                id          ,
                activity_status      ,
                description ,
                code  
            )
        
            SELECT 
                id          ,
                activity_status      ,
                description ,
                code  
            FROM  s3(
                '{{conn.minio_s3.extra_dejson.endpoint_url }}/{{ti.xcom_pull(task_ids='transform_country',key='s3_key')}}',
                'parquet'
                );
            """,
            # result of the last query is pushed to XCom
        ),
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    (
        extract_country_raw
        >> from_s3_to_duckdb()
        >> transform_country()
        >> truncate_country
        >> load_country
        >> remove_temp_files()
    )


country()
