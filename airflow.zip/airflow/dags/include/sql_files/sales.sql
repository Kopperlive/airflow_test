SELECT 
        _Period,
        CONVERT(NCHAR(34),ПодразделениеКомпании_ID,1) AS ПодразделениеКомпании_ID,
        CONVERT(NCHAR(34),СкладКомпании_ID,1) AS СкладКомпании_ID,
        CONVERT(NCHAR(34),Номенклатура_ID,1)  AS Номенклатура_ID,
        CONVERT(NCHAR(34),Поставщик_ID,1) AS Поставщик_ID,
        CONVERT(NCHAR(34),Покупатель_ID,1) AS Покупатель_ID,
        CONVERT(NCHAR(34),ДоговорВзаиморасчетов_ID,1) AS ДоговорВзаиморасчетов_ID,
        CONVERT(NCHAR(34),СтатусПартии_ID,1) AS СтатусПартии_ID,
        CONVERT(NCHAR(34),ХозОперация_ID,1) AS ХозОперация_ID,
        БезналичныйРасчет,
        CONVERT(NCHAR(34),СтавкаНДС_ID,1) AS СтавкаНДС_ID,
        Количество,
        Сумма,
        СуммаНДС,
        СуммаСкидки,
        Себестоимость,
        СуммаНДСВходящий

FROM vw_Продажи  WITH (NOLOCK)
WHERE _Active=0x01
    AND Покупатель_ID <> 0xAB3F3CA82AFF8E7411ED287787A6EA04 
    AND _Period >= DATEADD(YEAR,2000,'{{{{get_data_interval_start(data_interval_end,{month_range}) | ds_nodash}}}}')
    AND _Period < DATEADD(YEAR,2000,'{{{{data_interval_end | ds_nodash}}}}')
