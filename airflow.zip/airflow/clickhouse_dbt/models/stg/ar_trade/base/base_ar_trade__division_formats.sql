WITH source AS (

    SELECT * FROM {{ source('raw_dbt','division_formats_raw') }}

)

, renamed AS (

    SELECT
        {{ transform_binary_to_uuid('_IDRRef') }} AS id
        , {{ transform_string('_Description') }} AS description
    FROM source

)


SELECT * FROM renamed
