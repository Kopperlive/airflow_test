import os

import duckdb
import pendulum
from airflow.decorators import dag, task
from airflow.models import Variable
from airflow.models.taskinstance import TaskInstance
from airflow_clickhouse_plugin.operators.clickhouse import ClickHouseOperator
from common_utils.etl_utils import build_delete_partition_query, get_data_interval_start
from common_utils.telegram_utils import send_error_message_telegram
from custom_operators.s3tosql import SqlToS3OperatorImproved

doc_md = """
# Documentation for ETL movements DAG

## Overview

The `movements` DAG orchestrates the extraction, transformation, and loading of movements data from source systems into a data warehouse, with additional steps to export processed data to an S3 bucket. It employs DuckDB for intermediate data processing and ClickHouse for final data storage, ensuring effective and scalable management of movements data.

## DAG Configuration

- **Schedule**: Runs daily.
- **Catchup**: False (does not perform catch-up runs for past dates).
- **Concurrency**: Allows only one run at a time with `max_active_runs` set to 1.
- **Tags**: Includes tags `["etl", "facts"]` for easy filtering and identification within the Airflow UI.

## Task Details

### 1. `extract_movements_raw`
- **Type**: `SqlToS3OperatorImproved`
- **Description**: Extracts movements data from a SQL database and stores it in Parquet format on S3.
- **Outputs**: Parquet file stored in the S3 bucket defined by `BUCKET_NAME`.

### 2. `from_s3_to_duckdb`
- **Type**: Python task (@task decorator)
- **Description**: Retrieves data from S3 and loads it into a local DuckDB database for further processing.
- **Dependencies**: Follows `extract_movements_raw`.

### 3. `transform_movements`
- **Type**: Python task (@task decorator)
- **Description**: Transforms raw movements data into a structured format suitable for data warehousing, including enhancements such as conversion of binary fields to hexadecimal and normalization of descriptions.
- **Dependencies**: Executes after `from_s3_to_duckdb`.

### 4. `drop_partitions`
- **Type**: `ClickHouseOperator`
- **Description**: Manages data retention by dropping older partitions in the ClickHouse data warehouse based on the predefined month range.
- **Dependencies**: Runs after `transform_movements`.

### 5. `load_movements`
- **Type**: `ClickHouseOperator`
- **Description**: Loads the transformed movements data from S3 into ClickHouse.
- **Dependencies**: Follows `drop_partitions`.

### 6. `remove_temp_files`
- **Type**: Python task (@task decorator)
- **Description**: Cleans up temporary files created during the DAG execution to free up disk space and maintain order.
- **Dependencies**: Concludes the DAG after `load_movements`.

## Execution Flow

The DAG starts by extracting movements data, loading it into DuckDB for processing, transforming it through several stages, and finally loading the processed data into ClickHouse and exporting to S3. Each step is prepared by the outputs of the previous steps, maintaining data integrity and processing continuity.

"""

# S3 stuff
S3_CONN_ID = "minio_s3"
BUCKET_NAME = "etl-data-files"
AR_TRADE_CONN_ID = "nsp_ar_trade"
S3_FOLDER = "movements"
QUERY = "movements.sql"

DUCKDB_FILE = "/tmp/movements.db"


FACTS_MONTH_RANGE = int(Variable.get("facts_month_range"))


@task
def from_s3_to_duckdb(ti: TaskInstance):
    """
    Retrieves  data from S3 and loads it into DuckDB for further processing. This task pulls multiple
    datasets including the current state of warehouses and additional attributes from different S3 keys set in prior tasks.
    """

    conn = duckdb.connect(DUCKDB_FILE)

    movements_s3_key = ti.xcom_pull(
        task_ids="extract_movements_raw", key="return_value"
    )

    conn.sql(
        f"CREATE OR REPLACE TABLE movements_raw AS SELECT * FROM read_parquet('s3://{BUCKET_NAME}/{movements_s3_key}')"
    )
    conn.close()


@task
def transform_movements(ti: TaskInstance, data_interval_end: pendulum.DateTime):
    """
    Transforms raw movements data into a structured format suitable for data warehousing. This function enhances the raw
    data by converting binary fields to hexadecimal, normalizing descriptions
    """

    conn = duckdb.connect(DUCKDB_FILE)

    conn.sql(
        f"""CREATE OR REPLACE TABLE movements AS
            SELECT
                _Date_Time - INTERVAL 2000 YEAR as datetime
                ,_Number as number
                ,Автор_ID AS author_id
                ,ПодразделениеКомпании_ID AS division_id
                ,РегламентированныйУчет is_regulated_accounting
                ,Комментарий as comment
                ,CASE WHEN СкладКомпании_НОМЕР=296 THEN 1 WHEN СкладКомпании_НОМЕР=310 THEN 2 ELSE 0 END AS sender_type
                ,СкладКомпании_ID as sender_id
                ,CASE WHEN СкладПолучатель_НОМЕР=296 THEN 1 WHEN СкладПолучатель_НОМЕР=310 THEN 2 ELSE 0 END AS receiver_type
                ,СкладПолучатель_ID AS receiver_id
                ,ТипЦен_ID as price_type_id
                ,ХозОперация_ID AS operation_id
                ,ИДДокументаОтгрузки AS shipment_id
                ,ЗакрытиеЗаказовПокупателей AS  is_closed_customer_order
                ,Номенклатура_ID AS product_id
                ,ЕдиницаИзмерения_ID AS measurement_id
                ,СтавкаНДС_ID AS vat_rate_id
                ,SUM(Количество) AS quantity
                ,SUM(СуммаРозничная) AS amount_with_VAT
                ,SUM(Сумма) AS cost_price_with_VAT
                ,SUM(СуммаНДС) AS amount_VAT
            FROM movements_raw
            GROUP BY ALL
        """
    )
    conn.sql("LOAD httpfs;")

    filename = "movements.parquet"
    s3_key = f"{BUCKET_NAME}/{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}/{S3_FOLDER}/{filename}"
    conn.sql(f"COPY movements TO 's3://{s3_key}';")
    ti.xcom_push(key="s3_key", value=s3_key)
    conn.close()


@task
def remove_temp_files():
    os.remove(DUCKDB_FILE)


@dag(
    default_args={
        "owner": "ubaitur5",
        "on_failure_callback": send_error_message_telegram,
    },
    schedule_interval="@daily",
    template_searchpath=["/opt/airflow/dags/include/sql_files/"],
    start_date=pendulum.DateTime(2024, 3, 23),
    doc_md=doc_md,
    tags=["etl", "facts"],
    catchup=False,
    user_defined_macros={
        "build_delete_partition_query": build_delete_partition_query,
        "get_data_interval_start": get_data_interval_start,
    },
)
def movements():

    extract_movements_raw = SqlToS3OperatorImproved(
        task_id="extract_movements_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query=QUERY,
        s3_bucket=BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="movements_raw.parquet",
        params={"month_range": FACTS_MONTH_RANGE},
        replace=True,
        aws_conn_id=S3_CONN_ID,
        file_format="parquet",
        pd_kwargs={"index": False},  # pandas parameters to pass into .to_parquet()
    )

    drop_partitions = ClickHouseOperator(
        task_id="drop_partitions",
        database="dwh",
        sql=f"ALTER TABLE movements {{{{build_delete_partition_query({FACTS_MONTH_RANGE},data_interval_end)}}}}",
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    load_movements = ClickHouseOperator(
        task_id="load_movements",
        database="dwh",
        sql=(
            """
            INSERT INTO movements
            (
                date
		,time_id
                ,division_id
                ,sender_type
                ,sender_id
                ,receiver_type
                ,receiver_id
                ,product_id
                ,number
                ,operation_id
                ,shipment_id
                ,price_type_id
                ,author_id
                ,is_regulated_accounting
                ,is_closed_customer_order
                ,measurement_id
                ,vat_rate_id
                ,quantity
                ,amount_with_VAT
                ,amount_VAT
                ,cost_price_with_VAT
                ,`comment`
                )
        
            SELECT 
                CAST(datetime AS date) AS date
		,t.id AS time_id
                ,division_id
                ,sender_type
                ,sender_id
                ,receiver_type
                ,receiver_id
                ,product_id
                ,`number`
                ,operation_id
                ,shipment_id
                ,price_type_id
                ,author_id
                ,is_regulated_accounting
                ,is_closed_customer_order
                ,measurement_id
                ,vat_rate_id
                ,round(toDecimal64(quantity,4),3) AS quantity
                ,round(toDecimal64(amount_with_VAT,4),2) AS amount_with_VAT
                ,round(toDecimal64(amount_VAT,4),2) AS amount_VAT
                ,round(toDecimal64(cost_price_with_VAT,4),2) AS cost_price_with_VAT
                ,`comment`
            FROM  s3(
                '{{conn.minio_s3.extra_dejson.endpoint_url }}/{{ti.xcom_pull(task_ids='transform_movements',key='s3_key')}}',
                'parquet'
                ) m
		JOIN dwh.time t ON t.description = formatDateTime(m.datetime, '%T');
            """,
            # result of the last query is pushed to XCom
        ),
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    (
        extract_movements_raw
        >> from_s3_to_duckdb()
        >> transform_movements()
        >> drop_partitions
        >> load_movements
        >> remove_temp_files()
    )


movements()
