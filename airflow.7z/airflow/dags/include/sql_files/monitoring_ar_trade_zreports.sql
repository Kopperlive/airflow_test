SELECT divisions._Fld13813 AS [SHOPINDEX],
    --    DATEADD(YEAR,-2000,CAST(z._Fld4889 AS DATE)) AS [Date],
    --    DATEADD(YEAR,-2000,CAST(cassa._Fld4933 AS DATE)) AS [ZDate],
    --    z._Fld4886 AS [ZSum],
       cassa._Fld4934 AS [CASHNUMBER],
       cassa._Fld4935 AS [ZNUMBER],
       SUM(cassa._Fld4937) AS [ChequeCount],
       SUM(cassa._Fld4938) AS [ChequeSum]
FROM _Document458 z
    JOIN _Document458_VT4931 cassa
        ON z._Posted = 0x01
           and z._Marked = 0x00
           AND cassa._Document458_IDRRef = z._IDRRef
           AND CAST(_Fld4889 AS DATE) BETWEEN '{{data_interval_end.add(years=2000).subtract(days=params.date_range+3) | ds}}' AND '{{data_interval_end.add(years=2000)| ds}}'
    JOIN _Reference296 divisions
        ON divisions._IDRRef = z._Fld4881RRef
            and divisions._Fld13813!=0
GROUP BY divisions._Fld13813,--shopindex
       cassa._Fld4934,--cashnumber
       cassa._Fld4935--znumber

ORDER BY SHOPINDEX,
         CASHNUMBER,
         ZNUMBER