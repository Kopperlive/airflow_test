import os

import duckdb
import pandas as pd
import pendulum
from airflow.decorators import dag, task
from airflow.models.taskinstance import TaskInstance
from airflow_clickhouse_plugin.operators.clickhouse import ClickHouseOperator
from common_utils.telegram_utils import send_error_message_telegram
from constants.etl_constants import (
    EMPTY_NULL_PLACEHOLDER,
    EMPTY_NULL_PLACEHOLDER_FOR_REFERENCES,
)
from custom_operators.s3tosql import SqlToS3OperatorImproved
from duckdb.typing import BLOB, VARCHAR

doc_md = """
# ETL Dimensions contragent DAG Documentation

## Overview

The `contragent` DAG is designed to extract, transform, and load (ETL) contragent data into a data warehouse, with a focus on managing contragent dimensions. This DAG includes tasks for data extraction, transformation to a structured format, management of slowly changing dimensions (SCD), and building and updating a contragent hierarchy.

## DAG Configuration

- **Schedule**: Runs daily
- **Catchup**: False
- **Tags**: 'etl', 'dimensions'

## Tasks

### extract_contragent_raw

- **Operator**: `SqlToS3OperatorImproved`
- **Description**: Extracts raw contragent data from a source SQL database and stores it in an S3 bucket in parquet format.
- **SQL Connection**: Connected to the source database using `AR_TRADE_CONN_ID`.

### extract_contragent_old

- **Operator**: `ClickHouseOperator`
- **Description**: Extracts the current state of contragents marked as 'current' from the data warehouse to manage updates and track historical changes.
- **Database**: Data warehouse with connection `clickhouse_dwh`.

### extract_contragent_hierarchy_old

- **Operator**: `ClickHouseOperator`
- **Description**: Similar to `extract_contragent_old` but for the contragent hierarchy, capturing the current hierarchical relationships.

### from_s3_to_duckdb

- **Function**: `from_s3_to_duckdb`
- **Description**: Loads contragent data from S3 into DuckDB for transformation, setting up connections and configurations required for access.

### transform_contragent

- **Function**: `transform_contragent`
- **Description**: Transforms raw contragent data within DuckDB by structuring it and enhancing it with additional attributes like hexadecimal IDs and activity_status descriptions.

### contragent_scd

- **Function**: `contragent_scd`
- **Description**: Manages the slowly changing dimensions of contragent data by identifying new and updated records and setting their historical states.

### build_hierarchy_bridge_table

- **Function**: `build_hierarchy_bridge_table`
- **Description**: Constructs a hierarchy bridge table using recursive queries within DuckDB to map the complete hierarchy of contragents based on parent-child relationships.

### hierarchy_scd

- **Function**: `hierarchy_scd`
- **Description**: Similar to `contragent_scd` but specifically for managing the slowly changing dimensions of the contragent hierarchy.

### load_contragent

- **Operator**: `ClickHouseOperator`
- **Description**: Loads transformed and updated contragent data from S3 back into the data warehouse for querying and analytics.

### update_contragent

- **Operator**: `ClickHouseOperator`
- **Description**: Updates the end dates and statuses of contragents in the data warehouse to reflect changes captured in the current DAG run.

### load_contragent_hierarchy

- **Operator**: `ClickHouseOperator`
- **Description**: Loads the contragent hierarchy data into the data warehouse.

### update_contragent_hierarchy

- **Operator**: `ClickHouseOperator`
- **Description**: Updates the contragent hierarchy in the data warehouse similar to the `update_contragent` task.

## Additional Information

- This DAG utilizes advanced SQL and DuckDB functions to handle complex data transformations and hierarchy management.
- The use of both SQL and DuckDB provides flexibility in processing while leveraging the strengths of both systems for data handling and transformations.
- Data consistency and integrity are ensured through the careful management of slowly changing dimensions and hierarchical relationships.

"""

# S3 stuff
S3_CONN_ID = "minio_s3"
BUCKET_NAME = "etl-data-files"
AR_TRADE_CONN_ID = "nsp_ar_trade"
S3_FOLDER = "contragent"

DUCKDB_FILE = "/tmp/contragent.db"


def binary_to_hex(binary_value):
    """
    Converts a binary value to a hexadecimal string. This function is particularly useful for handling binary identifiers
    from databases that represent them in a binary format.

    Parameters:
        binary_value (bytes): The binary value to be converted.

    Returns:
        str: A hexadecimal string representation of the binary value prefixed with '0x'.

    Example:
        >>> binary_to_hex(b'\x00\x01')
        '0x0001'
    """

    return "0x" + binary_value.hex().upper()


@task
def from_s3_to_duckdb(data_interval_end: pendulum.DateTime, ti: TaskInstance):
    """
    Loads contragent-related data from S3 into DuckDB for processing. This function sets up connections, configures access,
    and loads the data into DuckDB tables for further transformation.
    """

    conn = duckdb.connect(DUCKDB_FILE)

    contragent_s3_key = ti.xcom_pull(
        task_ids="extract_contragent_raw", key="return_value"
    )

    contragent_old_s3_key = f"{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}/{S3_FOLDER}/contragent_old.csv"
    contragent_hierarchy_old_s3_key = f"{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}/{S3_FOLDER}/contragent_hierarchy_old.csv"

    conn.sql(
        f"CREATE OR REPLACE TABLE contragent_raw AS SELECT * FROM read_parquet('s3://{BUCKET_NAME}/{contragent_s3_key}')"
    )

    conn.sql(
        f"CREATE OR REPLACE TABLE contragent_old AS SELECT * FROM read_csv('s3://{BUCKET_NAME}/{contragent_old_s3_key}')"
    )

    conn.sql(
        f"CREATE OR REPLACE TABLE contragent_hierarchy_old AS SELECT * FROM read_csv('s3://{BUCKET_NAME}/{contragent_hierarchy_old_s3_key}')"
    )


@task
def transform_contragent():
    """
    Transforms raw contragent data into a structured format suitable for data warehousing. This function enhances the raw
    data by adding additional fields, converting binary fields to hexadecimal, and applying conditional logic to create
    more descriptive attributes.
    """

    conn = duckdb.connect(DUCKDB_FILE)

    conn.create_function("binary_to_hex", binary_to_hex, [BLOB], VARCHAR)
    conn.sql(
        f"""CREATE OR REPLACE TABLE contragent AS
            SELECT 
                binary_to_hex(s._IDRRef) AS id,
                binary_to_hex(s._ParentIDRRef) AS parent_id,
                CASE
                    WHEN s.ГоловнойКонтрагент_ID IS NOT NULL THEN
                        binary_to_hex(s.ГоловнойКонтрагент_ID)
                    ELSE
                        '{EMPTY_NULL_PLACEHOLDER_FOR_REFERENCES}'
                END AS head_contragent_id,
                s._Code AS code,
                TRIM(s._Description) AS description,
                CASE binary_to_hex(s._Marked)
                    WHEN '0x01' THEN
                        'Деактивированный'
                    ELSE
                        'Активный'
                END as activity_status,
                CASE binary_to_hex(s._Folder)
                    WHEN '0x01' THEN
                        'Строка'
                    ELSE
                        'Папка'
                END AS type,
                CASE
                    WHEN s.ОсвобожденОтНДС IS NOT NULL THEN
                        CASE binary_to_hex(s.ОсвобожденОтНДС)
                            WHEN '0x01' THEN
                                'Освобожден'
                            WHEN '0x00' THEN
                                'Не освобожден'
                        END
                    ELSE
                        '{EMPTY_NULL_PLACEHOLDER}'
                END AS exempt_from_VAT,
                CASE
                    WHEN s.Импорт IS NOT NULL THEN
                        CASE binary_to_hex(Импорт)
                            WHEN '0x01' THEN
                                'Импорт'
                            WHEN '0x00' THEN
                                'Местное'
                        END
                    ELSE
                        '{EMPTY_NULL_PLACEHOLDER}'
                END AS import_status,
                CASE
                    WHEN TRIM(s.ИНН) = ''
                            OR s.ИНН IS NULL THEN
                        '{EMPTY_NULL_PLACEHOLDER}'
                    ELSE
                        s.ИНН
                END AS inn,
                binary_to_hex(COALESCE(s.ОсновнойДоговорВзаиморасчетов_ID, '{EMPTY_NULL_PLACEHOLDER_FOR_REFERENCES}')) AS main_contragent_settlement_id,
                CASE
                    WHEN TRIM(s.ЭлектронныйАдрес) = ''
                            OR s.ЭлектронныйАдрес IS NULL THEN
                        '{EMPTY_NULL_PLACEHOLDER}'
                    ELSE
                        s.ЭлектронныйАдрес
                END AS email_address
            FROM contragent_raw s
        """
    )


@task
def contragent_scd(
    data_interval_start: pendulum.DateTime,
    data_interval_end: pendulum.DateTime,
    ti: TaskInstance,
):
    """
    Implements Slowly Changing Dimension (SCD) logic for contragent data by managing how data updates between cycles are
    handled to maintain a historical record. New and updated records are identified, and their historical states are managed.

    """
    conn = duckdb.connect(DUCKDB_FILE)

    # getting new rows
    conn.sql(
        """
    CREATE OR REPLACE TABLE contragent_new_rows AS
    (
    SELECT 
        id                          ,
        parent_id                   ,
        head_contragent_id          ,
        code                        ,
        description                 ,
        activity_status             ,
        type                        ,
        exempt_from_VAT             ,
        import_status               ,
        inn                         ,
        main_contragent_settlement_id,
        email_address               
    FROM contragent
    EXCEPT
    SELECT 
        id                          ,
        parent_id                   ,
        head_contragent_id          ,
        code                        ,
        description                 ,
        activity_status             ,
        type                        ,
        exempt_from_VAT             ,
        import_status               ,
        inn                         ,
        main_contragent_settlement_id,
        email_address               
    FROM contragent_old
    )
    """
    )

    # getting updated(changed) rows
    conn.sql(
        """
    CREATE OR REPLACE TABLE contragent_updated_rows AS
    (
    SELECT 
        id                          ,
        parent_id                   ,
        head_contragent_id          ,
        code                        ,
        description                 ,
        activity_status             ,
        type                        ,
        exempt_from_VAT             ,
        import_status               ,
        inn                         ,
        main_contragent_settlement_id,
        email_address               
    FROM contragent_old
    EXCEPT 
    SELECT 
        id                          ,
        parent_id                   ,
        head_contragent_id          ,
        code                        ,
        description                 ,
        activity_status             ,
        type                        ,
        exempt_from_VAT             ,
        import_status               ,
        inn                         ,
        main_contragent_settlement_id,
        email_address               
    FROM contragent
    )
    """
    )

    # if table in dwh is empty fill it with data_interval_start (1970-1-1) which is minimum possible date in clickhouse
    count_old = conn.sql("SELECT COUNT(*) FROM contragent_old").fetchone()[0]
    if count_old == 0:
        data_interval_start = pendulum.DateTime(1970, 1, 1)

    # for new rows set start date to today
    conn.sql(
        f"ALTER TABLE contragent_new_rows ADD COLUMN start_date Date DEFAULT '{data_interval_start.to_date_string()}'"
    )

    # for new rows set end_date to the maximum possible date in clickhouse
    conn.sql(
        "ALTER TABLE contragent_new_rows ADD COLUMN end_date Date DEFAULT '2149-06-06'"
    )

    # for new rows set is_current to 'Текущий'
    conn.sql(
        "ALTER TABLE contragent_new_rows ADD COLUMN is_current String DEFAULT 'Текущий'"
    )

    conn.sql("LOAD httpfs;")

    # push new rows to s3
    filename = "contragent_new_rows.parquet"
    s3_key = f"{BUCKET_NAME}/{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}/{S3_FOLDER}/{filename}"
    conn.sql(f"COPY contragent_new_rows TO 's3://{s3_key}';")
    ti.xcom_push(key="s3_key", value=s3_key)

    # push updated(changed rows) to s3
    updated_filename = "contragent_updated_rows.parquet"
    updated_s3_key = f"{BUCKET_NAME}/{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}/{S3_FOLDER}/{updated_filename}"
    conn.sql(f"COPY contragent_updated_rows TO 's3://{updated_s3_key}';")
    ti.xcom_push(key="updated_s3_key", value=updated_s3_key)


@task
def remove_temp_files():
    os.remove(DUCKDB_FILE)


@task
def build_hierarchy_bridge_table():
    """
    Constructs a hierarchy bridge table for contragents, mapping parent-child relationships across multiple levels. This function
    uses recursive queries to assemble the hierarchy and outputs a table that is used for managing complex relationships
    within the contragent data.
    """

    conn = duckdb.connect(DUCKDB_FILE)

    # The query starts with the top-level contragents (where parent_id is zero) and recursively joins to retrieve all levels of descendants
    df_hierarchy = conn.sql(
        """
        WITH RECURSIVE CTE_RECURSIVE AS (
            SELECT description,id,parent_id,type,1 AS Level FROM contragent WHERE parent_id='0x00000000000000000000000000000000'
            UNION ALL
            SELECT c.description,c.id,c.parent_id,c.type,p.Level+1 AS Level FROM contragent c JOIN CTE_RECURSIVE p ON c.parent_id=p.id
        )
        SELECT
            t1.parent_id,
            t1.id,
            t1.description,
            t1.level,
            t1.type,
            COALESCE((SELECT 0 FROM contragent t2 WHERE t1.id = t2.parent_id LIMIT 1),1) AS lowest_flag,
            CASE WHEN t1.Level = 1 THEN  1 ELSE  0 END AS highest_flag
        FROM CTE_RECURSIVE t1 
    """
    ).df()

    # Group the DataFrame by 'parent_id' and create a list of child IDs for each parent
    parent_to_children = df_hierarchy.groupby("parent_id")["id"].apply(list).to_dict()

    # Define a recursive function to traverse the hierarchy and collect all descendants of each parent(not only it's immediate descendants, but also descendants of this descendant,etc. )
    def get_all_descendants(parent_id, level):
        children = parent_to_children.get(parent_id, [])
        all_descendants = []
        if level == 1:
            all_descendants.append({"child_id": parent_id, "level": 0})
        for child in children:
            all_descendants.append({"child_id": child, "level": level})
            all_descendants.extend(get_all_descendants(child, level + 1))
        return all_descendants

    # Build a dictionary of all descendants for each parent
    all_descendants = {
        parent_id: get_all_descendants(parent_id, level=1)
        for parent_id in parent_to_children.keys()
    }

    # Flatten the dictionary into a list of tuples (parent, child, level)
    relationship_list = [
        (parent, descendant.get("child_id"), descendant.get("level"))
        for parent, descendants in all_descendants.items()
        for descendant in descendants
    ]

    # Create a DataFrame from the list
    relationship_df = pd.DataFrame(  # noqa: F841
        relationship_list, columns=["parent_id", "child_id", "level"]
    )

    # Load the relationship DataFrame back to DuckDB and join with the hierarchy DataFrame to construct the final hierarchy table
    # This table includes both highest flag (for top-level nodes) and lowest flag (for leaf nodes)
    conn.sql(
        """CREATE OR REPLACE TABLE contragent_hierarchy AS 
           SELECT 
                r.parent_id,
                r.child_id,
                r.level AS depth_from_parent,
                p.highest_flag AS highest_flag_parent,
                c.lowest_flag AS lowest_flag_child
           FROM relationship_df r
           JOIN  df_hierarchy p ON r.parent_id=p.id 
           JOIN df_hierarchy c ON r.child_id = c.id
        """
    )


@task
def hierarchy_scd(
    data_interval_start: pendulum.DateTime,
    data_interval_end: pendulum.DateTime,
    ti: TaskInstance,
):
    """
    Manages the Slowly Changing Dimension logic for the contragent hierarchy, ensuring that updates to the hierarchy are
    captured and historical integrity is maintained. This function identifies new and updated hierarchy nodes.
    """

    conn = duckdb.connect(DUCKDB_FILE)

    # getting new rows
    conn.sql(
        """
    CREATE OR REPLACE TABLE contragent_hierarchy_new_rows AS
    (
    SELECT 
        parent_id          ,
        child_id           ,
        depth_from_parent  ,
        highest_flag_parent,
        lowest_flag_child  
    FROM contragent_hierarchy
    EXCEPT
    SELECT 
        parent_id          ,
        child_id           ,
        depth_from_parent  ,
        highest_flag_parent,
        lowest_flag_child  
    FROM contragent_hierarchy_old
    )
    """
    )

    # getting updated(changed) rows
    conn.sql(
        """
    CREATE OR REPLACE TABLE contragent_hierarchy_updated_rows AS
    (
    SELECT 
        parent_id          ,
        child_id           ,
        depth_from_parent  ,
        highest_flag_parent,
        lowest_flag_child  
    FROM contragent_hierarchy_old
    EXCEPT 
    SELECT 
        parent_id          ,
        child_id           ,
        depth_from_parent  ,
        highest_flag_parent,
        lowest_flag_child  
    FROM contragent_hierarchy
    )
    """
    )

    # if table in dwh is empty fill it with data_interval_start (1970-1-1) which is minimum possible date in clickhouse
    count_old = conn.sql("SELECT COUNT(*) FROM contragent_hierarchy_old").fetchone()[0]
    if count_old == 0:
        data_interval_start = pendulum.DateTime(1970, 1, 1)

    # for new rows set start date to today
    conn.sql(
        f"ALTER TABLE contragent_hierarchy_new_rows ADD COLUMN start_date Date DEFAULT '{data_interval_start.to_date_string()}'"
    )

    # for new rows set end_date to the maximum possible date in clickhouse
    conn.sql(
        "ALTER TABLE contragent_hierarchy_new_rows ADD COLUMN end_date Date DEFAULT '2149-06-06'"
    )

    # for new rows set is_current to 'Текущий'
    conn.sql(
        "ALTER TABLE contragent_hierarchy_new_rows ADD COLUMN is_current String DEFAULT 'Текущий'"
    )

    conn.sql("LOAD httpfs;")

    # push new rows to s3
    filename = "contragent_hierarchy_new_rows.parquet"
    s3_key = f"{BUCKET_NAME}/{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}/{S3_FOLDER}/{filename}"
    conn.sql(f"COPY contragent_hierarchy_new_rows TO 's3://{s3_key}';")
    ti.xcom_push(key="s3_key", value=s3_key)

    # push updated(changed rows) to s3
    updated_filename = "contragent_hierarchy_updated_rows.parquet"
    updated_s3_key = f"{BUCKET_NAME}/{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}/{S3_FOLDER}/{updated_filename}"
    conn.sql(f"COPY contragent_hierarchy_updated_rows TO 's3://{updated_s3_key}';")
    ti.xcom_push(key="updated_s3_key", value=updated_s3_key)


@dag(
    default_args={
        "owner": "ubaitur5",
        "on_failure_callback": send_error_message_telegram,
    },
    schedule_interval="@daily",
    template_searchpath=["/opt/airflow/dags/include/sql_files/"],
    start_date=pendulum.DateTime(2024, 7, 23),
    doc_md=doc_md,
    tags=["etl", "dimensions"],
    catchup=False,
)
def contragent():

    extract_contragent_raw = SqlToS3OperatorImproved(
        task_id="extract_contragent_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query="""
        SELECT
            _IDRRef,
            _ParentIDRRef,
            _Folder,
            _Code,
            _Description,
            _Marked,
            [ИНН],
            [ОсновнойДоговорВзаиморасчетов_ID],
            [ОсвобожденОтНДС],
            [ГоловнойКонтрагент_ID],
            [ЭлектронныйАдрес],
            [Импорт]
        FROM [dbo].[vw_Контрагенты]
        """,
        s3_bucket=BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="contragent_raw.parquet",
        replace=True,
        aws_conn_id=S3_CONN_ID,
        file_format="parquet",
        pd_kwargs={"index": False},  # pandas parameters to pass into .to_parquet()
    )

    extract_contragent_hierarchy_old = ClickHouseOperator(
        task_id="extract_contragent_hierarchy_old",
        database="dwh",
        settings={"format_csv_null_representation": ""},
        sql=(
            f"""
            INSERT INTO FUNCTION
            s3(
                '{{{{ conn.minio_s3.extra_dejson.endpoint_url_for_writing }}}}/{BUCKET_NAME}/{{{{data_interval_end.year}}}}/{{{{data_interval_end.month}}}}/{{{{data_interval_end.day}}}}/{S3_FOLDER}/contragent_hierarchy_old.csv',
                '{{{{ conn.minio_s3.extra_dejson.aws_access_key_id}}}}',
                '{{{{ conn.minio_s3.extra_dejson.aws_secret_access_key}}}}',
                'CSVWithNames'
                )
            SELECT 
                parent_id          ,
                child_id           ,
                depth_from_parent  ,
                highest_flag_parent,
                lowest_flag_child  
            FROM contragent_hierarchy
            WHERE is_current='Текущий'
            SETTINGS s3_create_new_file_on_insert = 1,s3_truncate_on_insert=1
            """,
            # result of the last query is pushed to XCom
        ),
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    extract_contragent_old = ClickHouseOperator(
        task_id="extract_contragent_old",
        database="dwh",
        settings={"format_csv_null_representation": ""},
        sql=(
            f"""
            INSERT INTO FUNCTION
            s3(
                '{{{{ conn.minio_s3.extra_dejson.endpoint_url_for_writing }}}}/{BUCKET_NAME}/{{{{data_interval_end.year}}}}/{{{{data_interval_end.month}}}}/{{{{data_interval_end.day}}}}/{S3_FOLDER}/contragent_old.csv',
                '{{{{ conn.minio_s3.extra_dejson.aws_access_key_id}}}}',
                '{{{{ conn.minio_s3.extra_dejson.aws_secret_access_key}}}}',
                'CSVWithNames'
                )
            SELECT 
                id                              ,
                parent_id                       ,
                head_contragent_id              ,
                code                            ,
                description                     ,
                activity_status                 ,
                type                            ,
                exempt_from_VAT                 ,
                import_status                   ,
                inn                             ,
                main_contragent_settlement_id   ,
                email_address               
            FROM contragent
            WHERE is_current='Текущий'
            SETTINGS s3_create_new_file_on_insert = 1,s3_truncate_on_insert=1
            """,
            # result of the last query is pushed to XCom
        ),
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    load_contragent = ClickHouseOperator(
        task_id="load_contragent",
        database="dwh",
        sql=(
            """
            INSERT INTO contragent
              (
                id                              ,
                parent_id                       ,
                head_contragent_id              ,
                code                            ,
                description                     ,
                activity_status                 ,
                type                            ,
                exempt_from_VAT                 ,
                import_status                   ,
                inn                             ,
                main_contragent_settlement_id   ,
                email_address                   ,
                start_date                      ,
                end_date                        ,
                is_current
              )
            SELECT 
                id                              ,
                parent_id                       ,
                head_contragent_id              ,
                code                            ,
                description                     ,
                activity_status                 ,
                type                            ,
                exempt_from_VAT                 ,
                import_status                   ,
                inn                             ,
                main_contragent_settlement_id   ,
                email_address                   ,
                start_date                      ,
                end_date                        ,
                is_current
            FROM  s3(
                '{{conn.minio_s3.extra_dejson.endpoint_url }}/{{ti.xcom_pull(task_ids='contragent_scd',key='s3_key')}}',
                'parquet'
                );
            """,
            # result of the last query is pushed to XCom
        ),
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    update_contragent = ClickHouseOperator(
        task_id="update_contragent",
        database="dwh",
        sql=(
            """
            ALTER TABLE contragent
            UPDATE end_date='{{data_interval_start|ds}}',is_current='Исторический' WHERE id IN (SELECT  id FROM s3(
                            '{{conn.minio_s3.extra_dejson.endpoint_url }}/{{ti.xcom_pull(task_ids='contragent_scd',key='updated_s3_key')}}',
                            'parquet'
                            )) AND is_current = 'Текущий'
            """,
            # result of the last query is pushed to XCom
        ),
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    update_contragent_hierarchy = ClickHouseOperator(
        task_id="update_contragent_hierarchy",
        database="dwh",
        sql=(
            """
            ALTER TABLE contragent_hierarchy
            UPDATE end_date='{{data_interval_start|ds}}',is_current='Исторический' WHERE child_id IN (SELECT  child_id FROM s3(
                            '{{conn.minio_s3.extra_dejson.endpoint_url }}/{{ti.xcom_pull(task_ids='hierarchy_scd',key='updated_s3_key')}}',
                            'parquet'
                            )) AND is_current = 'Текущий'
            """,
            # result of the last query is pushed to XCom
        ),
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    load_contragent_hierarchy = ClickHouseOperator(
        task_id="load_contragent_hierarchy",
        database="dwh",
        sql=(
            """
            INSERT INTO contragent_hierarchy
              (
                parent_id          ,
                child_id           ,
                depth_from_parent  ,
                highest_flag_parent,
                lowest_flag_child  ,
                start_date         ,
                end_date           ,
                is_current
              )
            SELECT 
                parent_id          ,
                child_id           ,
                depth_from_parent  ,
                highest_flag_parent,
                lowest_flag_child  ,
                start_date         ,
                end_date           ,
                is_current
            FROM  s3(
                '{{conn.minio_s3.extra_dejson.endpoint_url }}/{{ti.xcom_pull(task_ids='hierarchy_scd',key='s3_key')}}',
                'parquet'
                );
            """,
            # result of the last query is pushed to XCom
        ),
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    (
        [
            extract_contragent_raw,
            extract_contragent_old,
            extract_contragent_hierarchy_old,
        ]
        >> from_s3_to_duckdb()
        >> transform_contragent()
        >> contragent_scd()
        >> update_contragent
        >> load_contragent
        >> build_hierarchy_bridge_table()
        >> hierarchy_scd()
        >> update_contragent_hierarchy
        >> load_contragent_hierarchy
        # >> remove_duckdb_file()
    )


contragent()
