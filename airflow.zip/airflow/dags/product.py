import os

import duckdb
import pendulum
from airflow.decorators import dag, task
from airflow.models.taskinstance import TaskInstance
from airflow_clickhouse_plugin.operators.clickhouse import ClickHouseOperator
from common_utils.telegram_utils import send_error_message_telegram
from constants.etl_constants import (
    EMPTY_NULL_PLACEHOLDER,
    EMPTY_NULL_PLACEHOLDER_FOR_REFERENCES,
)
from custom_operators.s3tosql import SqlToS3OperatorImproved

doc_md = """
# ETL Dimensions Product DAG Documentation

## Overview

The `product` DAG is designed to extract, transform, and load (ETL) data related to products into a data warehouse environment. This DAG handles the dimension data for products, organizing them into categories, updating product records with Slowly Changing Dimensions (SCD) logic, and loading the data into the data warehouse for analytical processing.

## DAG Configuration

- **Schedule**: Daily
- **Catchup**: False
- **Tags**: 'etl', 'dimensions'

## Tasks Overview

### extract_products_raw

- **Operator**: `SqlToS3OperatorImproved`
- **Description**: Extracts raw product data from the source system and stores it in S3 in parquet format.
- **Source**: Product management system accessed via `AR_TRADE_CONN_ID`.

### extract_price_segments_raw

- **Operator**: `SqlToS3OperatorImproved`
- **Description**: Extracts data related to price segments and stores it in S3 in parquet format.
- **Source**: Product management system accessed via `AR_TRADE_CONN_ID`.

### extract_statuses_raw

- **Operator**: `SqlToS3OperatorImproved`
- **Description**: Extracts data related to product statuses and stores it in S3 in parquet format.
- **Source**: Product management system accessed via `AR_TRADE_CONN_ID`.

### extract_trademarks_raw

- **Operator**: `SqlToS3OperatorImproved`
- **Description**: Extracts data related to trademarks and stores it in S3 in parquet format.
- **Source**: Product management system accessed via `AR_TRADE_CONN_ID`.

### extract_products_types_raw

- **Operator**: `SqlToS3OperatorImproved`
- **Description**: Extracts data related to product types and stores it in S3 in parquet format.
- **Source**: Product management system accessed via `AR_TRADE_CONN_ID`.

### extract_countries_raw

- **Operator**: `SqlToS3OperatorImproved`
- **Description**: Extracts data related to countries and stores it in S3 in parquet format.
- **Source**: Product management system accessed via `AR_TRADE_CONN_ID`.

### extract_old_product

- **Operator**: `ClickHouseOperator`
- **Description**: Extracts the current state of products from the data warehouse, marking them as 'current', and stores the data in S3 in CSV format.
- **Source**: Data warehouse accessed via `clickhouse_dwh`.

### from_s3_to_duckdb

- **Function**: `from_s3_to_duckdb`
- **Description**: Loads data from S3 into DuckDB, setting up necessary configurations for data manipulation and further processing within DuckDB.

### extract_product_categories

- **Function**: `extract_product_categories`
- **Description**: Extracts product categories from the raw product data in DuckDB, organizing products into hierarchical categories to facilitate further processing.

### delete_categories_from_products

- **Function**: `delete_categories_from_products`
- **Description**: Deletes category entries from the product table in DuckDB, ensuring that only non-categorized products remain for further processing.

### transform_product

- **Function**: `transform_product`
- **Description**: Transforms the product data by combining it with related tables such as categories, trademarks, product types, and price segments. This creates a structured and enriched product table ready for loading into the data warehouse.

### product_scd

- **Function**: `product_scd`
- **Description**: Implements Slowly Changing Dimensions (SCD) logic for product data. It tracks changes to product data and manages historical records in the data warehouse by identifying new and updated records.

### update_product

- **Operator**: `ClickHouseOperator`
- **Description**: Updates product records in the data warehouse, marking old records as historical and ensuring that the correct start and end dates are maintained for product records.

### load_product

- **Operator**: `ClickHouseOperator`
- **Description**: Loads the transformed and updated product data back into the data warehouse from S3, utilizing parquet files generated during the SCD process.

### remove_temp_files

- **Function**: `remove_temp_files`
- **Description**: Removes temporary files, including the DuckDB database file, to clean up resources and ensure that the next DAG run starts with a fresh environment.

## Data Flow

1. **Extract Data**: Product, price segments, trademarks, product types, and country data are extracted from the source system using `SqlToS3OperatorImproved` and stored in S3.
2. **Load into DuckDB**: The extracted data is loaded into DuckDB for further transformation and processing.
3. **Category Extraction**: Product categories are extracted and organized hierarchically in DuckDB.
4. **Data Transformation**: The product data is transformed, joined with related tables, and prepared for loading into the data warehouse.
5. **Slowly Changing Dimensions**: New and updated product records are identified, and historical records are managed using SCD logic.
6. **Load into Data Warehouse**: The final product data is loaded into the data warehouse, and old records are updated accordingly.
7. **Cleanup**: Temporary files are removed to clean up the environment for the next DAG run.

## Additional Details

- **Data Integrity**: This DAG is designed to ensure that product data is accurate and up-to-date by managing historical records and tracking changes with SCD logic.
- **Technology Stack**: Utilizes Airflow for orchestration, DuckDB for data processing, and ClickHouse for data storage, providing a robust system for ETL processes.
- **Security**: Implements secure data handling practices by configuring S3 access securely and ensuring that data transfer between systems is encrypted and managed through secure channels.


"""

# S3 stuff
S3_CONN_ID = "minio_s3"
BUCKET_NAME = "etl-data-files"
S3_FOLDER = "product"

DUCKDB_FILE = "/tmp/product.db"

AR_TRADE_CONN_ID = "nsp_ar_trade"


@task
def from_s3_to_duckdb(data_interval_end: pendulum.DateTime, ti: TaskInstance):
    """
    Loads data from various S3 buckets into DuckDB for further processing. This function initializes the DuckDB
    environment, configures access to S3, and then pulls multiple data streams into DuckDB tables for products,
    trademarks, countries, product types, and price segments.

    Parameters:
        data_interval_end (pendulum.DateTime): The end date of the data interval which determines the scope for
        fetching and processing the data.
        ti (TaskInstance): Airflow's TaskInstance object, used to pull data paths stored in XCom by previous tasks.

    Returns:
        None

    Raises:
        duckdb.DuckDBError: If there's an issue with executing SQL commands or connecting to the database.
        IOError: If there are issues accessing or reading from the specified S3 paths.
    """

    conn = duckdb.connect(DUCKDB_FILE)

    products_s3_key = ti.xcom_pull(task_ids="extract_products_raw", key="return_value")

    trademarks_s3_key = ti.xcom_pull(
        task_ids="extract_trademarks_raw", key="return_value"
    )
    product_type_s3_key = ti.xcom_pull(
        task_ids="extract_products_types_raw", key="return_value"
    )
    price_segments_s3_key = ti.xcom_pull(
        task_ids="extract_price_segments_raw", key="return_value"
    )

    statuses_s3_key = ti.xcom_pull(task_ids="extract_statuses_raw", key="return_value")

    product_old_s3_key = f"{BUCKET_NAME}/{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}/{S3_FOLDER}/product_old.csv"

    # Fetching old products
    conn.sql(
        f"CREATE OR REPLACE TABLE product_old AS SELECT * FROM read_csv('s3://{product_old_s3_key}')"
    )

    # Fetching all products
    conn.sql(
        f"CREATE OR REPLACE TABLE products_raw AS SELECT * FROM read_parquet('s3://{BUCKET_NAME}/{products_s3_key}')"
    )

    # Fetching all trademarks

    conn.sql(
        f"CREATE OR REPLACE TABLE trademarks_raw AS SELECT * FROM read_parquet('s3://{BUCKET_NAME}/{trademarks_s3_key}')"
    )

    # Fetching all product types
    conn.sql(
        f"CREATE OR REPLACE TABLE product_types AS SELECT * FROM read_parquet('s3://{BUCKET_NAME}/{product_type_s3_key}')"
    )

    # Fetching price segments
    conn.sql(
        f"CREATE OR REPLACE TABLE price_segments AS SELECT * FROM read_parquet('s3://{BUCKET_NAME}/{price_segments_s3_key}')"
    )

    # Fetching product statuses
    conn.sql(
        f"CREATE OR REPLACE TABLE statuses AS SELECT * FROM read_parquet('s3://{BUCKET_NAME}/{statuses_s3_key}')"
    )


@task
def extract_product_categories():
    """
    Extracts product categories from the raw products data stored in DuckDB and organizes them into hierarchical
    category tables. This function helps in classifying products into multiple category levels for better management
    and querying efficiency in downstream processes.
    """
    conn = duckdb.connect(DUCKDB_FILE)

    # First category
    conn.sql(
        "CREATE OR REPLACE TABLE first_category AS SELECT pr._IDRRef,pr._Description FROM products_raw pr WHERE _ParentIDRRef ='0x00000000000000000000000000000000'"  # where parent is not defined
    )

    # Second category
    conn.sql(
        "CREATE OR REPLACE TABLE second_category AS SELECT pr._IDRRef,pr._Description,pr._ParentIDRRef FROM first_category fc JOIN  products_raw pr ON pr._ParentIDRRef=fc._IDRRef"
    )

    # Third category
    conn.sql(
        "CREATE OR REPLACE TABLE third_category AS SELECT pr._IDRRef,pr._Description,pr._ParentIDRRef FROM second_category fc JOIN  products_raw pr ON pr._ParentIDRRef=fc._IDRRef"
    )

    # Fourth category
    conn.sql(
        "CREATE OR REPLACE TABLE fourth_category AS SELECT pr._IDRRef,pr._Description,pr._ParentIDRRef FROM third_category fc JOIN  products_raw pr ON pr._ParentIDRRef=fc._IDRRef"
    )

    # Fifth category
    conn.sql(
        "CREATE OR REPLACE TABLE fifth_category AS SELECT pr._IDRRef,pr._Description,pr._ParentIDRRef FROM fourth_category fc JOIN  products_raw pr ON pr._ParentIDRRef=fc._IDRRef"
    )


@task
def delete_categories_from_products():
    """
    Deletes entries from the products_raw table in DuckDB that are categorized under specific categories. This
    function is used to clean up the products table by removing entries that should be treated as categories rather
    than individual products.
    """

    conn = duckdb.connect(DUCKDB_FILE)
    conn.sql(
        """
    DELETE FROM products_raw WHERE _IDRRef IN 
    (
        SELECT _IDRRef FROM first_category
        UNION 
        SELECT _IDRRef FROM second_category
        UNION 
        SELECT _IDRRef FROM third_category
        UNION 
        SELECT _IDRRef FROM fourth_category
        UNION 
        SELECT _IDRRef FROM fifth_category
    )
    """
    )


@task
def transform_product():
    """
    Transforms the product data by joining with category, trademark, product product_type, and other related tables. It
    prepares a comprehensive products table that is ready for loading into a data warehouse or other analytical
    platforms.
    """

    conn = duckdb.connect(DUCKDB_FILE)

    conn.sql(
        f"""CREATE OR REPLACE TABLE product AS
            SELECT
                pr._IDRRef as id,
                pr._Code as code,
                pr._Description AS description,
                CASE WHEN trim(pr.Наименование1)='' THEN '{EMPTY_NULL_PLACEHOLDER}' ELSE pr.Наименование1 END AS description_kg,
                CASE WHEN trim(pr.Артикул)='' THEN '{EMPTY_NULL_PLACEHOLDER}' ELSE pr.Артикул END AS articul,
                CASE pr._Marked WHEN 1 THEN 'Деактивированный' WHEN 0 THEN 'Активный' END  AS activity_status,
                COALESCE(ps._Description,'{EMPTY_NULL_PLACEHOLDER}') as price_segment,
                CASE COALESCE(pr.Халал,0) WHEN 1 THEN 'Халал' WHEN 0 THEN 'Не Халал' END as is_halal,
                CASE COALESCE(ЭтоСертификат,0) WHEN 1 THEN 'Сертификат' WHEN 0 THEN 'Продукт' END AS is_certificate, 
                CASE pr.Импорт WHEN 1 THEN 'Импорт' WHEN 0 THEN 'Местное' ELSE '{EMPTY_NULL_PLACEHOLDER}' END  as import_status,
                COALESCE(tr._Description,'{EMPTY_NULL_PLACEHOLDER}') AS trademark,
                COALESCE(st._Description,'{EMPTY_NULL_PLACEHOLDER}') AS status,
                COALESCE(tp._Description,'{EMPTY_NULL_PLACEHOLDER}') AS product_type,
                COALESCE(pr.СтранаПроисхождения_ID,'{EMPTY_NULL_PLACEHOLDER_FOR_REFERENCES}') as country_id,
                COALESCE(fifth._Description,'{EMPTY_NULL_PLACEHOLDER}') AS fifth_category,
                COALESCE(fourth._Description,'{EMPTY_NULL_PLACEHOLDER}') AS fourth_category,
                COALESCE(third._Description,'{EMPTY_NULL_PLACEHOLDER}') AS third_category,
                COALESCE(second._Description,'{EMPTY_NULL_PLACEHOLDER}') AS second_category,
                COALESCE(first._Description,'{EMPTY_NULL_PLACEHOLDER}') AS first_category

             FROM products_raw pr

                LEFT JOIN fifth_category fifth ON fifth._IDRRef = pr._ParentIDRRef

                LEFT JOIN fourth_category fourth ON fourth._IDRRef = fifth._ParentIDRRef

                LEFT JOIN third_category third ON third._IDRRef = fourth._ParentIDRRef

                LEFT JOIN second_category second ON second._IDRRef = third._ParentIDRRef

                LEFT JOIN first_category first ON first._IDRRef = second._ParentIDRRef

                LEFT JOIN trademarks_raw tr ON tr._IDRRef = pr.ТоварнаяМарка_ID

                LEFT JOIN product_types tp ON tp._IDRRef = pr.ТипНоменклатуры_ID

                LEFT JOIN price_segments ps ON ps._IDRRef = pr.ЦеновойСегмент_ID
 
                LEFT JOIN statuses st ON pr.СтатусНоменклатуры_ID = st._IDRRef

              """
    )


@task
def product_scd(
    data_interval_start: pendulum.DateTime,
    data_interval_end: pendulum.DateTime,
    ti: TaskInstance,
):
    """
    Handles the Slowly Changing Dimension (SCD) logic for product data. It detects new and changed records, and
    manages historical records in the data warehouse.

    Parameters:
        data_interval_start (pendulum.DateTime): The start date for considering changes.
        data_interval_end (pendulum.DateTime): The end date for considering changes.
        ti (TaskInstance): Airflow's TaskInstance object for XCom operations.

    Returns:
        None

    Raises:
        duckdb.DuckDBError: If there's an issue with executing SQL commands or connecting to the database.
        IOError: If there are issues accessing or writing to the S3 bucket.
    """
    conn = duckdb.connect(DUCKDB_FILE)

    ## getting new rows
    conn.sql(
        """
    CREATE OR REPLACE TABLE product_new_rows AS
    (
    SELECT 
        id,
        description,
        description_kg,
        code,
        articul,
        activity_status,
        price_segment,
        is_halal,
        is_certificate,
        import_status,
        trademark,
        status,
        product_type,
        country_id,
        fifth_category,
        fourth_category,
        third_category,
        second_category,
        first_category
    FROM product
    EXCEPT 
    SELECT 
        id,
        description,
        description_kg,
        code,
        articul,
        activity_status,
        price_segment,
        is_halal,
        is_certificate,
        import_status,
        trademark,
        status,
        product_type,
        country_id,
        fifth_category,
        fourth_category,
        third_category,
        second_category,
        first_category
    FROM product_old
    )
    """
    )

    # getting rows that were updated(changed)
    conn.sql(
        """
    CREATE OR REPLACE TABLE product_updated_rows AS
    (
    SELECT 
        id,
        description,
        description_kg,
        code,
        articul,
        activity_status,
        price_segment,
        is_halal,
        is_certificate,
        import_status,
        trademark,
        status,
        product_type,
        country_id,
        fifth_category,
        fourth_category,
        third_category,
        second_category,
        first_category
    FROM product_old
    EXCEPT 
    SELECT 
        id,
        description,
        description_kg,
        code,
        articul,
        activity_status,
        price_segment,
        is_halal,
        is_certificate,
        import_status,
        trademark,
        status,
        product_type,
        country_id,
        fifth_category,
        fourth_category,
        third_category,
        second_category,
        first_category
    FROM product
    )
    """
    )

    # if product table in dwh is empty fill it with data_interval_start (1970-1-1) which is minimum possible date in clickhouse
    count_old = conn.sql("SELECT COUNT(*) FROM product_old").fetchone()[0]
    if count_old == 0:
        data_interval_start = pendulum.DateTime(1970, 1, 1)

    # for new rows set start_date to today
    conn.sql(
        f"ALTER TABLE product_new_rows ADD COLUMN start_date Date DEFAULT '{data_interval_start.to_date_string()}'"
    )

    # set end_date for new rows to be  '2149-06-06' which is maximum possible date in clickhouse
    conn.sql(
        "ALTER TABLE product_new_rows ADD COLUMN end_date Date DEFAULT '2149-06-06'"
    )

    # set column is_current to 'Текущий' for new rows
    conn.sql(
        "ALTER TABLE product_new_rows ADD COLUMN is_current String DEFAULT 'Текущий'"
    )

    conn.sql("LOAD httpfs;")

    # push new rows to s3
    filename = "product_new_rows.parquet"
    s3_key = f"{BUCKET_NAME}/{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}/{S3_FOLDER}/{filename}"
    conn.sql(f"COPY product_new_rows TO 's3://{s3_key}';")
    ti.xcom_push(key="s3_key", value=s3_key)

    # push updated(changed rows) to s3
    updated_filename = "product_updated_rows.parquet"
    updated_s3_key = f"{BUCKET_NAME}/{data_interval_end.year}/{data_interval_end.month}/{data_interval_end.day}/{S3_FOLDER}/{updated_filename}"
    conn.sql(f"COPY product_updated_rows TO 's3://{updated_s3_key}';")
    ti.xcom_push(key="updated_s3_key", value=updated_s3_key)


@task
def remove_temp_files():
    os.remove(DUCKDB_FILE)


@dag(
    default_args={
        "owner": "ubaitur5",
        "on_failure_callback": send_error_message_telegram,
    },
    schedule_interval="@daily",
    template_searchpath=["/opt/airflow/dags/include/sql_files/"],
    start_date=pendulum.DateTime(2024, 7, 23),
    doc_md=doc_md,
    tags=["etl", "dimensions"],
    catchup=False,
)
def product():

    extract_products_raw = SqlToS3OperatorImproved(
        task_id="extract_products_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query="""
        SELECT 
            CONVERT(nchar(34),_IDRRef,1) AS _IDRRef,
            CONVERT(nchar(34),_ParentIDRRef,1) AS _ParentIDRRef,
            _Code,
            _Description,
            Наименование1,
            Артикул,
            CONVERT(int,_Marked) AS _Marked,
            CONVERT(int,Халал) AS Халал,
            CONVERT(int,Импорт) AS Импорт,
            CONVERT(int,ЭтоСертификат) AS ЭтоСертификат,
            CONVERT(nchar(34),СтатусНоменклатуры_ID,1) AS СтатусНоменклатуры_ID,
            СрокВозврата,
            CONVERT(nchar(34),ТипНоменклатуры_ID,1) AS ТипНоменклатуры_ID,
            CONVERT(nchar(34),СтранаПроисхождения_ID,1) AS СтранаПроисхождения_ID,
            CONVERT(nchar(34),ТоварнаяМарка_ID,1) AS ТоварнаяМарка_ID,
            CONVERT(nchar(34),ЦеновойСегмент_ID,1) AS ЦеновойСегмент_ID
        FROM vw_Номенклатура
        """,
        s3_bucket=BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="products_raw.parquet",
        replace=True,
        aws_conn_id=S3_CONN_ID,
        file_format="parquet",
        pd_kwargs={"index": False},  # pandas parameters to pass into .to_parquet()
    )

    extract_price_segments_raw = SqlToS3OperatorImproved(
        task_id="extract_price_segments_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query="""
        SELECT 
            CONVERT(nchar(34),_IDRRef,1) AS _IDRRef,
            _Description
        FROM vw_ЦеновыеСегменты
        """,
        s3_bucket=BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="price_segments_raw.parquet",
        replace=True,
        aws_conn_id=S3_CONN_ID,
        file_format="parquet",
        pd_kwargs={"index": False},  # pandas parameters to pass into .to_parquet()
    )

    extract_trademarks_raw = SqlToS3OperatorImproved(
        task_id="extract_trademarks_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query="""
        SELECT 
            CONVERT(nchar(34),_IDRRef,1) AS _IDRRef,
            _Description
        FROM vw_ТоварныеМарки
        """,
        s3_bucket=BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="trademarks_raw.parquet",
        replace=True,
        aws_conn_id=S3_CONN_ID,
        file_format="parquet",
        pd_kwargs={"index": False},  # pandas parameters to pass into .to_parquet()
    )

    extract_statuses_raw = SqlToS3OperatorImproved(
        task_id="extract_statuses_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query="""
        SELECT 
            CONVERT(nchar(34),_IDRRef,1) AS _IDRRef,
            _Description
        FROM vw_СтатусыНоменклатуры
        """,
        s3_bucket=BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="statuses_raw.parquet",
        replace=True,
        aws_conn_id=S3_CONN_ID,
        file_format="parquet",
        pd_kwargs={"index": False},  # pandas parameters to pass into .to_parquet()
    )

    extract_products_types_raw = SqlToS3OperatorImproved(
        task_id="extract_products_types_raw",
        sql_conn_id=AR_TRADE_CONN_ID,
        query="""
        SELECT 
            CONVERT(nchar(34),_IDRRef,1) AS _IDRRef,
            _Description
        FROM vw_ТипыНоменклатуры
        """,
        s3_bucket=BUCKET_NAME,
        report_name=S3_FOLDER,
        filename="products_types_raw.parquet",
        replace=True,
        aws_conn_id=S3_CONN_ID,
        file_format="parquet",
        pd_kwargs={"index": False},  # pandas parameters to pass into .to_parquet()
    )

    extract_old_product = ClickHouseOperator(
        task_id="extract_old_product",
        database="dwh",
        sql=(
            f"""
            INSERT INTO FUNCTION
            s3(
                '{{{{ conn.minio_s3.extra_dejson.endpoint_url_for_writing }}}}/{BUCKET_NAME}/{{{{data_interval_end.year}}}}/{{{{data_interval_end.month}}}}/{{{{data_interval_end.day}}}}/{S3_FOLDER}/product_old.csv',
                '{{{{ conn.minio_s3.extra_dejson.aws_access_key_id}}}}',
                '{{{{ conn.minio_s3.extra_dejson.aws_secret_access_key}}}}',
                'CSVWithNames'
                )
            SELECT 
                id,
                description,
                description_kg,
                code,
                articul,
                activity_status,
                price_segment,
                is_halal,
                is_certificate,
                import_status,
                trademark,
                status,
                product_type,
                country_id,
                fifth_category,
                fourth_category,
                third_category,
                second_category,
                first_category
            FROM product
            WHERE is_current='Текущий'
            SETTINGS s3_create_new_file_on_insert = 1,s3_truncate_on_insert=1
            """,
            # result of the last query is pushed to XCom
        ),
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    load_product = ClickHouseOperator(
        task_id="load_product",
        database="dwh",
        sql=(
            """
            INSERT INTO product 
            (
                id,
                description,
                description_kg,
                code,
                articul,
                activity_status,
                price_segment,
                is_halal,
                is_certificate,
                import_status,
                trademark,
                status,
                product_type,
                country_id,
                fifth_category,
                fourth_category,
                third_category,
                second_category,
                first_category,
                start_date,
                end_date,
                is_current
            )
            SELECT 
                id,
                description,
                description_kg,
                code,
                articul,
                activity_status,
                price_segment,
                is_halal,
                is_certificate,
                import_status,
                trademark,
                status,
                product_type,
                country_id,
                fifth_category,
                fourth_category,
                third_category,
                second_category,
                first_category,
                start_date,
                end_date,
                is_current
            FROM  s3(
                '{{ conn.minio_s3.extra_dejson.endpoint_url }}/{{ti.xcom_pull(task_ids='product_scd',key='s3_key')}}',
                'parquet'
                );
            """,
            # result of the last query is pushed to XCom
        ),
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    update_product = ClickHouseOperator(
        task_id="update_product",
        database="dwh",
        sql=(
            """
            ALTER TABLE product
            UPDATE end_date='{{data_interval_start|ds}}',is_current='Исторический' WHERE id IN (SELECT  id FROM s3(
                            '{{ conn.minio_s3.extra_dejson.endpoint_url }}/{{ti.xcom_pull(task_ids='product_scd',key='updated_s3_key')}}',
                            'parquet'
                            )) AND is_current = 'Текущий'
            """,
            # result of the last query is pushed to XCom
        ),
        # query_id is templated and allows to quickly identify query in ClickHouse logs
        query_id="{{ ti.dag_id }}-{{ ti.task_id }}-{{ ti.run_id }}-{{ ti.try_number }}",
        clickhouse_conn_id="clickhouse_dwh",
    )

    (
        [
            extract_old_product,
            extract_products_raw,
            extract_products_types_raw,
            extract_trademarks_raw,
            extract_price_segments_raw,
            extract_statuses_raw,
        ]
        >> from_s3_to_duckdb()
        >> extract_product_categories()
        >> delete_categories_from_products()
        >> transform_product()
        >> product_scd()
        >> update_product
        >> load_product
        >> remove_temp_files()
    )


product()
