WITH source AS (

    SELECT * FROM {{ ref("base_ar_trade__users") }}

)

, final AS (
    SELECT * FROM source
)


SELECT * FROM final
