WITH source AS (
    SELECT * FROM {{source('raw_dbt', 'assortments_raw')}}
),
renamed AS (
    SELECT
        CAST("_Period" AS Date) AS date
        , {{transform_hex_to_uuid('"_RecorderRRef"')}} AS recorder_id
        , CAST({{transform_hex_to_uuid('"ПодразделениеКомпании_ID"')}} AS LowCardinality(UUID)) AS division_id
        , CAST({{transform_hex_to_uuid('"Номенклатура_ID"')}} AS LowCardinality(UUID)) AS product_id
        , CAST({{transform_hex_to_uuid('"СтавкаНДС_ID"')}} AS LowCardinality(UUID)) AS vat_rate_id
        , CAST("Состояние" AS UInt8) AS is_entered
        , {{transform_decimal('"Цена"')}} AS cost_price_with_VAT
        , CAST("БазовыйАссортимент" AS UInt8) AS is_base_assortment
    FROM source
)
SELECT * FROM renamed