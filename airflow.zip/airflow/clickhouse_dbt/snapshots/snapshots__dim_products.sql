{% snapshot snapshots__dim_products %}
    select * from {{ ref('int_products_with_hierarchy') }}
{% endsnapshot %}