SELECT 
      [_Date_Time]
      ,[_Number]
      ,CONVERT(NCHAR(34),[Автор_ID],1) AS Автор_ID
      ,CONVERT(NCHAR(34),[ПодразделениеКомпании_ID],1) AS ПодразделениеКомпании_ID
      ,CONVERT(INT,[РегламентированныйУчет]) AS РегламентированныйУчет
      ,[Комментарий]
      ,CONVERT(NCHAR(34),[СкладКомпании_ID],1) AS СкладКомпании_ID
      ,CONVERT(INT,СкладКомпании_НОМЕР) AS СкладКомпании_НОМЕР
      ,CONVERT(INT,СкладПолучатель_НОМЕР) AS СкладПолучатель_НОМЕР
      ,CONVERT(NCHAR(34),[СкладПолучатель_ID],1) AS СкладПолучатель_ID
      ,CONVERT(NCHAR(34),[ТипЦен_ID],1) AS ТипЦен_ID
      ,CONVERT(NCHAR(34),[ХозОперация_ID],1) AS ХозОперация_ID
	,[ИДДокументаОтгрузки]
      --   ,[ВхДокНомер]
      --   ,[ВхДокДата]--
	,CONVERT(INT,[ЗакрытиеЗаказовПокупателей]) AS ЗакрытиеЗаказовПокупателей
	,CONVERT(NCHAR(34),mvt.Номенклатура_ID,1) AS Номенклатура_ID
	,mvt.Количество
	,CONVERT(NCHAR(34),mvt.ЕдиницаИзмерения_ID,1) AS ЕдиницаИзмерения_ID
	,mvt.СуммаРозничная --amount
	,mvt.Сумма --cost_price
	,CONVERT(NCHAR(34),mvt.СтавкаНДС_ID,1) AS СтавкаНДС_ID
	,mvt.СуммаНДС

FROM vw_ПеремещениеТоваров mv
	LEFT JOIN vw_ПеремещениеТоваров_Товары mvt ON mvt.Ссылка=mv._IDRRef
WHERE mv._Marked=0x00 AND mv._Posted=0x01
AND _Date_Time >= '{{get_data_interval_start(data_interval_end,params.month_range).add(years=2000) | ds_nodash}}' AND _Date_Time < '{{data_interval_end.add(years=2000) | ds_nodash}}'

	

